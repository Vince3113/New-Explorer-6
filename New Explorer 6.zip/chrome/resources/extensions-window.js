(function () {
  const { AddonManager } = ChromeUtils.importESModule(
    "resource://gre/modules/AddonManager.sys.mjs"
  );

  function h(tag, className, text) {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (text != null) el.textContent = text;
    return el;
  }

  function syncColorScheme() {
    const parentWin = Services.wm.getMostRecentWindow("navigator:browser");
    if (!parentWin) return;
    try {
      const srcRoot = parentWin.document.documentElement;
      const dstRoot = document.documentElement;
      const apply = () => {
        const v = srcRoot.getAttribute("ie6-colorscheme");
        if (v) dstRoot.setAttribute("ie6-colorscheme", v);
        else dstRoot.removeAttribute("ie6-colorscheme");
      };
      apply();
      const mo = new parentWin.MutationObserver(apply);
      mo.observe(srcRoot, { attributes: true, attributeFilter: ["ie6-colorscheme"] });
      window.addEventListener("unload", () => { try { mo.disconnect(); } catch (e) {} }, { once: true });
    } catch (e) {}
  }

  function openInBrowser(url) {
    const win = Services.wm.getMostRecentWindow("navigator:browser");
    if (!win) return;
    win.gBrowser.selectedTab = win.gBrowser.addTab(url, {
      triggeringPrincipal: Services.scriptSecurityManager.getSystemPrincipal(),
    });
    win.focus();
  }

  function createCustomSelect(options, initialValue, onChange) {
    const el = h("div", "ie6ext-custom-select");
    el.tabIndex = 0;

    let currentIndex = Math.max(0, options.findIndex((o) => o.value === initialValue));
    let highlightedIndex = 0;

    const selectText = h("span", "ie6ext-select-text", options[currentIndex].label);
    el.append(selectText, h("div", "ie6ext-dropmarker"));

    const dropdownMenu = h("div", "ie6ext-custom-dropdown");
    dropdownMenu.style.display = "none";
    document.body.appendChild(dropdownMenu);

    const isOpen = () => dropdownMenu.style.display === "block";

    function setOpen(open) {
      dropdownMenu.style.display = open ? "block" : "none";
      el.classList.toggle("open", open);
    }

    function setHighlight(index) {
      highlightedIndex = index;
      items.forEach((item, i) => item.classList.toggle("selected", i === index));
    }

    function selectOption(index, fire) {
      currentIndex = index;
      selectText.textContent = options[index].label;
      setOpen(false);
      el.focus();
      if (fire && onChange) onChange(options[index].value);
    }

    const items = options.map((opt, index) => {
      const item = h("div", "ie6ext-dropdown-item", opt.label);
      item.addEventListener("mouseenter", () => setHighlight(index));
      item.addEventListener("click", (e) => {
        e.stopPropagation();
        selectOption(index, true);
      });
      dropdownMenu.appendChild(item);
      return item;
    });

    el.addEventListener("click", (e) => {
      e.stopPropagation();
      if (isOpen()) {
        setOpen(false);
        return;
      }
      const rect = el.getBoundingClientRect();
      dropdownMenu.style.top = `${rect.bottom}px`;
      dropdownMenu.style.left = `${rect.left}px`;
      dropdownMenu.style.width = `${rect.width}px`;
      setOpen(true);
      setHighlight(currentIndex);
    });

    el.addEventListener("keydown", (e) => {
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        if (!isOpen()) {
          el.click();
          return;
        }
        const step = e.key === "ArrowDown" ? 1 : -1;
        setHighlight((highlightedIndex + step + options.length) % options.length);
      } else if (e.key === "Enter") {
        e.preventDefault();
        if (isOpen()) selectOption(highlightedIndex, true);
      } else if (e.key === "Escape") {
        e.preventDefault();
        setOpen(false);
      }
    });

    window.addEventListener("click", () => setOpen(false));

    return el;
  }

  window.addEventListener("load", () => {
    syncColorScheme();

    const $ = (id) => document.getElementById(id);
    const listBody = $("ie6ext-list-body");
    const radioEnable = $("ie6ext-radio-enable");
    const radioDisable = $("ie6ext-radio-disable");
    const uninstallBtn = $("ie6ext-uninstall-btn");

    const SORT_ACCESSORS = {
      name: (a) => (a.name || "").toLowerCase(),
      publisher: (a) => ((a.creator && a.creator.name) || "").toLowerCase(),
      status: (a) => (a.userDisabled ? 1 : 0),
      type: () => "extension",
      file: (a) => (a.id || "").toLowerCase(),
    };

    let addons = [];
    let currentFilter = "all";
    let sortKey = "name";
    let sortDir = "asc";
    let selectedRow = null;
    let selectedAddon = null;

    const showSelect = createCustomSelect(
      [
        { label: "All Extensions in Internet Explorer", value: "all" },
        { label: "Extensions currently enabled in Internet Explorer", value: "enabled" },
        { label: "Extensions currently disabled in Internet Explorer", value: "disabled" },
      ],
      "all",
      (val) => {
        currentFilter = val;
        renderRows();
      }
    );
    showSelect.id = "ie6ext-show-select";
    $("ie6ext-root").appendChild(showSelect);

    document.querySelectorAll(".ie6ext-colbtn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const key = btn.id.replace("ie6ext-col-", "");
        if (sortKey === key) {
          sortDir = sortDir === "asc" ? "desc" : "asc";
        } else {
          sortKey = key;
          sortDir = "asc";
        }
        renderRows();
      });
    });

    function sortAddons(list) {
      const accessor = SORT_ACCESSORS[sortKey];
      const dir = sortDir === "desc" ? -1 : 1;
      return [...list].sort((a, b) => {
        const av = accessor(a);
        const bv = accessor(b);
        return av < bv ? -dir : av > bv ? dir : 0;
      });
    }

    function setActionsEnabled(enabled) {
      radioEnable.disabled = radioDisable.disabled = uninstallBtn.disabled = !enabled;
    }

    function syncRadios(addon) {
      radioEnable.checked = !addon.userDisabled;
      radioDisable.checked = addon.userDisabled;
    }

    function clearSelection() {
      if (selectedRow) selectedRow.classList.remove("selected");
      selectedRow = null;
      selectedAddon = null;
      setActionsEnabled(false);
    }

    function selectRow(row, addon) {
      if (selectedRow) selectedRow.classList.remove("selected");
      selectedRow = row;
      selectedAddon = addon;
      row.classList.add("selected");
      setActionsEnabled(true);
      syncRadios(addon);
    }

    function titledCell(className, text) {
      const cell = h("div", "ie6ext-cell " + className, text);
      cell.title = text;
      return cell;
    }

    function buildRow(addon) {
      const row = h("div", "ie6ext-row");

      const nameCell = h("div", "ie6ext-cell ie6ext-cell-name");
      const icon = h("img", "ie6ext-row-icon");
      icon.src = addon.iconURL || "resource://ie6theme/images/extension.png";
      const nameLabel = h("span", "", addon.name);
      nameLabel.title = addon.name;
      nameCell.append(icon, nameLabel);

      row.append(
        nameCell,
        titledCell("ie6ext-cell-publisher", (addon.creator && addon.creator.name) || "Not available"),
        h("div", "ie6ext-cell ie6ext-cell-status", addon.userDisabled ? "Disabled" : "Enabled"),
        h("div", "ie6ext-cell ie6ext-cell-type", "Extension"),
        titledCell("ie6ext-cell-file", addon.id)
      );

      row.addEventListener("click", () => selectRow(row, addon));
      row.addEventListener("contextmenu", (e) => {
        e.preventDefault();
        selectRow(row, addon);
        openInBrowser(addon.optionsURL || "about:addons");
      });
      row.addEventListener("dblclick", () => openInBrowser(addon.optionsURL || "about:addons"));

      return row;
    }

    function renderRows() {
      listBody.replaceChildren();
      clearSelection();

      const filtered = addons.filter((a) => {
        if (currentFilter === "enabled") return !a.userDisabled;
        if (currentFilter === "disabled") return a.userDisabled;
        return true;
      });

      if (filtered.length === 0) {
        listBody.appendChild(h("div", "ie6ext-empty", "No extensions match this filter."));
        return;
      }

      for (const addon of sortAddons(filtered)) {
        listBody.appendChild(buildRow(addon));
      }
    }

    for (const radio of [radioEnable, radioDisable]) {
      radio.addEventListener("change", async () => {
        const addon = selectedAddon;
        const row = selectedRow;
        if (!addon) return;
        try {
          if (radioDisable.checked) await addon.disable();
          else await addon.enable();
        } catch (e) {
          if (addon === selectedAddon) syncRadios(addon);
          return;
        }
        row.querySelector(".ie6ext-cell-status").textContent = addon.userDisabled ? "Disabled" : "Enabled";
      });
    }

    uninstallBtn.addEventListener("click", async () => {
      if (!selectedAddon) return;
      const addonToUninstall = selectedAddon;

      try {
        await addonToUninstall.uninstall();
        addons = addons.filter((a) => a.id !== addonToUninstall.id);
        renderRows();
      } catch (e) {}
    });

    $("ie6ext-ok-btn").addEventListener("click", () => window.close());

    $("ie6ext-learnmore").addEventListener("click", (e) => {
      e.preventDefault();
      openInBrowser("about:addons");
    });

    AddonManager.getAddonsByTypes(["extension"])
      .then((list) => {
        addons = list.filter((a) => !a.hidden);
        renderRows();
      })
      .catch((e) => {});
  }, { once: true });
})();