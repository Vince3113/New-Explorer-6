const { CustomizableUI } = ChromeUtils.importESModule(
  "moz-src:///browser/components/customizableui/CustomizableUI.sys.mjs"
);

const LOG = "[customize-toolbar]";
const AREA = "nav-bar";
const SEPARATOR_BUTTON_ID = "ie6-add-separator-button";
const PREF_TEXT_MODE = "ie6theme.toolbar.textMode";
const PREF_ICON_SIZE = "ie6theme.toolbar.iconSize";

const browserWin = window.opener || Services.wm.getMostRecentBrowserWindow();
const $ = (id) => document.getElementById(id);

const EXCLUDED_WIDGET_IDS = new Set([
  "send-tab-button",
  "sidebar-button",
  "share-tab-button",
  "firefox-view-button",
  "import-button",
  "new-window-button",
  "search-container",
  "panic-button",
  "alltabs-button",
  "library-button",
  "sync-button",
  "urlbar-container",
  "ie6-address-toolbar",
  "reset-pbm-toolbar-button",
  "vertical-spacer",
  "fxa-toolbar-menu-button",
  "privatebrowsing-button",
]);

const EXCLUDED_ID_PATTERN = /screenshot/i;
const isExcluded = (id) => EXCLUDED_WIDGET_IDS.has(id) || EXCLUDED_ID_PATTERN.test(id);

const LABEL_OVERRIDES = {
  "back-button": "Back",
  "forward-button": "Forward",
  "stop-reload-button": "Stop / Reload",
  "home-button": "Home",
  "find-button": "Search",
  "bookmarks-menu-button": "Favorites",
  "history-panelmenu": "History",
  "email-link-button": "Email",
  "print-button": "Print",
  "unified-extensions-button": "Extensions",
  "downloads-button": "Downloads",
  "save-page-button": "Save Page",
  "open-file-button": "Open File",
  "zoom-controls": "Zoom Controls",
  "edit-controls": "Edit Controls",
  "characterencoding-button": "Encoding",
  "logins-button": "Passwords",
  "preferences-button": "Edit",
  "developer-button": "Developer",
  "fullscreen-button": "Full Screen",
  "ie6-account-button": "Account",
};

const selected = { available: null, current: null };
let activeList = null;

function friendlyLabel(widget) {
  if (widget.id.startsWith("customizableui-special-separator")) return "Separator";
  return (
    LABEL_OVERRIDES[widget.id] ||
    widget.label ||
    widget.id
      .replace(/-(button|toolbar|container)$/, "")
      .split(/[-_]/)
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
      .join(" ")
  );
}

function h(tag, cls, text) {
  const el = document.createElement(tag);
  if (cls) el.className = cls;
  if (text) el.textContent = text;
  return el;
}

function createItem(widget, listKey) {
  let cls = "ct-item";
  if (selected[listKey] === widget.id) {
    cls += activeList === listKey ? " selected" : " selected-inactive";
  }
  const item = h("div", cls);
  item.append(h("div", `ct-icon ct-icon-${widget.id}`), h("span", "", friendlyLabel(widget)));
  item.addEventListener("click", () => {
    selected[listKey] = widget.id;
    activeList = listKey;
    refreshLists();
  });
  return item;
}

function fillList(listKey, widgets) {
  $(`ct-${listKey}`).replaceChildren(...widgets.map((w) => createItem(w, listKey)));
}

function refreshLists() {
  const current = CustomizableUI.getWidgetIdsInArea(AREA)
    .map((id) => CustomizableUI.getWidget(id))
    .filter((w) => w && !isExcluded(w.id));

  const available = CustomizableUI.getUnusedWidgets(browserWin.gNavToolbox.palette)
    .filter((w) => !isExcluded(w.id))
    .sort((a, b) => (b.id === SEPARATOR_BUTTON_ID) - (a.id === SEPARATOR_BUTTON_ID));

  fillList("current", current);
  fillList("available", available);
}

function moveSelected(listFrom, listTo, action) {
  const id = selected[listFrom];
  if (!id) return;
  action(id);
  selected[listTo] = id;
  selected[listFrom] = null;
  activeList = listTo;
  refreshLists();
}

function moveWithinArea(delta) {
  const id = selected.current;
  if (!id) return;

  const ids = CustomizableUI.getWidgetIdsInArea(AREA);
  const visible = ids.filter((i) => !isExcluded(i));
  const neighbor = visible[visible.indexOf(id) + delta];
  if (!neighbor) return;

  const neighborIndex = ids.indexOf(neighbor);
  const position = delta < 0 ? neighborIndex : neighborIndex + 1;
  if (position < ids.length) CustomizableUI.moveWidgetWithinArea(id, position);
  else CustomizableUI.moveWidgetWithinArea(id);

  activeList = "current";
  refreshLists();
}

function initButtons() {
  $("ct-add").addEventListener("click", () =>
    moveSelected("available", "current", (id) => CustomizableUI.addWidgetToArea(id, AREA))
  );
  $("ct-remove").addEventListener("click", () =>
    moveSelected("current", "available", (id) => CustomizableUI.removeWidgetFromArea(id))
  );
  $("ct-up").addEventListener("click", () => moveWithinArea(-1));
  $("ct-down").addEventListener("click", () => moveWithinArea(1));

  $("ct-reset").addEventListener("click", () => {
    CustomizableUI.reset();
    selected.available = selected.current = activeList = null;
    refreshLists();
  });
  $("ct-close").addEventListener("click", () => window.close());

  const titlebar = $("ct-titlebar-checkbox");
  titlebar.checked = Services.prefs.getIntPref("browser.tabs.inTitlebar", 1) === 0;
  titlebar.addEventListener("change", () => {
    Services.prefs.setIntPref("browser.tabs.inTitlebar", titlebar.checked ? 0 : 1);
  });
}

function syncColorScheme() {
  try {
    const src = browserWin.document.documentElement;
    const dst = document.documentElement;
    const apply = () => {
      const v = src.getAttribute("ie6-colorscheme");
      if (v) dst.setAttribute("ie6-colorscheme", v);
      else dst.removeAttribute("ie6-colorscheme");
    };
    apply();
    const mo = new browserWin.MutationObserver(apply);
    mo.observe(src, { attributes: true, attributeFilter: ["ie6-colorscheme"] });
    window.addEventListener("unload", () => { try { mo.disconnect(); } catch (e) {} }, { once: true });
  } catch (e) {}
}

function wireCombo(id, prefName, defaultValue) {
  const combo = $(id);
  const textEl = combo.querySelector(".ct-combo-text");
  const list = combo.querySelector(".ct-combo-list");
  const items = [...list.querySelectorAll(".ct-combo-item")];
  const clamp = (i) => Math.max(0, Math.min(items.length - 1, i));
  let selectedIndex = 0;
  let activeIndex = 0;
  let isOpen = false;

  function setValue(value, save) {
    const idx = items.findIndex((i) => i.dataset.value === value);
    if (idx < 0) return false;
    selectedIndex = idx;
    textEl.textContent = items[idx].textContent;
    if (save) Services.prefs.setStringPref(prefName, value);
    return true;
  }

  function setActive(idx) {
    activeIndex = clamp(idx);
    items.forEach((it, i) => it.classList.toggle("active", i === activeIndex));
  }

  function open() {
    list.style.display = "block";
    list.classList.remove("up");
    const spaceBelow = window.innerHeight - combo.getBoundingClientRect().bottom;
    if (list.offsetHeight > spaceBelow) list.classList.add("up");
    combo.classList.add("open");
    setActive(selectedIndex);
    isOpen = true;
  }

  function close() {
    list.style.display = "none";
    combo.classList.remove("open");
    isOpen = false;
  }

  function choose(idx) {
    setValue(items[idx].dataset.value, true);
    close();
  }

  if (!setValue(Services.prefs.getStringPref(prefName, defaultValue), false)) {
    setValue(defaultValue, false);
  }

  combo.addEventListener("mousedown", (e) => {
    if (list.contains(e.target)) return;
    if (isOpen) close();
    else open();
  });
  combo.addEventListener("blur", close);
  document.addEventListener("mousedown", (e) => {
    if (isOpen && !combo.contains(e.target)) close();
  });

  items.forEach((item, i) => {
    item.addEventListener("mouseover", () => setActive(i));
    item.addEventListener("click", () => choose(i));
  });

  combo.addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      const delta = e.key === "ArrowDown" ? 1 : -1;
      if (isOpen) setActive(activeIndex + delta);
      else setValue(items[clamp(selectedIndex + delta)].dataset.value, true);
    } else if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      if (isOpen) choose(activeIndex);
      else open();
    } else if (e.key === "Escape" && isOpen) {
      e.preventDefault();
      e.stopPropagation();
      close();
    }
  });
}

function init() {
  syncColorScheme();
  initButtons();
  wireCombo("ct-text-options", PREF_TEXT_MODE, "selective");
  wireCombo("ct-icon-options", PREF_ICON_SIZE, "large");
  refreshLists();

  if (typeof browserWin.ie6WireContainer === "function") {
    browserWin.ie6WireContainer($("ct-available"));
    browserWin.ie6WireContainer($("ct-current"));
  }
}

init();
browserWin.addEventListener("unload", () => window.close(), { once: true });