(function () {
  const HTML_NS = "http://www.w3.org/1999/xhtml";

  const MEDIA_EXTENSIONS = {
    pictures: ["jpg", "jpeg", "png", "gif", "bmp", "tif", "tiff", "webp", "ico", "heic"],
    music: ["mp3", "wav", "wma", "aac", "flac", "ogg", "oga", "m4a", "opus", "mid", "midi"],
    video: ["mp4", "avi", "wmv", "mov", "mkv", "flv", "webm", "mpg", "mpeg", "m4v", "3gp", "ogv"],
  };

  const TEXT_DOCUMENT_EXTENSIONS = [
    "txt", "doc", "docx", "rtf", "odt", "wpd",
    "pdf",
    "xls", "xlsx", "ods", "csv",
    "ppt", "pptx", "odp",
    "md", "log",
  ];

  const SEARCH_MAX_ENTRIES = 20000;
  const SEARCH_MAX_RESULTS = 300;
  const SEARCH_TIME_BUDGET_MS = 20000;
  const SEARCH_SKIP_DIRS = new Set([
    "windows", "$recycle.bin", "system volume information", "programdata", "node_modules", "appdata",
  ]);

  const DRIVE_LETTERS = "CDEFGHIJKLMNOPQRSTUVWXYZ";
  const ROVER_TRICK_COUNT = 7;
  const ROVER_BALLOON_TEXT = "I love to play fetch. Throw me a question!";
  const OK_CANCEL_ROW = "sc-btnrow sc-okcancel";

  const SILVER_SCROLLDOWN = {
    "scrolldown.png": ["silver"],
    "scrolldownhover.png": ["silver"],
  };

  const SCHEME_IMAGE_RULES = {
    olive: { folders: ["olive"] },
    silver: { folders: ["silver"] },
    royale: { folders: ["royale"] },
    royalenoir: { folders: ["royalenoir", "royale"] },
    zune: { folders: ["zune"], overrides: SILVER_SCROLLDOWN },
    embedded: { folders: ["embedded"], overrides: SILVER_SCROLLDOWN },
  };

  const SPECIAL_FOLDER_KINDS = {
    "My Documents": "documents",
    "My Pictures": "pictures",
    "My Music": "music",
    "My Videos": "videos",
  };

  const SHELL_VALUE_NAMES = {
    documents: "Personal",
    pictures: "My Pictures",
    music: "My Music",
    videos: "My Video",
    desktop: "Desktop",
  };

  const DIR_SERVICE_KEYS = {
    documents: ["Pers", "Docs"],
    pictures: ["Pict"],
    music: ["Music"],
    videos: ["Vids"],
    desktop: ["Desk"],
  };

  const SUBFOLDER_NAMES = {
    documents: ["Documents", "My Documents"],
    pictures: ["Pictures", "My Pictures"],
    music: ["Music", "My Music"],
    videos: ["Videos", "My Videos"],
    desktop: ["Desktop"],
  };

  let sidebar;
  let companionPanel;
  let cameFromView = "main";
  let roverMenuCameFrom = "main";
  let currentViewName = "main";
  let isCharacterOff = false;
  let isBalloonTipsOff = false;
  let isAutoCompleteOff = false;
  let characterAnimPlaying = false;
  let roverBalloonEl = null;

  function h(tag, className, text) {
    const el = document.createElementNS(HTML_NS, tag);
    if (className) el.className = className;
    if (text != null) el.textContent = text;
    return el;
  }

  function createInput(className, type = "text") {
    const input = h("input", className);
    input.type = type;
    return input;
  }

  function createTextarea(className, value) {
    const textarea = h("textarea", className);
    textarea.value = value;
    return textarea;
  }

  function playVideo(video) {
    video.play()?.catch(() => {});
  }

  function formatTodayDDMMYYYY() {
    const now = new Date();
    const day = String(now.getDate()).padStart(2, "0");
    const month = String(now.getMonth() + 1).padStart(2, "0");
    return `${day}/${month}/${now.getFullYear()}`;
  }

  function newLocalFile(path) {
    const file = Components.classes["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
    file.initWithPath(path);
    return file;
  }

  function getExistingDrives() {
    const drives = [];
    for (const letter of DRIVE_LETTERS) {
      try {
        const file = newLocalFile(`${letter}:\\`);
        if (file.exists()) drives.push({ letter: `${letter}:`, file });
      } catch (e) {}
    }
    return drives;
  }

  function getMozIconUrl(path, size = 16) {
    try {
      return `moz-icon://${Services.io.newFileURI(newLocalFile(path)).spec}?size=${size}`;
    } catch (e) {
      return "";
    }
  }

  const imgUrlCache = new Map();

  function getChromeImgUrl(fileNames) {
    const names = [].concat(fileNames);
    const cacheKey = names.join("|");
    if (imgUrlCache.has(cacheKey)) return imgUrlCache.get(cacheKey);

    for (const fileName of names) {
      try {
        const file = Services.dirsvc.get("ProfD", Ci.nsIFile);
        file.append("chrome");
        file.append("images");
        fileName.split("/").forEach((segment) => file.append(segment));
        if (file.exists()) {
          const url = Services.io.newFileURI(file).spec;
          imgUrlCache.set(cacheKey, url);
          return url;
        }
      } catch (e) {}
    }
    return "";
  }

  const searchImg = (name) => getChromeImgUrl(["search/" + name, name]);
  const roverUrl = (fileName) => getChromeImgUrl(["search/animations/rover/" + fileName]);

  function getSchemeImgUrl(name) {
    const scheme = document.documentElement.getAttribute("ie6-colorscheme") || "luna";
    const rule = SCHEME_IMAGE_RULES[scheme];
    const folders = rule ? rule.overrides?.[name] || rule.folders : [];

    for (const folder of folders) {
      const url = getChromeImgUrl([folder + "/" + name]);
      if (url) return url;
    }
    return searchImg(name);
  }

  const sidebarQuery = (selector) => sidebar?.querySelector(selector) ?? null;
  const getCharacterVideo = () => sidebarQuery(".sc-rover-video");
  const getCharacterImg = () => sidebarQuery(".sc-rover-img");
  const getCharacterWrap = () => sidebarQuery(".sc-rover-wrap");

  function hideRoverBalloon() {
    roverBalloonEl?.remove();
    roverBalloonEl = null;
  }

  function showRoverBalloon(anchorEl, text) {
    hideRoverBalloon();
    if (!anchorEl) return;

    roverBalloonEl = h("div", "sc-character-balloon", text);
    document.documentElement.appendChild(roverBalloonEl);

    const updatePos = () => {
      if (!roverBalloonEl || !anchorEl.ownerDocument) return;
      const rect = anchorEl.getBoundingClientRect();
      if (rect.width === 0 && rect.height === 0) {
        hideRoverBalloon();
        return;
      }
      roverBalloonEl.style.left = `${rect.right + 6}px`;
      roverBalloonEl.style.top = `${rect.top - 10}px`;
    };

    updatePos();
    requestAnimationFrame(updatePos);
  }

  function showCharacterIdle() {
    const video = getCharacterVideo();
    const img = getCharacterImg();

    if (video) {
      video.pause();
      video.hidden = true;
      video.removeAttribute("src");
      video.load();
    }
    if (img) {
      const url = roverUrl("idle.png");
      if (url) img.src = url;
      img.hidden = false;
    }
  }

  function playCharacterVideo(fileName, { loop = false, onEnded = null } = {}) {
    const video = getCharacterVideo();
    const img = getCharacterImg();
    if (!video) return;

    if (video._onEndedHandler) {
      video.removeEventListener("ended", video._onEndedHandler);
      video._onEndedHandler = null;
    }

    if (img) img.hidden = true;
    video.hidden = false;
    video.loop = loop;

    const url = roverUrl(fileName);
    if (url) video.src = url;

    if (!loop && onEnded) {
      const handler = () => {
        video.removeEventListener("ended", handler);
        video._onEndedHandler = null;
        onEnded();
      };
      video._onEndedHandler = handler;
      video.addEventListener("ended", handler);
    }

    playVideo(video);
  }

  const characterToggleLabel = () =>
    isCharacterOff ? "Turn on animated character" : "Turn off animated character";

  function updateCharacterVisibility() {
    const speechBubble = sidebarQuery(".sc-speech-bubble");
    if (speechBubble) speechBubble.hidden = isCharacterOff;

    const wrap = getCharacterWrap();
    if (wrap && !characterAnimPlaying) {
      wrap.hidden = isCharacterOff;
      if (!isCharacterOff) showCharacterIdle();
    }

    document.querySelectorAll(".sc-toggle-character-text").forEach((span) => {
      span.textContent = characterToggleLabel();
    });
  }

  function toggleCharacter() {
    isCharacterOff = !isCharacterOff;

    const wrap = getCharacterWrap();
    if (!wrap) {
      updateCharacterVisibility();
      return;
    }

    characterAnimPlaying = true;
    wrap.hidden = false;

    playCharacterVideo(isCharacterOff ? "hide.webm" : "arrive.webm", {
      onEnded: () => {
        characterAnimPlaying = false;
        if (isCharacterOff) wrap.hidden = true;
        else showCharacterIdle();
      },
    });

    updateCharacterVisibility();
  }

  function playOneShotAnimation(fileName) {
    const wrap = getCharacterWrap();
    if (isCharacterOff || !wrap) return;

    characterAnimPlaying = true;
    wrap.hidden = false;
    playCharacterVideo(fileName, {
      onEnded: () => {
        characterAnimPlaying = false;
        showCharacterIdle();
      },
    });
  }

  function playSearchStartAnimation() {
    const wrap = getCharacterWrap();
    if (isCharacterOff || !wrap) return;

    characterAnimPlaying = true;
    wrap.hidden = false;
    playCharacterVideo("start-search.webm", {
      onEnded: () => playCharacterVideo("searching.webm", { loop: true }),
    });
  }

  const playSearchStopAnimation = () => playOneShotAnimation("stop-search.webm");

  const playCharacterTrick = () =>
    playOneShotAnimation(`trick${1 + Math.floor(Math.random() * ROVER_TRICK_COUNT)}.webm`);

  function createSelect(options, initialValue) {
    const el = h("div", "sc-select");
    el.tabIndex = 0;

    const icon = h("img", "sc-select-icon");
    const text = h("span", "sc-select-text");
    const content = h("div", "sc-select-content");
    content.append(icon, text);

    const dropMarker = h("img", "sc-dropmarker");
    let isHovering = false;

    const refreshDropMarker = () => {
      const url = getSchemeImgUrl(isHovering ? "scrolldownhover.png" : "scrolldown.png");
      if (url) dropMarker.src = url;
    };
    refreshDropMarker();

    el.addEventListener("mouseenter", () => {
      isHovering = true;
      refreshDropMarker();
    });
    el.addEventListener("mouseleave", () => {
      isHovering = false;
      refreshDropMarker();
    });

    const schemeObserver = new MutationObserver(() => {
      if (el.isConnected) refreshDropMarker();
      else schemeObserver.disconnect();
    });
    schemeObserver.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["ie6-colorscheme"],
    });

    el.append(content, dropMarker);

    const dropdown = h("div", "sc-dropdown");
    dropdown.hidden = true;
    document.body.appendChild(dropdown);

    const items = [];
    let currentIndex = 0;

    const setHighlight = (index) => items.forEach((item, i) => item.classList.toggle("selected", i === index));

    function selectOption(index) {
      currentIndex = index;
      const opt = options[index];
      text.textContent = opt.label;
      icon.hidden = !opt.icon;
      if (opt.icon) icon.src = opt.icon;
      dropdown.hidden = true;
    }

    options.forEach((opt, index) => {
      const item = h("div", "sc-dropdown-item");
      if (opt.icon) {
        const itemIcon = h("img", "sc-select-icon");
        itemIcon.src = opt.icon;
        item.appendChild(itemIcon);
      }
      item.appendChild(h("span", null, opt.label));
      items.push(item);

      item.addEventListener("mouseenter", () => setHighlight(index));
      item.addEventListener("click", (e) => {
        e.stopPropagation();
        selectOption(index);
        el.focus();
      });
      dropdown.appendChild(item);
    });

    el.addEventListener("click", (e) => {
      e.stopPropagation();
      if (!dropdown.hidden) {
        dropdown.hidden = true;
        return;
      }

      document.querySelectorAll(".sc-dropdown").forEach((d) => (d.hidden = true));

      const rect = el.getBoundingClientRect();
      dropdown.style.top = `${rect.bottom}px`;
      dropdown.style.left = `${rect.left}px`;
      dropdown.style.width = `${rect.width}px`;
      dropdown.hidden = false;
      setHighlight(currentIndex);
    });

    const onWindowClick = () => {
      if (el.isConnected) {
        dropdown.hidden = true;
        return;
      }
      dropdown.remove();
      schemeObserver.disconnect();
      window.removeEventListener("click", onWindowClick);
    };
    window.addEventListener("click", onWindowClick);

    selectOption(Math.max(0, options.findIndex((o) => o.value === initialValue)));

    return {
      el,
      get value() {
        return options[currentIndex].value;
      },
    };
  }

  function addSelect(parent, containerClass, options, initialValue) {
    const container = h("div", containerClass);
    const select = createSelect(options, initialValue);
    container.appendChild(select.el);
    parent.appendChild(container);
    return select;
  }

  function getLookInOptions() {
    const options = [
      { label: "My Computer", value: "My Computer", icon: searchImg("computer.png") },
      { label: "My Documents", value: "My Documents", icon: searchImg("mydocuments.png") },
      { label: "My Pictures", value: "My Pictures", icon: searchImg("mypictures.png") },
      { label: "My Music", value: "My Music", icon: searchImg("mymusic.png") },
      { label: "My Videos", value: "My Videos", icon: searchImg("myvideos.png") },
    ];

    const driveIcon = searchImg("drive.png");
    for (const { letter } of getExistingDrives()) {
      options.push({ label: `Local Hard Drives (${letter})`, value: letter, icon: driveIcon });
    }
    return options;
  }

  function getWindowsShellFolder(valueName) {
    if (!valueName) return null;
    try {
      const regKey = Components.classes["@mozilla.org/windows-registry-key;1"].createInstance(Ci.nsIWindowsRegKey);
      regKey.open(
        Ci.nsIWindowsRegKey.ROOT_KEY_CURRENT_USER,
        "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders",
        Ci.nsIWindowsRegKey.ACCESS_READ
      );
      const path = regKey.hasValue(valueName) ? regKey.readStringValue(valueName) : null;
      regKey.close();

      if (path) {
        const file = newLocalFile(path);
        if (file.exists()) return file;
      }
    } catch (e) {}

    return null;
  }

  function findChildFolder(base, names) {
    for (const name of names) {
      try {
        const dir = base.clone();
        dir.append(name);
        if (dir.exists()) return dir;
      } catch (e) {}
    }
    return null;
  }

  function getSpecialFolder(kind) {
    const shellFolder = getWindowsShellFolder(SHELL_VALUE_NAMES[kind]);
    if (shellFolder) return shellFolder;

    for (const key of DIR_SERVICE_KEYS[kind] || []) {
      try {
        const dir = Services.dirsvc.get(key, Ci.nsIFile);
        if (dir?.exists()) return dir;
      } catch (e) {}
    }

    try {
      const subfolders = SUBFOLDER_NAMES[kind] || [];
      const inHome = findChildFolder(Services.dirsvc.get("Home", Ci.nsIFile), subfolders);
      if (inHome) return inHome;

      if (kind !== "documents" && kind !== "desktop") {
        const documentsDir = getSpecialFolder("documents");
        if (documentsDir) return findChildFolder(documentsDir, subfolders);
      }
    } catch (e) {}

    return null;
  }

  function resolveLookInRoots(lookInValue) {
    if (lookInValue === "My Computer") {
      const roots = [];

      try {
        const home = Services.dirsvc.get("Home", Ci.nsIFile);
        if (home?.exists()) roots.push(home);
      } catch (e) {}

      getExistingDrives().forEach(({ file }) => roots.push(file));
      return roots;
    }

    const kind = SPECIAL_FOLDER_KINDS[lookInValue];
    if (kind) {
      const folder = getSpecialFolder(kind);
      return folder ? [folder] : [];
    }

    try {
      const file = newLocalFile(lookInValue + "\\");
      if (file.exists()) return [file];
    } catch (e) {}

    return [];
  }

  function parseDateInput(str) {
    const match = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec((str || "").trim());
    if (!match) return null;
    const date = new Date(Number(match[3]), Number(match[2]) - 1, Number(match[1]));
    return isNaN(date.getTime()) ? null : date;
  }

  function computeDateRange(mode, fromStr, toStr) {
    const DAY_MS = 24 * 60 * 60 * 1000;
    const now = Date.now();

    if (mode === "last_week") return { start: now - 7 * DAY_MS, end: now };

    if (mode === "past_month") {
      const d = new Date();
      d.setMonth(d.getMonth() - 1);
      return { start: d.getTime(), end: now };
    }

    if (mode === "past_year") {
      const d = new Date();
      d.setFullYear(d.getFullYear() - 1);
      return { start: d.getTime(), end: now };
    }

    if (mode === "specify_dates") {
      const from = parseDateInput(fromStr);
      const to = parseDateInput(toStr);
      if (to) to.setHours(23, 59, 59, 999);
      const start = from ? from.getTime() : null;
      const end = to ? to.getTime() : null;
      return start == null && end == null ? null : { start, end };
    }

    return null;
  }

  function computeSizeFilter(mode, direction, specifyValueStr) {
    if (mode === "small") return { type: "lt", valueKB: 100 };
    if (mode === "medium") return { type: "lt", valueKB: 1024 };
    if (mode === "large") return { type: "gt", valueKB: 1024 };

    if (mode === "specify") {
      const valueKB = Number(specifyValueStr);
      if (!isFinite(valueKB) || valueKB < 0) return null;
      return { type: direction === "at_most" ? "lte" : "gte", valueKB };
    }

    return null;
  }

  function getAccessedTime(path) {
    try {
      return newLocalFile(path).lastAccessedTime;
    } catch (e) {
      return null;
    }
  }

  function matchesDateFilter(filter, info, path) {
    let timestamp = info.lastModified;
    if (filter.type === "created") {
      if (info.creationTime != null) timestamp = info.creationTime;
    } else if (filter.type === "accessed") {
      const accessed = getAccessedTime(path);
      if (accessed != null) timestamp = accessed;
    }

    if (filter.start != null && timestamp < filter.start) return false;
    if (filter.end != null && timestamp > filter.end) return false;
    return true;
  }

  function matchesSizeFilter(filter, sizeBytes) {
    const sizeKB = sizeBytes != null ? sizeBytes / 1024 : 0;
    switch (filter.type) {
      case "lt": return sizeKB < filter.valueKB;
      case "gt": return sizeKB > filter.valueKB;
      case "lte": return sizeKB <= filter.valueKB;
      case "gte": return sizeKB >= filter.valueKB;
      default: return false;
    }
  }

  async function searchFiles({ roots, extensions, namePattern, contentPattern, dateFilter, sizeFilter }) {
    const results = [];
    const startTime = Date.now();
    let scanned = 0;
    let truncated = false;

    const nameNeedle = (namePattern || "").toLowerCase();
    const contentNeedle = (contentPattern || "").toLowerCase();
    const hasDateFilter = !!(dateFilter && (dateFilter.start != null || dateFilter.end != null));

    const queue = roots.map((f) => f.path);
    let queueIndex = 0;

    while (queueIndex < queue.length && results.length < SEARCH_MAX_RESULTS) {
      if (Date.now() - startTime > SEARCH_TIME_BUDGET_MS || scanned > SEARCH_MAX_ENTRIES) {
        truncated = true;
        break;
      }

      let children;
      try {
        children = await IOUtils.getChildren(queue[queueIndex++]);
      } catch (e) {
        continue;
      }

      for (const childPath of children) {
        scanned++;
        if (scanned > SEARCH_MAX_ENTRIES) {
          truncated = true;
          break;
        }

        let info;
        try {
          info = await IOUtils.stat(childPath);
        } catch (e) {
          continue;
        }

        const fileName = childPath.split(/[\\/]/).pop();
        const lowerName = fileName.toLowerCase();

        if (info.type === "directory") {
          if (SEARCH_SKIP_DIRS.has(lowerName)) continue;
          queue.push(childPath);

          if (extensions === null && !contentNeedle && !sizeFilter) {
            const nameOk = !nameNeedle || lowerName.includes(nameNeedle);
            const dateOk = !hasDateFilter || matchesDateFilter(dateFilter, info, childPath);
            if (nameOk && dateOk) {
              results.push({ name: fileName, path: childPath, sizeKB: null, ext: "", isDirectory: true });
            }
          }
          continue;
        }

        const dotIndex = fileName.lastIndexOf(".");
        const ext = dotIndex !== -1 ? fileName.substring(dotIndex + 1).toLowerCase() : "";
        if (extensions && !extensions.has(ext)) continue;

        if (nameNeedle && !lowerName.includes(nameNeedle)) continue;
        if (contentNeedle && !lowerName.includes(contentNeedle)) continue;
        if (hasDateFilter && !matchesDateFilter(dateFilter, info, childPath)) continue;
        if (sizeFilter && !matchesSizeFilter(sizeFilter, info.size)) continue;

        results.push({
          name: fileName,
          path: childPath,
          sizeKB: info.size != null ? Math.round(info.size / 1024) : null,
          ext,
        });

        if (results.length >= SEARCH_MAX_RESULTS) break;
      }
    }

    return { results, truncated };
  }

  async function runSearch({ query, location, backView, searchOptions }) {
    playSearchStartAnimation();
    renderView("searching", {
      query,
      location,
      includeSubfolders: true,
      includeSystem: true,
      includeHidden: false,
    });

    let searchResult;
    try {
      searchResult = await searchFiles(searchOptions);
    } catch (e) {
      searchResult = { results: [], truncated: false };
    }

    playSearchStopAnimation();
    renderView("mediaResults", { ...searchResult, backView });
  }

  function addDivider(parent, text) {
    parent.appendChild(h("div", "sc-samplelabel sc-divider", text));
  }

  function addLinkRow(parent, iconUrl, label, { spaced = false, textClass = null, onClick = null } = {}) {
    const row = h("div", "sc-linkrow" + (spaced ? " sc-linkrow-spaced" : ""));
    const icon = h("img", "sc-linkicon");
    if (iconUrl) icon.src = iconUrl;
    const text = h("span", textClass, label);
    row.append(icon, text);
    if (onClick) row.addEventListener("click", onClick);
    parent.appendChild(row);
    return { row, text };
  }

  function addToggleCharacterRow(parent, iconUrl, spaced = false) {
    return addLinkRow(parent, iconUrl, characterToggleLabel(), {
      spaced,
      textClass: "sc-toggle-character-text",
      onClick: toggleCharacter,
    });
  }

  function addButtonRow(parent, buttons, className = "sc-btnrow") {
    const row = h("div", className);
    for (const [label, onClick] of buttons) {
      const button = h("button", "sc-btn", label);
      if (onClick) button.addEventListener("click", onClick);
      row.appendChild(button);
    }
    parent.appendChild(row);
    return row;
  }

  const addOkCancelRow = (parent, onCancel, onOk) =>
    addButtonRow(parent, [["OK", onOk], ["Cancel", onCancel]], OK_CANCEL_ROW);

  function addRadioGroup(parent, name, options, { spaced = false, onChange = null } = {}) {
    const entries = options.map((opt) => {
      const label = h("label", "sc-linkrow" + (spaced ? " sc-linkrow-spaced" : ""));
      const radio = createInput("sc-radio", "radio");
      radio.name = name;
      radio.checked = !!opt.checked;
      const span = h("span", null, opt.label);
      label.append(radio, span);
      parent.appendChild(label);
      return { radio, span, value: opt.value };
    });

    const refreshBold = () => {
      entries.forEach(({ radio, span }) => span.classList.toggle("sc-bold", radio.checked));
    };
    refreshBold();

    entries.forEach(({ radio, value }) => {
      radio.addEventListener("change", () => {
        refreshBold();
        onChange?.(value);
      });
    });

    return {
      getValue: () => entries.find(({ radio }) => radio.checked)?.value,
    };
  }

  function addCheckbox(parent, label, { checked = false, boldWhenChecked = false } = {}) {
    const row = h("label", "sc-linkrow");
    const checkbox = createInput("sc-checkbox", "checkbox");
    checkbox.checked = checked;
    const span = h("span", null, label);

    if (boldWhenChecked) {
      span.classList.toggle("sc-bold", checked);
      checkbox.addEventListener("change", () => span.classList.toggle("sc-bold", checkbox.checked));
    }

    row.append(checkbox, span);
    parent.appendChild(row);
    return checkbox;
  }

  function addFileFields(panel) {
    const fileNameInput = createInput("sc-input");
    const fileContentInput = createInput("sc-input");

    panel.append(
      h("div", "sc-label", "All or part of the file name:"),
      fileNameInput,
      h("div", "sc-label", "A word or phrase in the file:"),
      fileContentInput,
      h("div", "sc-label", "Look in:")
    );
    const lookInSelect = addSelect(panel, "sc-lookin", getLookInOptions(), "My Computer");

    return { fileNameInput, fileContentInput, lookInSelect };
  }

  function addSearchCriteria(panel, idPrefix) {
    const dropMarkerDownUrl = getSchemeImgUrl("dropmarker.png");
    const dropMarkerUpUrl = getSchemeImgUrl("dropmarker-up.png");

    function addCategory(title) {
      const row = h("div", "sc-category-row");
      const dropImg = h("img", "sc-category-dropmarker");
      if (dropMarkerDownUrl) dropImg.src = dropMarkerDownUrl;
      row.append(h("span", "sc-category-title", title), dropImg);

      const content = h("div", "sc-category-content");
      content.hidden = true;
      panel.append(row, content);

      row.addEventListener("click", () => {
        content.hidden = !content.hidden;
        const url = content.hidden ? dropMarkerDownUrl : dropMarkerUpUrl;
        if (url) dropImg.src = url;
      });

      return content;
    }

    const dateContent = addCategory("When was it modified?");
    const dateControls = h("div", "sc-date-controls");

    const dateTypeSelect = addSelect(
      dateControls,
      "sc-date-type",
      [
        { label: "Modified Date", value: "modified" },
        { label: "Created Date", value: "created" },
        { label: "Accessed Date", value: "accessed" },
      ],
      "modified"
    );

    const addDateInput = (label) => {
      const input = createInput("sc-input sc-date-input");
      input.value = formatTodayDDMMYYYY();
      input.disabled = true;
      const row = h("div", "sc-date-row");
      row.append(h("span", "sc-date-label", label), input);
      dateControls.appendChild(row);
      return input;
    };
    const fromInput = addDateInput("from");
    const toInput = addDateInput("to");

    const dateRadios = addRadioGroup(
      dateContent,
      `${idPrefix}_modified_time`,
      [
        { label: "Don't remember", checked: true, value: "dont_remember" },
        { label: "Within the last week", value: "last_week" },
        { label: "Past month", value: "past_month" },
        { label: "Within the past year", value: "past_year" },
        { label: "Specify dates", value: "specify_dates" },
      ],
      {
        onChange: (value) => {
          const isSpecify = value === "specify_dates";
          fromInput.disabled = !isSpecify;
          toInput.disabled = !isSpecify;
          dateControls.classList.toggle("enabled", isSpecify);
        },
      }
    );
    dateContent.appendChild(dateControls);

    const sizeContent = addCategory("What size is it?");
    const sizeControls = h("div", "sc-size-controls");

    const sizeDirectionSelect = addSelect(
      sizeControls,
      "sc-size-select",
      [
        { label: "at least", value: "at_least" },
        { label: "at most", value: "at_most" },
      ],
      "at_least"
    );

    const sizeInput = createInput("sc-input sc-size-input", "number");
    sizeInput.value = "0";
    sizeInput.disabled = true;
    sizeControls.appendChild(sizeInput);

    const sizeRadios = addRadioGroup(
      sizeContent,
      `${idPrefix}_file_size`,
      [
        { label: "Don't remember", checked: true, value: "dont_remember" },
        { label: "Small (less than 100 KB)", value: "small" },
        { label: "Medium (less than 1 MB)", value: "medium" },
        { label: "Large (more than 1 MB)", value: "large" },
        { label: "Specify size (in KB)", value: "specify" },
      ],
      {
        onChange: (value) => {
          const isSpecify = value === "specify";
          sizeInput.disabled = !isSpecify;
          sizeControls.classList.toggle("enabled", isSpecify);
        },
      }
    );
    sizeContent.appendChild(sizeControls);

    const advancedContent = addCategory("More advanced options");
    [
      "Search system folders",
      "Search hidden files and folders",
      "Search subfolders",
      "Case sensitive",
      "Search tape backup",
    ].forEach((label) => addCheckbox(advancedContent, label, { boldWhenChecked: true }));

    return {
      getDateFilter() {
        const mode = dateRadios.getValue() || "dont_remember";
        const type = mode === "specify_dates" ? dateTypeSelect.value : "modified";
        const range = computeDateRange(mode, fromInput.value, toInput.value);
        return range ? { type, start: range.start, end: range.end } : null;
      },
      getSizeFilter() {
        return computeSizeFilter(sizeRadios.getValue() || "dont_remember", sizeDirectionSelect.value, sizeInput.value);
      },
    };
  }

  const VIEWS = {
    main(panel) {
      const queryBox = createTextarea("sc-querybox", "Please type your query here, then press <Enter>.");
      panel.append(
        h("div", "sc-title", "What are you looking for?"),
        h("div", "sc-intro", "Type your question below. For best results, use complete sentences."),
        queryBox,
        h("div", "sc-samplelabel", "Sample question:")
      );

      setTimeout(() => {
        queryBox.focus();
        queryBox.select();
      }, 50);

      addLinkRow(panel, searchImg("go-small.png"), "Buy a book online");
      addDivider(panel, "You may also want to...");
      addLinkRow(panel, searchImg("searchcomputer.png"), "Search this computer for files", {
        onClick: () => renderView("files"),
      });
      addLinkRow(panel, searchImg("preferences.png"), "Change preferences", {
        onClick: () => {
          cameFromView = "main";
          renderView("prefs");
        },
      });
      addToggleCharacterRow(panel, searchImg("turnoff.png"));
      addButtonRow(panel, [["Search"]]);
    },

    files(panel) {
      const arrowIcon = searchImg("go-small.png");
      panel.appendChild(h("div", "sc-title", "What do you want to search for?"));

      addLinkRow(panel, arrowIcon, "Pictures, music, or video", { onClick: () => renderView("media") });
      addLinkRow(panel, arrowIcon, "Documents (word processing, spreadsheet, etc.)", {
        onClick: () => renderView("documents"),
      });
      addLinkRow(panel, arrowIcon, "All files and folders", { onClick: () => renderView("allfiles") });
      addLinkRow(panel, arrowIcon, "Computers or people", { onClick: () => renderView("computers") });
      addLinkRow(panel, searchImg("help.png"), "Information in Help and Support Center");

      addDivider(panel, "You may also want to...");
      addLinkRow(panel, searchImg("internetsearch.png"), "Search the Internet", {
        onClick: () => renderView("internet"),
      });
      addLinkRow(panel, searchImg("preferences.png"), "Change preferences", {
        onClick: () => {
          cameFromView = "files";
          renderView("prefs");
        },
      });
      addLinkRow(panel, searchImg("learn.png"), "Learn more about Search Companion");
      addToggleCharacterRow(panel, searchImg("turnoff.png"));
    },

    allfiles(panel) {
      panel.appendChild(h("div", "sc-title", "Search by any or all of the criteria below."));
      const { fileNameInput, fileContentInput, lookInSelect } = addFileFields(panel);
      const criteria = addSearchCriteria(panel, "allfiles");

      addButtonRow(panel, [
        ["Back", () => renderView("files")],
        [
          "Search",
          () =>
            runSearch({
              query: fileNameInput.value.trim() || "files",
              location: lookInSelect.value,
              backView: "allfiles",
              searchOptions: {
                roots: resolveLookInRoots(lookInSelect.value),
                extensions: null,
                namePattern: fileNameInput.value.trim(),
                contentPattern: fileContentInput.value.trim(),
                dateFilter: criteria.getDateFilter(),
                sizeFilter: criteria.getSizeFilter(),
              },
            }),
        ],
      ]);
    },

    documents(panel) {
      panel.append(
        h("div", "sc-title", "Search by any or all of the criteria below."),
        h("div", "sc-label", "Last time it was modified:")
      );

      const dateRadios = addRadioGroup(panel, "doc_modified_time", [
        { label: "Don't remember", checked: true, value: "dont_remember" },
        { label: "Within the last week", value: "last_week" },
        { label: "Past month", value: "past_month" },
        { label: "Within the past year", value: "past_year" },
      ]);

      const docNameInput = createInput("sc-input");
      panel.append(h("div", "sc-label", "All or part of the document name:"), docNameInput);

      addDivider(panel, "You may also want to...");
      addLinkRow(panel, searchImg("preferences.png"), "Use advanced search options", {
        onClick: () => renderView("allfiles"),
      });

      addButtonRow(panel, [
        ["Back", () => renderView("files")],
        [
          "Search",
          () => {
            const range = computeDateRange(dateRadios.getValue() || "dont_remember", "", "");
            const namePattern = docNameInput.value.trim();

            runSearch({
              query: namePattern || "document",
              location: "My Computer",
              backView: "documents",
              searchOptions: {
                roots: resolveLookInRoots("My Computer"),
                extensions: new Set(TEXT_DOCUMENT_EXTENSIONS),
                namePattern,
                contentPattern: "",
                dateFilter: range ? { type: "modified", start: range.start, end: range.end } : null,
                sizeFilter: null,
              },
            });
          },
        ],
      ]);
    },

    media(panel) {
      panel.append(
        h("div", "sc-title", "Search by any or all of the criteria below."),
        h("div", "sc-intro", "Which type of file?")
      );

      const mediaCheckboxes = [
        { label: "Pictures and Photos", key: "pictures" },
        { label: "Music", key: "music" },
        { label: "Video", key: "video" },
      ].map(({ label, key }) => ({ key, checkbox: addCheckbox(panel, label) }));

      const { fileNameInput, fileContentInput, lookInSelect } = addFileFields(panel);
      const criteria = addSearchCriteria(panel, "media");

      addButtonRow(panel, [
        ["Back", () => renderView("files")],
        [
          "Search",
          () => {
            const checkedKeys = mediaCheckboxes.filter((c) => c.checkbox.checked).map((c) => c.key);
            const activeKeys = checkedKeys.length ? checkedKeys : Object.keys(MEDIA_EXTENSIONS);

            runSearch({
              query: fileNameInput.value.trim() || "media",
              location: lookInSelect.value,
              backView: "media",
              searchOptions: {
                roots: resolveLookInRoots(lookInSelect.value),
                extensions: new Set(activeKeys.flatMap((key) => MEDIA_EXTENSIONS[key])),
                namePattern: fileNameInput.value.trim(),
                contentPattern: fileContentInput.value.trim(),
                dateFilter: criteria.getDateFilter(),
                sizeFilter: criteria.getSizeFilter(),
              },
            });
          },
        ],
      ]);
    },

    searching(panel, data) {
      const query = data?.query ? `"${data.query}"` : "files";
      const location = data?.location || "My Documents";
      const includeSubfolders = data?.includeSubfolders ?? true;
      const includeSystem = data?.includeSystem ?? true;
      const includeHidden = data?.includeHidden ?? false;

      const title = h("div", "sc-title sc-searching-title");
      title.append(
        document.createTextNode("Searching for files with "),
        h("span", "sc-searching-bold", query),
        document.createTextNode(" in the file name.")
      );

      const list = h("ul", "sc-searching-list");
      list.append(
        h("li", null, `- Looking in ${location}${includeSubfolders ? " and in subfolders" : ""}.`),
        h("li", null, `- ${includeSystem ? "Looking in" : "Not looking in"} system folders.`),
        h("li", null, `- ${includeHidden ? "Looking in" : "Not looking in"} hidden files and folders.`)
      );

      panel.append(title, list);
      addButtonRow(panel, [["Stop", () => renderView("files")]], "sc-btnrow sc-searching-btnrow");
    },

    mediaResults(panel, data) {
      const results = data?.results || [];
      const hasResults = results.length > 0;
      const backView = data?.backView || "media";
      const arrowIcon = searchImg("go-small.png");
      const addOption = (label, iconUrl, onClick) => addLinkRow(panel, iconUrl, label, { spaced: true, onClick });

      if (hasResults) {
        const plural = results.length === 1 ? "" : "s";
        panel.appendChild(
          h("div", "sc-title", `There were ${results.length} file${plural} found. Did you find what you wanted?`)
        );

        addOption("Yes, finished searching", arrowIcon, () => {
          hideSidebar();
          renderView("main");
        });
        addOption("Yes, but make future searches faster", arrowIcon, () => renderView("indexing"));
        addDivider(panel, "No, refine this search and...");
      } else {
        panel.append(
          h("div", "sc-title", "There were no files found that match your search criteria."),
          h("div", "sc-intro", "What would you like to do?")
        );
      }

      addOption("Change file name or keywords", arrowIcon, () => renderView(backView));
      addOption("Look in more locations", arrowIcon, () => renderView(backView));
      addOption("Change whether hidden and system files are included", arrowIcon, () => renderView(backView));
      addOption("Start a new search", searchImg("newsearch.png"), () => renderView("files"));

      if (hasResults) {
        addDivider(panel, "Results:");

        for (const file of results) {
          const { row } = addOption(file.name, getMozIconUrl(file.path, 16), () => {
            try {
              newLocalFile(file.path).reveal();
            } catch (e) {}
          });
          row.title = file.path;
        }
      }

      addButtonRow(panel, [["Back", () => renderView(backView)]]);
    },

    computers(panel) {
      const arrowIcon = searchImg("go-small.png");
      panel.appendChild(h("div", "sc-title", "What are you looking for?"));
      addLinkRow(panel, arrowIcon, "A computer on the network");
      addLinkRow(panel, arrowIcon, "People in your address book");

      addDivider(panel, "You may also want to...");
      addLinkRow(panel, searchImg("searchcomputer.png"), "Search the Internet", {
        onClick: () => renderView("internet"),
      });

      addButtonRow(panel, [["Back", () => renderView("files")]]);
    },

    prefs(panel) {
      const arrowIcon = searchImg("go-small.png");
      const addPref = (label, onClick) => addLinkRow(panel, arrowIcon, label, { spaced: true, onClick });
      const addTogglePref = (toggle, getLabel) => {
        const { text } = addPref(getLabel(), () => {
          toggle();
          text.textContent = getLabel();
        });
      };

      panel.appendChild(h("div", "sc-title", "How do you want to use Search Companion?"));

      addToggleCharacterRow(panel, arrowIcon, true);
      addPref("With a different character", () => {
        roverMenuCameFrom = "prefs";
        renderView("character");
      });
      addPref("Without Indexing Service", () => renderView("indexing"));
      addPref("Change files and folders search behavior", () => renderView("behavior"));
      addPref("Change Internet search behavior", () => renderView("internetBehavior"));
      addTogglePref(
        () => (isBalloonTipsOff = !isBalloonTipsOff),
        () => (isBalloonTipsOff ? "Show balloon tips" : "Don't show balloon tips")
      );
      addTogglePref(
        () => (isAutoCompleteOff = !isAutoCompleteOff),
        () => (isAutoCompleteOff ? "Turn AutoComplete on" : "Turn AutoComplete off")
      );

      addButtonRow(panel, [["Back", () => renderView(cameFromView)]]);
    },

    character(panel) {
      const goBack = () => {
        hideRoverBalloon();
        renderView(roverMenuCameFrom);
      };

      const charImg = h("img", "sc-character-img");
      charImg.hidden = true;

      const charVideo = h("video", "sc-character-video-preview");
      charVideo.muted = true;
      charVideo.playsInline = true;
      const greetUrl = roverUrl("greet.webm");
      if (greetUrl) charVideo.src = greetUrl;

      charVideo.addEventListener(
        "ended",
        () => {
          charVideo.hidden = true;
          const idleUrl = roverUrl("idle.png");
          if (idleUrl) charImg.src = idleUrl;
          charImg.hidden = false;
          if (currentViewName === "character") showRoverBalloon(charImg, ROVER_BALLOON_TEXT);
        },
        { once: true }
      );

      const charBox = h("div", "sc-character-box");
      charBox.append(h("div", "sc-character-titlebar", "Rover"), charImg, charVideo);
      addButtonRow(charBox, [["Back", goBack], ["Next"]], "sc-character-navrow");
      charBox.appendChild(h("div", "sc-character-desc", "Rover will help you sniff out what you're looking for."));

      panel.append(h("div", "sc-title", "Which character would you like to use?"), charBox);
      playVideo(charVideo);
      showRoverBalloon(charVideo, ROVER_BALLOON_TEXT);

      addOkCancelRow(panel, goBack, goBack);
    },

    indexing(panel) {
      panel.append(
        h("div", "sc-title", "Indexing Service"),
        h(
          "div",
          "sc-intro",
          "When Indexing Service is enabled, the files on your computer are indexed and maintained while your computer is idle so you can perform faster searches."
        ),
        h("div", "sc-title", "Indexing Service is currently enabled."),
        h("div", "sc-intro", "Do you want to enable Indexing Service?")
      );

      addRadioGroup(panel, "indexing_service_status", [
        { label: "Yes, enable Indexing Service.", checked: true },
        { label: "No, do not enable Indexing Service." },
      ]);

      addDivider(panel, "You may also want to...");
      addLinkRow(panel, searchImg("index.png"), "Change Indexing Service settings (Advanced)", { spaced: true });
      addLinkRow(panel, searchImg("help.png"), "Learn more about Indexing Service", { spaced: true });

      addOkCancelRow(panel, () => renderView("prefs"));
    },

    behavior(panel) {
      panel.appendChild(h("div", "sc-title", "Choose the default files and folders search behavior."));

      addRadioGroup(
        panel,
        "files_search_behavior",
        [
          { label: "Standard - includes step-by-step options that help you refine your search", checked: true },
          { label: "Advanced - includes options to manually enter search criteria. Recommended for advanced users only" },
        ],
        { spaced: true }
      );

      addOkCancelRow(panel, () => renderView("prefs"));
    },

    internetBehavior(panel) {
      panel.append(
        h("div", "sc-title", "Internet Search Behavior"),
        h("div", "sc-intro", "How do you want to search the Internet?")
      );

      addRadioGroup(
        panel,
        "internet_search_behavior",
        [
          {
            label: "With Search Companion - provides task suggestions and automatically sends your search to other search engines",
            checked: true,
          },
          { label: "With Classic Internet search" },
        ],
        { spaced: true }
      );

      panel.appendChild(h("div", "sc-label", "Select the default search engine:"));
      addSelect(
        panel,
        "sc-lookin",
        [
          { label: "MSN", value: "msn" },
          { label: "AltaVista", value: "altavista" },
          { label: "Google", value: "google" },
          { label: "Ask Jeeves", value: "askjeeves" },
          { label: "AlltheWeb", value: "alltheweb" },
          { label: "Teoma", value: "teoma" },
          { label: "Excite", value: "excite" },
          { label: "Overture", value: "overture" },
          { label: "Yahoo", value: "yahoo" },
          { label: "AOL Search", value: "aol" },
          { label: "Lycos", value: "lycos" },
          { label: "Encarta", value: "encarta" },
        ],
        "msn"
      );

      addOkCancelRow(panel, () => renderView("prefs"));
    },

    internet(panel) {
      const arrowIcon = searchImg("go-small.png");
      panel.appendChild(h("div", "sc-title", "What would you like to do?"));

      [
        "Find a legal document",
        "Find software reviews, instructions, etc.",
        "Automatically send your search to other search engines",
        "Highlight words on the results page",
      ].forEach((label) => addLinkRow(panel, arrowIcon, label, { spaced: true }));

      addDivider(panel, "Change current search:");
      panel.appendChild(createTextarea("sc-changesearch", ""));
      addLinkRow(panel, searchImg("newsearch.png"), "Start a new search");

      addButtonRow(panel, [["Back", () => renderView("files")], ["Search"]]);
    },

    roverMenu(panel) {
      const arrowIcon = searchImg("go-small.png");
      panel.append(
        h("div", "sc-title", "You rang?"),
        h("div", "sc-intro", "What would you like to do?")
      );

      addLinkRow(panel, arrowIcon, "Choose a different animated character", {
        spaced: true,
        onClick: () => renderView("character"),
      });
      addToggleCharacterRow(panel, arrowIcon, true);
      addLinkRow(panel, arrowIcon, "Do a trick", { spaced: true, onClick: playCharacterTrick });

      addButtonRow(panel, [["Back", () => renderView(roverMenuCameFrom)]]);
    },
  };

  function renderView(viewName, data) {
    currentViewName = viewName;
    if (viewName !== "character") hideRoverBalloon();

    companionPanel.replaceChildren();
    VIEWS[viewName]?.(companionPanel, data);

    updateCharacterVisibility();
  }

  function setSearchButtonOpen(isOpen) {
    const btn = document.getElementById("find-button");
    if (!btn) return;
    if (isOpen) btn.setAttribute("open", "true");
    else btn.removeAttribute("open");
  }

  function hideSidebar() {
    sidebar.hidden = true;
    hideRoverBalloon();
    setSearchButtonOpen(false);
  }

  function buildTitlebar() {
    const closeBtn = h("img", "sb-flatbtn sb-close-btn");
    const closeImg = getChromeImgUrl(["close.png"]);
    if (closeImg) closeBtn.src = closeImg;
    closeBtn.title = "Close";
    closeBtn.addEventListener("click", hideSidebar);

    const titlebar = h("div", "sb-titlebar");
    titlebar.append(h("span", null, "Search"), closeBtn);
    return titlebar;
  }

  function buildRover() {
    const wrap = h("div", "sc-rover-wrap");

    const img = h("img", "sc-rover-img");
    const idleUrl = roverUrl("idle.png");
    if (idleUrl) img.src = idleUrl;

    const video = h("video", "sc-rover-video");
    video.muted = true;
    video.playsInline = true;
    video.hidden = true;

    wrap.append(img, video);
    wrap.addEventListener("click", () => {
      if (isCharacterOff || currentViewName === "roverMenu") return;
      roverMenuCameFrom = currentViewName;
      renderView("roverMenu");
    });
    return wrap;
  }

  function ensureSidebar() {
    if (sidebar) return sidebar;

    sidebar = document.createXULElement("vbox");
    sidebar.id = "ie6-search-sidebar";
    sidebar.className = "sb-panel";
    sidebar.hidden = true;

    companionPanel = h("div", "sc-panel");
    renderView("main");

    const content = h("div", "sc-content");
    content.append(companionPanel, h("div", "sc-speech-bubble"), buildRover());

    sidebar.append(buildTitlebar(), content);

    const browserBox = document.getElementById("browser");
    browserBox.insertBefore(sidebar, browserBox.firstChild);

    window.__ie6Sidebars ||= {
      panels: {},
      register(id, hideFn) {
        this.panels[id] = hideFn;
      },
      closeOthers(exceptId) {
        for (const [id, hideFn] of Object.entries(this.panels)) {
          if (id !== exceptId) hideFn();
        }
      },
    };
    window.__ie6Sidebars.register("search", hideSidebar);

    return sidebar;
  }

  function toggleSidebar() {
    ensureSidebar();
    if (!sidebar.hidden) return hideSidebar();

    window.__ie6Sidebars?.closeOthers("search");
    renderView("main");
    sidebar.hidden = false;
    setSearchButtonOpen(true);
  }

  window.ie6ToggleSearchSidebar = toggleSidebar;

  function init() {
    document.addEventListener(
      "command",
      (e) => {
        if (e.target.id !== "find-button") return;
        e.preventDefault();
        e.stopPropagation();
        toggleSidebar();
      },
      true
    );
  }

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();