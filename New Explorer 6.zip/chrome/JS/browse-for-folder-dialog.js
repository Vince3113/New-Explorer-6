(function () {
  const { PlacesUtils } = ChromeUtils.importESModule("resource://gre/modules/PlacesUtils.sys.mjs");

  const HTML_NS = "http://www.w3.org/1999/xhtml";
  const IMG = "resource://ie6theme/images/";
  const WINDOW_TYPE = "ie6-browse-for-folder-window";

  const WIDTH = 310;
  const HEIGHT = 330;

  const ROOTS = [
    { guid: PlacesUtils.bookmarks.toolbarGuid, label: "Favorites Bar" },
    { guid: PlacesUtils.bookmarks.unfiledGuid, label: "Other Favorites" },
  ];

  const args = window.arguments?.[0] || {};
  const parentWin = args.parentBrowserWin || Services.wm.getMostRecentWindow("navigator:browser");

  let selectedGuid = PlacesUtils.bookmarks.toolbarGuid;
  let selectedRow = null;

  const $ = (id) => document.getElementById(id);

  function h(tag, className) {
    const el = document.createElementNS(HTML_NS, tag);
    if (className) el.className = className;
    return el;
  }

  function label(text) {
    const el = h("span", "bf-label");
    el.textContent = text;
    return el;
  }

  function icon(name, className) {
    const img = h("img", className);
    img.src = IMG + name;
    return img;
  }

  function focusExistingInstance() {
    const windows = Services.wm.getEnumerator(WINDOW_TYPE);
    while (windows.hasMoreElements()) {
      const other = windows.getNext();
      if (other === window) continue;
      other.focus();
      window.close();
      return true;
    }
    return false;
  }

  function syncColorScheme() {
    if (!parentWin) return;
    try {
      const src = parentWin.document.documentElement;
      const apply = () => {
        const scheme = src.getAttribute("ie6-colorscheme");
        if (scheme) document.documentElement.setAttribute("ie6-colorscheme", scheme);
        else document.documentElement.removeAttribute("ie6-colorscheme");
      };
      apply();

      const observer = new parentWin.MutationObserver(apply);
      observer.observe(src, { attributes: true, attributeFilter: ["ie6-colorscheme"] });
      window.addEventListener("unload", () => observer.disconnect(), { once: true });
    } catch (e) {}
  }

  function closeWithParent() {
    if (!parentWin) return;
    const closeSelf = () => window.close();
    parentWin.addEventListener("unload", closeSelf, { once: true });
    window.addEventListener(
      "unload",
      () => {
        try {
          parentWin.removeEventListener("unload", closeSelf);
        } catch (e) {}
      },
      { once: true }
    );
  }

  const isFolder = (node) =>
    node.typeCode === PlacesUtils.bookmarks.TYPE_FOLDER ||
    node.type === PlacesUtils.TYPE_X_MOZ_PLACE_CONTAINER;

  const subFolders = (node) =>
    (node.children || []).filter((child) => isFolder(child) && child.guid !== args.selectedGuid);

  function selectRow(row, guid) {
    selectedRow?.classList.remove("selected");
    selectedRow = row;
    selectedGuid = guid;
    row.classList.add("selected");
  }

  function appendFolder(container, node, text) {
    const nodeEl = h("div", "bf-node");
    const row = h("div", "bf-row");
    row.append(icon("favourites-folder.png", "bf-icon"), label(text));
    nodeEl.append(row);

    if (node.guid === selectedGuid) {
      selectedRow = row;
      row.classList.add("selected");
    }
    row.addEventListener("click", (e) => {
      e.stopPropagation();
      selectRow(row, node.guid);
    });

    const folders = subFolders(node);
    if (folders.length) {
      const toggle = icon("expand.PNG", "bf-toggle");
      row.prepend(toggle);

      const childrenEl = h("div", "bf-children");
      childrenEl.hidden = true;
      nodeEl.append(childrenEl);
      for (const child of folders) appendFolder(childrenEl, child, child.title || "(unnamed)");

      toggle.addEventListener("click", (e) => {
        e.stopPropagation();
        childrenEl.hidden = !childrenEl.hidden;
        toggle.src = IMG + (childrenEl.hidden ? "expand.PNG" : "hide.PNG");
      });
    }

    container.append(nodeEl);
  }

  async function buildTree() {
    let trees;
    try {
      trees = await Promise.all(ROOTS.map((root) => PlacesUtils.promiseBookmarksTree(root.guid)));
    } catch (e) {
      return;
    }

    const rootRow = h("div", "bf-row");
    rootRow.append(icon("favorites-small.png", "bf-icon bf-icon-star"), label("Favorites"));
    const rootChildren = h("div", "bf-children bf-root-children");
    const rootNode = h("div", "bf-node bf-root");
    rootNode.append(rootRow, rootChildren);

    trees.forEach((tree, i) => appendFolder(rootChildren, tree, ROOTS[i].label));
    $("bf-tree").replaceChildren(rootNode);
  }

  function init() {
    window.resizeTo(WIDTH, HEIGHT);
    if (focusExistingInstance()) return;

    syncColorScheme();
    closeWithParent();

    $("bf-btn-cancel").addEventListener("click", () => window.close());
    $("bf-btn-ok").addEventListener("click", () => {
      args.callback?.(selectedGuid);
      window.close();
    });

    buildTree();
  }

  window.addEventListener("load", init, { once: true });
})();