(function () {
  "use strict";

  const HTML_NS = "http://www.w3.org/1999/xhtml";
  const SIDEBAR_ID = "ie6-research-sidebar";
  const IMG = "resource://ie6theme/images/";

  const MODES = [
    { label: "All Reference Books", value: "all" },
    { label: "Encyclopedia", value: "encyclopedia" },
    { label: "Thesaurus: English (U.S.)", value: "thesaurus" },
    { label: "Dictionary", value: "dictionary" },
    { label: "Translation", value: "translate" },
  ];

  const LANGS = [
    { label: "English (U.S.)", value: "en" },
    { label: "Spanish", value: "es" },
    { label: "French (France)", value: "fr" },
    { label: "German", value: "de" },
    { label: "Italian", value: "it" },
    { label: "Portuguese", value: "pt" },
    { label: "Russian", value: "ru" },
  ];

  const POS_LABELS = { n: "Noun", v: "Verb", adj: "Adjective", adv: "Adverb" };

  const BLOCK = { block: "rs-block", header: "rs-block-header", body: "rs-block-body" };
  const TREE = { block: "rs-block rs-block-tree", header: "rs-block-header", body: "rs-tree-body" };
  const GROUP = { block: "rs-group", header: "rs-group-header", body: "rs-group-body" };

  const ui = {};
  const selects = {};

  const state = {
    history: [{ status: "home", mode: "all", query: "" }],
    index: 0,
    ticket: 0,
  };

  function h(tag, className, text) {
    const el = document.createElementNS(HTML_NS, tag);
    if (className) el.className = className;
    if (text != null) el.textContent = text;
    return el;
  }

  function img(src, className) {
    const el = h("img", className);
    el.src = src;
    return el;
  }

  function link(className, text, onClick) {
    const a = h("a", className, text);
    a.href = "#";
    a.addEventListener("click", (e) => {
      e.preventDefault();
      onClick?.();
    });
    return a;
  }

  const stripTags = (html) => (html || "").replace(/<[^>]+>/g, "");

  const dropdownClosers = new Set();
  const closeDropdowns = () => dropdownClosers.forEach((close) => close());
  window.addEventListener("click", closeDropdowns);

  function createSelect(options, initialValue, { onChange, onEnter } = {}) {
    const el = h("div", "sb-select");
    el.tabIndex = 0;

    const text = h("span", "sb-select-text");
    el.append(text, h("div", "sb-dropmarker"));

    const menu = h("div", "sb-dropdown");
    menu.hidden = true;
    document.body.appendChild(menu);

    let current = Math.max(0, options.findIndex((o) => o.value === initialValue));
    let highlighted = current;

    const items = options.map((opt, i) => {
      const item = h("div", "sb-dropdown-item", opt.label);
      item.addEventListener("mouseenter", () => highlight(i));
      item.addEventListener("click", (e) => {
        e.stopPropagation();
        choose(i);
      });
      menu.appendChild(item);
      return item;
    });

    function show(i) {
      current = i;
      text.textContent = options[i].label;
    }

    function highlight(i) {
      highlighted = i;
      items.forEach((item, n) => item.classList.toggle("selected", n === i));
    }

    function setOpen(open) {
      menu.hidden = !open;
      if (!open) return;

      const rect = el.getBoundingClientRect();
      menu.style.top = `${rect.bottom}px`;
      menu.style.left = `${rect.left}px`;
      menu.style.width = `${rect.width}px`;
      highlight(current);
    }

    function choose(i) {
      show(i);
      setOpen(false);
      el.focus();
      onChange?.(options[i].value);
    }

    el.addEventListener("click", (e) => {
      e.stopPropagation();
      const wasOpen = !menu.hidden;
      closeDropdowns();
      setOpen(!wasOpen);
    });

    el.addEventListener("keydown", (e) => {
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        if (menu.hidden) return setOpen(true);
        const step = e.key === "ArrowDown" ? 1 : -1;
        highlight((highlighted + step + options.length) % options.length);
      } else if (e.key === "Enter") {
        e.preventDefault();
        if (!menu.hidden) choose(highlighted);
        else onEnter?.();
      } else if (e.key === "Escape") {
        e.preventDefault();
        setOpen(false);
      }
    });

    dropdownClosers.add(() => setOpen(false));
    show(current);

    return {
      el,
      get value() {
        return options[current].value;
      },
      set value(v) {
        const i = options.findIndex((o) => o.value === v);
        if (i !== -1) show(i);
      },
    };
  }

  async function getJSON(url) {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  }

  async function fetchEncyclopedia(query) {
    const found = await getJSON(
      `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&format=json&origin=*`
    );
    const hit = found.query?.search[0];
    if (!hit) throw new Error("No results found");

    const summary = await getJSON(
      `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(hit.title)}`
    );
    if (!summary.extract) throw new Error("No summary text");
    return { title: summary.title, text: summary.extract };
  }

  async function fetchThesaurus(word) {
    const w = encodeURIComponent(word);
    const [synonyms, antonyms] = await Promise.all([
      getJSON(`https://api.datamuse.com/words?rel_syn=${w}&md=p`),
      getJSON(`https://api.datamuse.com/words?rel_ant=${w}&md=p`).catch(() => []),
    ]);
    if (!synonyms.length && !antonyms.length) throw new Error("No results");
    return { synonyms, antonyms };
  }

  async function fetchDictionary(word) {
    const data = await getJSON(
      `https://en.wiktionary.org/api/rest_v1/page/definition/${encodeURIComponent(word)}`
    );
    if (!data || !Object.keys(data).length) throw new Error("Not found");
    return data;
  }

  async function fetchTranslation(text, from, to) {
    const pair = encodeURIComponent(`${from}|${to}`);
    const data = await getJSON(
      `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${pair}`
    );
    const translatedText = data?.responseData?.translatedText;
    if (!translatedText) throw new Error("No translation found");
    return { translatedText };
  }

  async function load(mode, query, langs) {
    switch (mode) {
      case "all": {
        const settled = await Promise.allSettled([
          fetchEncyclopedia(query),
          fetchThesaurus(query),
          fetchDictionary(query),
        ]);
        const [encyclopedia, thesaurus, dictionary] = settled.map((r) =>
          r.status === "fulfilled" ? r.value : null
        );
        if (!encyclopedia && !thesaurus && !dictionary) throw new Error("No results");
        return { encyclopedia, thesaurus, dictionary };
      }
      case "encyclopedia":
        return fetchEncyclopedia(query);
      case "thesaurus":
        return fetchThesaurus(query);
      case "dictionary":
        return fetchDictionary(query);
      case "translate":
        return fetchTranslation(query, langs.from, langs.to);
    }
    throw new Error(`Unknown mode: ${mode}`);
  }

  function collapsible(parts, title, children, open) {
    const block = h("div", parts.block);
    const header = h("div", parts.header);
    const toggle = h("div", "rs-toggle");
    const body = h("div", parts.body);

    header.append(toggle, h("span", null, title));
    body.append(...children);

    const render = () => {
      body.hidden = !open;
      toggle.classList.toggle("rs-open", open);
    };
    header.addEventListener("click", () => {
      open = !open;
      render();
    });
    render();

    block.append(header, body);
    return block;
  }

  const sectionBlock = (title, children) => collapsible(BLOCK, title, children, true);
  const treeSection = (title, children) => collapsible(TREE, title, children, true);
  const treeGroup = (title, nodes) => collapsible(GROUP, title, nodes, false);

  function encyclopediaBlock(query, data) {
    return treeSection("Encyclopedia", [
      treeGroup(data.title || query, [h("div", "rs-def", data.text)]),
    ]);
  }

  function thesaurusBlock(query, data) {
    const bySpeech = {};
    for (const item of data.synonyms) {
      const tag = (item.tags || []).find((t) => POS_LABELS[t]);
      const label = tag ? POS_LABELS[tag] : "Synonyms";
      (bySpeech[label] ||= []).push(item.word);
    }

    const wordItem = (word) => {
      const el = h("div", "rs-item", word);
      el.addEventListener("click", () => search(word, "thesaurus"));
      return el;
    };

    const groups = Object.entries(bySpeech).map(([pos, words]) =>
      treeGroup(`${query} (${pos}.)`, words.map(wordItem))
    );
    if (data.antonyms?.length) {
      groups.push(treeGroup(`${query} (Antonyms)`, data.antonyms.map((a) => wordItem(a.word))));
    }
    return treeSection("Thesaurus: English (U.S.)", groups);
  }

  function dictionaryBlock(query, data) {
    const groups = [];
    for (const entries of Object.values(data || {})) {
      for (const entry of entries || []) {
        if (!entry.definitions?.length) continue;
        const pos = entry.partOfSpeech ? ` (${entry.partOfSpeech}.)` : "";
        const defs = entry.definitions.map((d) => h("div", "rs-def", stripTags(d.definition)));
        groups.push(treeGroup(`${query}${pos}`, defs));
      }
    }
    return groups.length ? treeSection("Dictionary", groups) : null;
  }

  const BLOCK_BUILDERS = {
    encyclopedia: encyclopediaBlock,
    thesaurus: thesaurusBlock,
    dictionary: dictionaryBlock,
  };

  function resultBlocks(mode, query, data) {
    const entries = mode === "all" ? Object.entries(data) : [[mode, data]];
    return entries
      .filter(([, d]) => d)
      .map(([m, d]) => BLOCK_BUILDERS[m](query, d))
      .filter(Boolean);
  }

  function setResults(...nodes) {
    ui.results.replaceChildren(...nodes);
    ui.results.scrollTop = 0;
  }

  function renderHome() {
    setResults(
      h("label", "rs-hint", "Type text to look up in a variety of research and reference services."),
      h("label", "rs-hint", "You can also press ALT and click a word to start a search.")
    );
  }

  function renderNoResults(query) {
    const linkBox = h("div", "rs-linkbox");
    linkBox.append(
      img(IMG + "research/research-options.png", "rs-footer-icon"),
      link("rs-link", "All Reference Books", () => search(query, "all"))
    );

    setResults(
      sectionBlock("Can't find it?", [
        h("div", "rs-msg", "Try one of these alternatives or see Help for hints on refining your search."),
        h("div", "rs-subhead", "Other places to search"),
        h("div", null, `Search for '${query}' in:`),
        linkBox,
      ])
    );
  }

  function renderTranslate(query, translatedText) {
    ensureTranslateSelects();

    const options = h("div", "rs-translate-options");
    options.appendChild(link("rs-link", "Translation options..."));

    const children = [
      h("div", "rs-msg", "Translate a word or sentence."),
      h("label", "rs-label", "From:"),
      selects.from.el,
      h("label", "rs-label", "To:"),
      selects.to.el,
      options,
    ];
    if (query && translatedText) children.push(h("div", "rs-translation", translatedText));
    else if (query) children.push(h("div", "rs-hint", "No results were found."));

    setResults(sectionBlock("Translation", children));
  }

  function renderEntry(entry) {
    if (entry.status === "home") return renderHome();

    if (entry.mode === "translate") {
      ensureTranslateSelects();
      if (entry.from) selects.from.value = entry.from;
      if (entry.to) selects.to.value = entry.to;
      return renderTranslate(entry.query, entry.status === "ok" ? entry.data.translatedText : null);
    }

    if (entry.status !== "ok") return renderNoResults(entry.query);

    const blocks = resultBlocks(entry.mode, entry.query, entry.data);
    if (blocks.length) setResults(...blocks);
    else renderNoResults(entry.query);
  }

  function ensureTranslateSelects() {
    if (selects.from) return;
    const onChange = () => {
      const query = ui.input.value.trim();
      if (query) search(query, "translate");
      else renderTranslate("", null);
    };
    selects.from = createSelect(LANGS, "es", { onChange });
    selects.to = createSelect(LANGS, "en", { onChange });
  }

  async function search(presetQuery, presetMode) {
    ensureSidebar();

    const query = (presetQuery ?? ui.input.value).trim();
    if (!query) return;

    ui.input.value = query;
    if (presetMode) ui.mode.value = presetMode;
    const mode = ui.mode.value;

    let langs = null;
    if (mode === "translate") {
      ensureTranslateSelects();
      langs = { from: selects.from.value, to: selects.to.value };
    }

    const ticket = ++state.ticket;
    setResults(h("label", "rs-hint", "Searching..."));

    const entry = { status: "ok", mode, query, data: null, ...langs };
    try {
      entry.data = await load(mode, query, langs);
    } catch (e) {
      entry.status = "error";
    }

    if (ticket !== state.ticket) return;

    state.history = state.history.slice(0, state.index + 1);
    state.history.push(entry);
    state.index = state.history.length - 1;
    updateNav();
    renderEntry(entry);
  }

  function goHistory(delta) {
    const i = state.index + delta;
    if (i < 0 || i >= state.history.length) return;

    state.ticket++;
    state.index = i;

    const entry = state.history[i];
    ui.input.value = entry.query;
    ui.mode.value = entry.mode;
    renderEntry(entry);
    updateNav();
  }

  function updateNav() {
    ui.back.disabled = state.index <= 0;
    ui.fwd.disabled = state.index >= state.history.length - 1;
  }

  function navButton(className, title, onClick) {
    const btn = h("button", className);
    btn.type = "button";
    btn.title = title;
    btn.disabled = true;
    btn.addEventListener("click", onClick);
    return btn;
  }

  function footerLink(iconName, text) {
    const a = link("rs-footer-btn");
    a.append(img(IMG + iconName, "rs-footer-icon"), h("span", null, text));
    return a;
  }

  function buildTitlebar() {
    const close = img(IMG + "close.png", "sb-flatbtn sb-close-btn");
    close.title = "Close";
    close.addEventListener("click", () => setVisible(false));

    const titlebar = h("div", "sb-titlebar");
    titlebar.append(h("span", null, "Research"), close);
    return titlebar;
  }

  function buildForm() {
    ui.input = h("input", "rs-input");
    ui.input.type = "text";
    ui.input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") search();
    });

    const go = h("button", "rs-go");
    go.type = "button";
    go.title = "Start searching";
    go.addEventListener("click", () => search());

    const searchRow = h("div", "rs-searchrow");
    searchRow.append(ui.input, go);

    ui.mode = createSelect(MODES, "all", {
      onChange: (mode) => {
        if (mode === "translate") renderTranslate("", null);
        else if (!ui.input.value.trim()) renderHome();
      },
      onEnter: () => search(),
    });

    ui.back = navButton("rs-nav rs-back", "Back", () => goHistory(-1));
    ui.fwd = navButton("rs-nav rs-fwd", "Next", () => goHistory(1));
    const navRow = h("div", "rs-navrow");
    navRow.append(ui.back, ui.fwd);

    const form = h("div", "rs-form");
    form.append(h("label", "rs-label", "Search for:"), searchRow, ui.mode.el, navRow);
    return form;
  }

  function buildSidebar() {
    const sidebar = document.createXULElement("vbox");
    sidebar.id = SIDEBAR_ID;
    sidebar.className = "sb-panel";
    sidebar.hidden = true;

    const form = buildForm();

    ui.results = h("div", "rs-results");
    renderHome();
    const wrap = h("div", "rs-results-wrap");
    wrap.appendChild(ui.results);

    const footer = h("div", "rs-footer");
    footer.append(
      footerLink("research/services.png", "Get services on Office Marketplace"),
      footerLink("research/research-options.png", "Research options...")
    );

    const body = h("div", "rs-body");
    body.append(form, wrap, footer);

    sidebar.append(buildTitlebar(), body);
    return sidebar;
  }

  function ensureSidebar() {
    if (ui.sidebar) return ui.sidebar;

    ui.sidebar = buildSidebar();
    const browserBox = document.getElementById("browser");
    browserBox.insertBefore(ui.sidebar, browserBox.firstChild);

    window.__ie6Sidebars ||= {
      panels: {},
      register(id, hideFn) {
        this.panels[id] = hideFn;
      },
      closeOthers(exceptId) {
        for (const [id, hideFn] of Object.entries(this.panels)) {
          if (id !== exceptId) hideFn();
        }
      },
    };
    window.__ie6Sidebars.register(SIDEBAR_ID, () => setVisible(false));

    return ui.sidebar;
  }

  function setVisible(open) {
    const sidebar = ensureSidebar();
    if (open) window.__ie6Sidebars.closeOthers(SIDEBAR_ID);
    else closeDropdowns();
    sidebar.hidden = !open;
  }

  window.ie6ToggleResearchSidebar = (force) => {
    const sidebar = ensureSidebar();
    setVisible(typeof force === "boolean" ? force : sidebar.hidden);
  };

  window.ie6OpenResearchWithWord = (word, mode) => {
    setVisible(true);
    search(word, mode || "encyclopedia");
  };
})();