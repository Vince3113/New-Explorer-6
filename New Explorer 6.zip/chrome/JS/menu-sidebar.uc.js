(function () {
  const LOG = "[menu-sidebar]";

  const ITEMS = [
    { id: "ie6-sb-search", label: "Search", key: "S", fn: "ie6ToggleSearchSidebar" },
    { id: "ie6-sb-favorites", label: "Favorites", key: "F", fn: "ie6ToggleBookmarksSidebar" },
    { id: "ie6-sb-history", label: "History", key: "H", fn: "ie6ToggleHistorySidebar" },
    { id: "ie6-sb-folders", label: "Folders", key: "o", fn: "ie6ToggleFoldersSidebar" },
    { id: "ie6-sb-media", label: "Media", key: "M", fn: "ie6ToggleMediaSidebar" },
    { id: "ie6-sb-research", label: "Research", key: "R", fn: "ie6ToggleResearchSidebar" },
    { id: "ie6-sb-passwords", label: "Passwords", key: "P", fn: "ie6ToggleLoginsSidebar" },
    { id: "ie6-sb-account", label: "Account", key: "A", fn: "ie6ToggleAccountSidebar" },
  ];

  function findSidebarPopup() {
    for (const id of ["viewSidebarMenu", "viewSidebarMenuMenu"]) {
      const el = document.getElementById(id);
      if (!el) continue;
      const popup = el.localName === "menupopup" ? el : el.querySelector("menupopup");
      if (popup) return popup;
    }
    const viewPopup = document.getElementById("menu_viewPopup");
    for (const m of viewPopup?.querySelectorAll("menu") || []) {
      if (m.getAttribute("label") === "Sidebar") return m.querySelector("menupopup");
    }
    return null;
  }

  function openSidebar(fnName) {
    const fn = window[fnName];
    if (typeof fn !== "function") return;
    try {
      fn();
    } catch (e) {}
  }

  function collapseNative(popup) {
    for (const child of popup.children) {
      if (!child.classList.contains("ie6-sidebar-item")) child.setAttribute("collapsed", "true");
    }
  }

  function init() {
    const popup = findSidebarPopup();
    if (!popup || popup.querySelector(".ie6-sidebar-item")) return;

    for (const def of ITEMS) {
      const item = document.createXULElement("menuitem");
      item.id = def.id;
      item.className = "ie6-sidebar-item";
      item.setAttribute("label", def.label);
      item.setAttribute("accesskey", def.key);
      item.addEventListener("command", () => openSidebar(def.fn));
      popup.appendChild(item);
    }

    collapseNative(popup);
    popup.addEventListener("popupshowing", () => collapseNative(popup));
  }

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();