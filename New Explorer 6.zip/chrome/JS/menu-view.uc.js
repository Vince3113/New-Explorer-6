(function () {
  const LOG = "[menu-view]";

  const ORDER = {
    sidebar: -3,
    statusBar: -2,
    toolbars: -1,
    separator1: 3,
    goTo: 4,
    stop: 5,
    refresh: 6,
    separator2: 7,
    zoom: 8,
    pageStyle: 9,
    encoding: 10,
    separator3: 11,
    source: 12,
    privacyReport: 13,
    fullScreen: 14,
  };

  function makeItem(id, label, accesskey, order, command) {
    const item = document.createXULElement("menuitem");
    item.id = id;
    item.setAttribute("label", label);
    item.setAttribute("accesskey", accesskey);
    item.style.order = order;
    item.addEventListener("command", command);
    return item;
  }

  function makeSeparator(order) {
    const sep = document.createXULElement("menuseparator");
    sep.classList.add("ie6-view-sep");
    sep.style.order = order;
    return sep;
  }

  function makeEntry(label, { acceltext, disabled, checked, onCommand }) {
    const item = document.createXULElement("menuitem");
    item.setAttribute("label", label);
    if (acceltext) item.setAttribute("acceltext", acceltext);
    if (disabled) item.setAttribute("disabled", "true");
    if (checked !== undefined) {
      item.setAttribute("type", "checkbox");
      if (checked) item.setAttribute("checked", "true");
    }
    item.addEventListener("command", onCommand);
    return item;
  }

  function findExisting(popup, candidateIds, labelText) {
    for (const id of candidateIds) {
      const el = document.getElementById(id);
      if (el) return el;
    }
    for (const it of popup.querySelectorAll("menu, menuitem")) {
      if (it.getAttribute("label") === labelText) return it;
    }
    return null;
  }

  const asMenu = (el) => (el && el.localName === "menupopup" ? el.parentElement : el);

  function setOrder(el, order) {
    if (!el) return;
    el.style.order = order;
  }

  function attempt(action) {
    try {
      action();
    } catch (e) {}
  }

  function openSource() {
    attempt(() => {
      const url = window.gBrowser.selectedBrowser.currentURI.spec;
      if (!url) return;
      window.gBrowser.selectedTab = window.gBrowser.addTab("view-source:" + url, {
        triggeringPrincipal: Services.scriptSecurityManager.getSystemPrincipal(),
      });
    });
  }

  function fixEncoding() {
    const native = document.getElementById("repair-text-encoding");
    if (native && typeof native.doCommand === "function") native.doCommand();
  }

  function openPrivacyReport() {
    attempt(() => {
      const existing = Services.wm.getMostRecentWindow("ie6-privacy-report-window");
      if (existing) {
        existing.focus();
        return;
      }
      window.openDialog(
        "chrome://userscripts/content/privacy-report-window.xhtml",
        "",
        "chrome,dialog=yes,titlebar,centerscreen,dependent,resizable=no,minimizable=no"
      );
    });
  }

  const doRefresh = () => attempt(() => window.BrowserReload());
  const doStop = () => attempt(() => window.BrowserStop());
  const doBack = () => attempt(() => window.BrowserBack());
  const doForward = () => attempt(() => window.BrowserForward());
  const doHome = () => attempt(() => window.BrowserHome());

  function buildGoToPopup(popup) {
    const { gBrowser } = window;
    popup.replaceChildren(
      makeEntry("Back", { acceltext: "Alt+Left Arrow", disabled: !gBrowser.canGoBack, onCommand: doBack }),
      makeEntry("Forward", { acceltext: "Alt+Right Arrow", disabled: !gBrowser.canGoForward, onCommand: doForward }),
      document.createXULElement("menuseparator"),
      makeEntry("Home Page", { acceltext: "Alt+Home", onCommand: doHome })
    );

    try {
      const sessionHistory = gBrowser.selectedBrowser.browsingContext.sessionHistory;
      const count = sessionHistory ? sessionHistory.count : 0;
      if (count === 0) return;

      popup.appendChild(document.createXULElement("menuseparator"));
      for (let i = 0; i < count; i++) {
        const entry = sessionHistory.getEntryAtIndex(i);
        if (!entry) continue;
        popup.appendChild(
          makeEntry(entry.title || entry.URI.spec, {
            checked: i === sessionHistory.index,
            onCommand: () =>
              attempt(() => gBrowser.selectedBrowser.webNavigation.gotoIndex(i)),
          })
        );
      }
    } catch (e) {}
  }

  function createGoToMenu() {
    const menu = document.createXULElement("menu");
    menu.id = "ie6-view-goto";
    menu.setAttribute("label", "Go To");
    menu.setAttribute("accesskey", "G");
    menu.style.order = ORDER.goTo;

    const popup = document.createXULElement("menupopup");
    popup.id = "ie6-view-goto-popup";
    popup.addEventListener("popupshowing", () => buildGoToPopup(popup));
    menu.appendChild(popup);
    return menu;
  }

  function createStatusBarItem(popup) {
    const item = document.createXULElement("menuitem");
    item.id = "ie6-view-statusbar";
    item.setAttribute("type", "checkbox");
    item.setAttribute("autocheck", "false");
    item.setAttribute("label", "Status Bar");
    item.setAttribute("accesskey", "B");
    item.style.order = ORDER.statusBar;

    item.addEventListener("command", () => {
      const api = window.ie6StatusBar;
      if (!api) return;
      api.setHidden(api.isVisible());
    });

    popup.addEventListener("popupshowing", (e) => {
      if (e.target !== popup) return;
      if (window.ie6StatusBar?.isVisible()) item.setAttribute("checked", "true");
      else item.removeAttribute("checked");
    });
    return item;
  }

  function init() {
    const popup = document.getElementById("menu_viewPopup");
    if (!popup || document.getElementById("ie6-view-goto")) return;

    setOrder(asMenu(findExisting(popup, ["viewSidebarMenu"], "Sidebar")), ORDER.sidebar);
    setOrder(asMenu(findExisting(popup, ["viewToolbarsMenu"], "Toolbars")), ORDER.toolbars);
    setOrder(findExisting(popup, ["viewFullZoomMenu"], "Zoom"), ORDER.zoom);
    setOrder(findExisting(popup, ["pageStyleMenu"], "Page Style"), ORDER.pageStyle);
    setOrder(
      findExisting(popup, ["fullScreenItem", "menu_fullScreen"], "Full Screen"),
      ORDER.fullScreen
    );

    popup.append(
      createStatusBarItem(popup),
      createGoToMenu(),
      makeItem("ie6-view-stop", "Stop", "S", ORDER.stop, doStop),
      makeItem("ie6-view-refresh", "Refresh", "R", ORDER.refresh, doRefresh),
      makeItem("ie6-view-encoding", "Encoding", "n", ORDER.encoding, fixEncoding),
      makeItem("ie6-view-source", "Source", "c", ORDER.source, openSource),
      makeItem("ie6-view-privacyreport", "Privacy Report...", "P", ORDER.privacyReport, openPrivacyReport),
      makeSeparator(ORDER.separator1),
      makeSeparator(ORDER.separator2),
      makeSeparator(ORDER.separator3)
    );
  }

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();