(function () {
  const LOG = "[menu-file]";

  const NEW_ITEMS = [
    { id: "ie6-file-new-tab", label: "Tab", accesskey: "T", target: "menu_newNavigatorTab" },
    { id: "ie6-file-new-window", label: "Window", accesskey: "W", target: "menu_newNavigator" },
  ];

  const SEND_ITEMS = [
    { id: "ie6-file-send-page", label: "Page by E-mail...", accesskey: "P" },
    { id: "ie6-file-send-link", label: "Link by E-mail...", accesskey: "L" },
    { id: "ie6-file-send-shortcut", label: "Shortcut to Desktop", accesskey: "D", command: createDesktopShortcut },
  ];

  function createMenu(id, label, accesskey, items) {
    const menu = document.createXULElement("menu");
    menu.id = id;
    menu.setAttribute("label", label);
    menu.setAttribute("accesskey", accesskey);

    const popup = document.createXULElement("menupopup");
    popup.id = id + "-popup";
    for (const { id: itemId, label: itemLabel, accesskey: key, command } of items) {
      const item = document.createXULElement("menuitem");
      item.id = itemId;
      item.setAttribute("label", itemLabel);
      item.setAttribute("accesskey", key);
      if (command) item.addEventListener("command", command);
      popup.appendChild(item);
    }
    menu.appendChild(popup);
    return menu;
  }

  function createItem(id, label, accesskey, command) {
    const item = document.createXULElement("menuitem");
    item.id = id;
    item.setAttribute("label", label);
    item.setAttribute("accesskey", accesskey);
    if (command) item.addEventListener("command", command);
    return item;
  }

  function openPrint() {
    document.getElementById("cmd_print")?.doCommand();
  }

  function getActiveTabInfo() {
    const browser = window.gBrowser.selectedBrowser;
    return {
      url: browser.currentURI ? browser.currentURI.spec : "",
      title: window.gBrowser.selectedTab.label || browser.contentTitle || "",
    };
  }

  async function createDesktopShortcut() {
    if (Services.appinfo.OS !== "WINNT") return;
    try {
      const { url, title } = getActiveTabInfo();
      if (!url) return;

      const safeTitle = (title || "Shortcut").replace(/[\\/:*?"<>|]/g, "_").trim() || "Shortcut";
      const file = Services.dirsvc.get("Desk", Ci.nsIFile).clone();
      file.append(safeTitle + ".url");

      if (file.exists()) {
        file.createUnique(Ci.nsIFile.NORMAL_FILE_TYPE, 0o644);
        file.remove(false);
      }

      await IOUtils.writeUTF8(file.path, `[InternetShortcut]\r\nURL=${url}\r\n`);
    } catch (e) {}
  }

  function openImportExportWizard() {
    const existing = Services.wm.getMostRecentWindow("ie6theme:import-export-wizard");
    if (existing) {
      existing.focus();
      return;
    }
    window.openDialog(
      "chrome://userscripts/content/import-export-wizard.xhtml",
      "",
      "chrome,dialog=yes,centerscreen,resizable=no,width=511,height=400"
    );
  }

  function addNewMenu(filePopup) {
    const items = NEW_ITEMS.map(({ target, ...item }) => ({
      ...item,
      command: () => document.getElementById(target)?.doCommand(),
    }));
    filePopup.insertBefore(createMenu("ie6-file-new", "New", "N", items), filePopup.firstChild);
  }

  function addSendMenu(filePopup) {
    const printItem = document.getElementById("menu_print");
    const oldSendLink = document.getElementById("menu_sendLink");
    if (!printItem || !oldSendLink) return;

    filePopup.insertBefore(printItem, oldSendLink);

    const sendMenu = createMenu("ie6-file-send", "Send", "d", SEND_ITEMS);
    filePopup.insertBefore(sendMenu, oldSendLink);
    oldSendLink.remove();

    const importExport = document.createXULElement("menuitem");
    importExport.id = "ie6-file-importexport";
    importExport.setAttribute("label", "Import and Export...");
    importExport.setAttribute("accesskey", "I");
    importExport.addEventListener("command", openImportExportWizard);
    filePopup.insertBefore(importExport, sendMenu.nextSibling);
  }

  function addEditSaveItems(filePopup) {
    const saveAs = document.getElementById("menu_savePage");
    if (!saveAs) return;

    const edit = createItem("menu_fileEdit", "Edit", "E");
    edit.setAttribute("disabled", "true");

    const save = createItem("menu_fileSave", "Save", "S");
    save.setAttribute("key", "key_savePage");
    save.setAttribute("disabled", "true");

    filePopup.insertBefore(edit, saveAs);
    filePopup.insertBefore(save, saveAs);
  }

  function addPrintItems(filePopup) {
    const printItem = document.getElementById("menu_print");
    const sendMenu = document.getElementById("ie6-file-send");
    if (!printItem || !sendMenu) return;

    filePopup.insertBefore(createItem("menu_pageSetup", "Page Setup...", "u", openPrint), printItem);
    filePopup.insertBefore(createItem("menu_printPrev", "Print Preview...", "v", openPrint), sendMenu);
    filePopup.insertBefore(document.createXULElement("menuseparator"), sendMenu);
  }

  function init() {
    const filePopup = document.getElementById("menu_FilePopup");
    if (!filePopup || document.getElementById("ie6-file-new")) return;

    addNewMenu(filePopup);
    addSendMenu(filePopup);
    addEditSaveItems(filePopup);
    addPrintItems(filePopup);
  }

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();