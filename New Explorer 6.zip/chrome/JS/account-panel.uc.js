(function () {
  const HTML_NS = "http://www.w3.org/1999/xhtml";

  const ICON_DIR = (() => {
    const dir = Services.dirsvc.get("ProfD", Ci.nsIFile);
    dir.append("chrome");
    dir.append("images");
    return Services.io.newFileURI(dir).spec.replace(/\/?$/, "/");
  })();

  const SIGNIN_URL =
    "https://accounts.firefox.com/signin?service=sync&context=fx_desktop_v3&entrypoint=ie6theme";

  const QUICK_ACTIONS = [
    "Profile Settings",
    "Security",
    "Connected Services",
    "Data Collection and Use",
    "E-mail Communications",
  ];

  let sidebar;
  let contentWrap;

  function h(tag, className, text) {
    const el = document.createElementNS(HTML_NS, tag);
    if (className) el.className = className;
    if (text != null) el.textContent = text;
    return el;
  }

  function icon(path, className, alt) {
    const img = h("img", className);
    img.src = ICON_DIR + path;
    if (alt) img.alt = alt;
    return img;
  }

  function html(tag, className, markup) {
    const el = h(tag, className);
    el.innerHTML = markup;
    return el;
  }

  function setAccountButtonOpen(isOpen) {
    const btn = document.getElementById("ie6-account-button");
    if (!btn) return;
    if (isOpen) {
      btn.setAttribute("open", "true");
    } else {
      btn.removeAttribute("open");
      btn.removeAttribute("checked");
    }
  }

  function getFxAccounts() {
    const { getFxAccountsSingleton } = ChromeUtils.importESModule(
      "resource://gre/modules/FxAccounts.sys.mjs"
    );
    return getFxAccountsSingleton();
  }

  function openURL(url) {
    gBrowser.selectedTab = gBrowser.addTab(url, {
      triggeringPrincipal: Services.scriptSecurityManager.getSystemPrincipal(),
    });
  }

  const openSignInTab = () => openURL(SIGNIN_URL);

  async function openManagePage() {
    let url = "https://accounts.firefox.com/settings";
    try {
      url = await getFxAccounts().constructor.config.promiseManageURI("ie6theme");
    } catch (e) {}
    openURL(url);
  }

  async function handleSignOut() {
    try {
      await getFxAccounts().signOut();
    } catch (e) {}
    refreshView();
  }

  function renderSignIn() {
    const card = h("div", "ac-card");

    const banner = h("div", "ac-banner");
    banner.append(
      h("span", "ac-heading", "Sign Up to the Microsoft Network Service."),
      html(
        "div",
        null,
        "Please <b>sign in</b> with your <b>.NET Passport</b> to synchronize your Add-ons, Favorites and Search History every time you use Internet Explorer."
      )
    );

    const emailInput = h("input", "ac-field-input");
    emailInput.type = "text";
    const passInput = h("input", "ac-field-input");
    passInput.type = "password";

    const signinBtn = h("button", "ac-imgbtn");
    signinBtn.appendChild(icon("accounts/signinnet.png", null, "Sign In .net"));
    signinBtn.addEventListener("click", openSignInTab);
    const btnRow = h("div", "ac-btn-row");
    btnRow.appendChild(signinBtn);

    const remindCb = h("input", "sb-checkbox");
    remindCb.type = "checkbox";
    const checkLabel = h("label", "ac-checkbox-label");
    checkLabel.append(remindCb, document.createTextNode(" Remind my credentials."));

    const form = h("div", "ac-form");
    form.append(
      h("label", "ac-field-label", "E-mail address:"),
      emailInput,
      h("label", "ac-field-label", "Password:"),
      passInput,
      btnRow,
      checkLabel
    );

    const infoHeader = h("div", "ac-note-header");
    infoHeader.append(
      icon("accounts/help.png", "ac-note-icon"),
      h("span", null, "Will leaving this unchecked log me out?")
    );
    const infoBox = h("div", "ac-note ac-note-info");
    infoBox.append(
      infoHeader,
      html(
        "div",
        null,
        "<b>Your .NET Passport session will be saved after sign-in</b>, but checking this box allows us to autocomplete your data automatically."
      )
    );

    const divider = h("div", "ac-divider");
    divider.appendChild(h("span", null, "Or"));
    const goBtn = h("button", "ac-imgbtn ac-go-btn");
    goBtn.append(
      icon("accounts/buttongo.png", "ac-go-normal"),
      icon("accounts/buttongopress.png", "ac-go-pressed")
    );
    goBtn.addEventListener("click", openSignInTab);
    const passkey = h("div", "ac-passkey");
    passkey.append(divider, h("span", "ac-heading ac-heading-spaced", "Sign In with Pass-Key"), goBtn);

    const linksRow = h("div", "ac-links-row");
    linksRow.append(h("a", "ac-link", "Sign Up"), h("a", "ac-link", "Forgot your Password?"));

    card.append(banner, form, infoBox, passkey, linksRow);
    return card;
  }

  function renderDashboard(user) {
    const card = h("div", "ac-card");

    const header = h("div", "ac-dash-header", user.email || "My Account");

    const userRow = h("div", "ac-dash-userrow");
    if (user.avatarURL) {
      const avatar = h("img", "ac-dash-avatar");
      avatar.src = user.avatarURL;
      userRow.appendChild(avatar);
    }
    userRow.appendChild(h("span", "ac-dash-email", user.displayName || "My Account"));

    const mgmtHeader = icon("accounts/accountman.png", "ac-accountman-header", "Account Management");

    const bigButtons = [
      ["ac-item-profile", "Create a New Profile", () => openURL("about:profiles")],
      ["ac-item-sync", `Synchronize: ${user.syncEnabled ? "ON" : "OFF"}`, () => openURL("about:preferences#sync")],
      ["ac-item-security", "Security Alerts", openManagePage],
    ];
    const dashList = h("div", "ac-dash-list");
    for (const [cls, text, run] of bigButtons) {
      const item = h("div", `ac-dash-item ${cls}`, text);
      item.addEventListener("click", run);
      dashList.appendChild(item);
    }

    const qaList = h("div", "ac-qa-list");
    for (const text of QUICK_ACTIONS) {
      const link = h("a", "ac-link ac-link-light", text);
      link.addEventListener("click", openManagePage);
      qaList.appendChild(link);
    }

    const vpnHeader = h("div", "ac-note-header");
    vpnHeader.append(
      icon("accounts/help.png", "ac-note-icon"),
      h("span", null, "Know more about our VPN")
    );
    const vpnLink = h("a", "ac-link ac-link-bold", "Get VPN");
    vpnLink.addEventListener("click", () => openURL("https://www.mozilla.org/products/vpn/"));
    const vpnBox = h("div", "ac-note ac-note-vpn");
    vpnBox.append(
      vpnHeader,
      icon("accounts/placeimage.png", "ac-note-image", "VPN Display"),
      html("div", null, "Discover <b>an added layer of anonymous browsing</b> and protection."),
      vpnLink
    );

    const signOutLink = h("a", "ac-link ac-link-light ac-signout", "Sign Out");
    signOutLink.addEventListener("click", handleSignOut);

    card.append(
      header,
      userRow,
      mgmtHeader,
      dashList,
      h("div", "ac-qa-header", "Quick Actions"),
      qaList,
      vpnBox,
      signOutLink
    );
    return card;
  }

  function refreshView() {
    if (!contentWrap) return;

    let state = null;
    try {
      const { UIState } = ChromeUtils.importESModule("resource://services-sync/UIState.sys.mjs");
      state = UIState.get();
    } catch (e) {}

    const signedIn = state?.status === "signed_in";
    sidebar.dataset.view = signedIn ? "dashboard" : "signin";

    try {
      contentWrap.replaceChildren(signedIn ? renderDashboard(state) : renderSignIn());
    } catch (e) {
      contentWrap.replaceChildren(h("div", null, "Error al cargar la cuenta."));
    }
  }

  function hideSidebar() {
    sidebar.hidden = true;
    setAccountButtonOpen(false);
  }

  function registerObservers() {
    const observer = {
      observe(subject, topic) {
        if (topic === "fxaccounts:onlogin") {
          window.__ie6Sidebars?.closeOthers("account");
          sidebar.hidden = false;
          setAccountButtonOpen(true);
        }
        refreshView();
      },
    };
    const topics = ["fxaccounts:onlogin", "fxaccounts:onlogout", "UIState:onStateUpdated"];

    topics.forEach((topic) => Services.obs.addObserver(observer, topic));
    window.addEventListener(
      "unload",
      () => topics.forEach((topic) => Services.obs.removeObserver(observer, topic)),
      { once: true }
    );
  }

  function buildTitlebar() {
    const closeBtn = icon("close.png", "sb-flatbtn sb-close-btn");
    closeBtn.title = "Close";
    closeBtn.addEventListener("click", hideSidebar);

    const titlebar = h("div", "sb-titlebar");
    titlebar.append(h("span", null, "Account"), closeBtn);
    return titlebar;
  }

  function ensureSidebar() {
    if (sidebar) return sidebar;

    sidebar = document.createXULElement("vbox");
    sidebar.id = "ie6-account-sidebar";
    sidebar.className = "sb-panel";
    sidebar.hidden = true;

    contentWrap = h("div", "ac-content-wrap");
    const listWrap = h("div", "ac-list-wrap");
    listWrap.appendChild(contentWrap);
    sidebar.append(buildTitlebar(), listWrap);

    const browserBox = document.getElementById("browser");
    browserBox.insertBefore(sidebar, browserBox.firstChild);

    window.__ie6Sidebars ||= {
      panels: {},
      register(id, hideFn) {
        this.panels[id] = hideFn;
      },
      closeOthers(exceptId) {
        for (const [id, hideFn] of Object.entries(this.panels)) {
          if (id !== exceptId) hideFn();
        }
      },
    };
    window.__ie6Sidebars.register("account", hideSidebar);

    registerObservers();
    return sidebar;
  }

  function toggleSidebar() {
    ensureSidebar();
    if (!sidebar.hidden) return hideSidebar();

    window.__ie6Sidebars?.closeOthers("account");
    refreshView();
    sidebar.hidden = false;
    setAccountButtonOpen(true);
  }

  window.ie6ToggleAccountSidebar = toggleSidebar;
})();