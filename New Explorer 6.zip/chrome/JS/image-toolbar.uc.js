(function () {
  const { ActorManagerParent } = ChromeUtils.importESModule(
    "resource://gre/modules/ActorManagerParent.sys.mjs"
  );

  try {
    ActorManagerParent.addJSWindowActors({
      ImageToolbar: {
        parent: {
          esModuleURI: "resource://ie6theme/actors/ImageToolbarParent.sys.mjs",
        },
        child: {
          esModuleURI: "resource://ie6theme/actors/ImageToolbarChild.sys.mjs",
          events: { DOMWindowCreated: {} },
        },
        allFrames: true,
        matches: ["file:///*", "http://*/*", "https://*/*"],
      },
    });
  } catch (e) {
    if (!/already registered/.test(e.message)) {}
  }
})();