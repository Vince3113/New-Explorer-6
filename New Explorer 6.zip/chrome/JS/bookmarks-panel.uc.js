(function () {
  const HTML_NS = "http://www.w3.org/1999/xhtml";

  const { PlacesUtils } = ChromeUtils.importESModule(
    "resource://gre/modules/PlacesUtils.sys.mjs"
  );

  const ICON_DIR = (() => {
    const dir = Services.dirsvc.get("ProfD", Ci.nsIFile);
    dir.append("chrome");
    dir.append("images");
    return Services.io.newFileURI(dir).spec.replace(/\/?$/, "/");
  })();

  const FOLDER = "favourites-folder.png";
  const FOLDER_OPEN = "favourites-folder-open.png";

  const ROOTS = [
    { guid: PlacesUtils.bookmarks.toolbarGuid, label: "Favorites Bar" },
    { guid: PlacesUtils.bookmarks.unfiledGuid, label: "Other Favorites" },
  ];

  let sidebar;
  let listEl;
  let ctxMenuEl;
  let selectedEl = null;

  const iconURL = (name) => ICON_DIR + name;

  function h(tag, className, text) {
    const el = document.createElementNS(HTML_NS, tag);
    if (className) el.className = className;
    if (text != null) el.textContent = text;
    return el;
  }

  function icon(name, className = "sb-icon") {
    const img = h("img", className);
    img.src = iconURL(name);
    return img;
  }

  function selectItem(el) {
    selectedEl?.classList.remove("sb-selected");
    selectedEl = el;
    el?.classList.add("sb-selected");
  }

  function setBookmarksButtonOpen(isOpen) {
    const btn = document.getElementById("bookmarks-menu-button");
    if (!btn) return;
    if (isOpen) btn.setAttribute("open", "true");
    else btn.removeAttribute("open");
  }

  function refreshTree() {
    if (sidebar && !sidebar.hidden) buildTree();
  }

  function showCtxMenu(x, y, items) {
    if (!ctxMenuEl) {
      ctxMenuEl = h("div", "sb-menu sb-ctxmenu");
      ctxMenuEl.hidden = true;
      sidebar.appendChild(ctxMenuEl);
    }

    ctxMenuEl.replaceChildren(
      ...items.map(({ label, bold, onClick }) => {
        const row = h("div", "sb-menu-item" + (bold ? " sb-menu-bold" : ""), label);
        row.addEventListener("click", (e) => {
          e.stopPropagation();
          ctxMenuEl.hidden = true;
          onClick();
        });
        return row;
      })
    );

    ctxMenuEl.style.left = x + "px";
    ctxMenuEl.style.top = y + "px";
    ctxMenuEl.hidden = false;
  }

  function attachContextMenu(row, getItems) {
    row.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      e.stopPropagation();
      selectItem(row);
      showCtxMenu(e.clientX, e.clientY, getItems());
    });
  }

  function promptName(title, label, value) {
    const input = { value };
    const ok = Services.prompt.prompt(window, title, label, input, null, { value: false });
    return ok ? input.value.trim() : "";
  }

  async function renameItem(guid, currentTitle) {
    const name = promptName("Rename", "New name:", currentTitle || "");
    if (!name) return;
    await PlacesUtils.bookmarks.update({ guid, title: name });
    buildTree();
  }

  async function deleteItem(guid) {
    await PlacesUtils.bookmarks.remove(guid);
    buildTree();
  }

  async function createSubfolder(parentGuid) {
    const name = promptName("New Folder", "New folder name:", "New Folder");
    if (!name) return;
    await PlacesUtils.bookmarks.insert({
      parentGuid,
      type: PlacesUtils.bookmarks.TYPE_FOLDER,
      title: name,
    });
    buildTree();
  }

  const editItems = (guid, title) => [
    { label: "Rename...", onClick: () => renameItem(guid, title) },
    { label: "Delete", onClick: () => deleteItem(guid) },
  ];

  function createFolderRow(label) {
    const row = h("div", "sb-row bm-folder");
    const folderIcon = icon(FOLDER);
    row.title = label;
    row.append(folderIcon, h("span", null, label));
    return { row, folderIcon };
  }

  function appendBookmark(box, child) {
    const row = h("div", "sb-row bm-page");
    const title = child.title || child.uri;
    row.title = `${title}\n${child.uri}`;
    row.append(icon("page.png"), h("span", null, title));
    row.addEventListener("click", (e) => {
      e.stopPropagation();
      selectItem(row);
      gBrowser.selectedTab = gBrowser.addTrustedTab(child.uri);
    });
    attachContextMenu(row, () => editItems(child.guid, child.title));
    box.appendChild(row);
  }

  function appendSubfolder(box, child) {
    const { row, folderIcon } = createFolderRow(child.title || "(unnamed)");
    const subBox = h("div", "sb-children");
    box.append(row, subBox);

    row.addEventListener("click", (e) => {
      e.stopPropagation();
      selectItem(row);
      const willOpen = !subBox.classList.contains("sb-open");
      subBox.classList.toggle("sb-open", willOpen);
      folderIcon.src = iconURL(willOpen ? FOLDER_OPEN : FOLDER);
      if (willOpen && !subBox.dataset.filled) fillFolder(child.guid, subBox);
    });

    attachContextMenu(row, () => [
      {
        label: subBox.classList.contains("sb-open") ? "Collapse" : "Expand",
        bold: true,
        onClick: () => row.click(),
      },
      { label: "New Folder...", onClick: () => createSubfolder(child.guid) },
      ...editItems(child.guid, child.title),
    ]);
  }

  async function fillFolder(guid, box) {
    box.dataset.filled = "1";

    let node;
    try {
      node = await PlacesUtils.promiseBookmarksTree(guid, { includeItemIds: false });
    } catch (e) {
      return;
    }

    for (const child of node.children || []) {
      const isSeparator =
        child.type === PlacesUtils.TYPE_X_MOZ_PLACE_SEPARATOR ||
        child.typeCode === PlacesUtils.bookmarks.TYPE_SEPARATOR;

      if (child.uri) appendBookmark(box, child);
      else if (!isSeparator) appendSubfolder(box, child);
    }
  }

  function buildTree() {
    if (!listEl) return;
    listEl.textContent = "";
    selectItem(null);

    for (const root of ROOTS) {
      const group = h("div", "sb-group");
      const { row, folderIcon } = createFolderRow(root.label);
      const box = h("div", "sb-children");
      group.append(row, box);
      listEl.appendChild(group);

      row.addEventListener("click", (e) => {
        e.stopPropagation();
        selectItem(row);
        const wasOpen = group.classList.contains("sb-group-open");

        listEl.querySelectorAll(".sb-group-open").forEach((grp) => {
          grp.classList.remove("sb-group-open");
          grp.querySelector(":scope > .sb-children").classList.remove("sb-open");
          grp.querySelector(":scope > .bm-folder img").src = iconURL(FOLDER);
        });

        if (wasOpen) return;
        group.classList.add("sb-group-open");
        box.classList.add("sb-open");
        folderIcon.src = iconURL(FOLDER_OPEN);
        if (!box.dataset.filled) fillFolder(root.guid, box);
      });

      attachContextMenu(row, () => [
        {
          label: group.classList.contains("sb-group-open") ? "Collapse" : "Expand",
          bold: true,
          onClick: () => row.click(),
        },
        { label: "New Folder...", onClick: () => createSubfolder(root.guid) },
      ]);
    }
  }

  function openAddFavoriteDialog() {
    const browser = gBrowser.selectedBrowser;
    window.openDialog(
      "chrome://userscripts/content/add-favorite-dialog.xhtml",
      "_blank",
      "chrome,dialog,centerscreen,resizable=no",
      {
        title: browser.contentTitle || gBrowser.selectedTab.label || "",
        url: browser.currentURI.spec,
        onCreated: refreshTree,
      }
    );
  }

  function openOrganizeFavoritesWindow() {
    const existing = Services.wm.getMostRecentWindow("ie6theme:organize-favorites");
    if (existing) {
      existing.focus();
      return;
    }
    window.openDialog(
      "chrome://userscripts/content/organize-favorites-window.xhtml",
      "_blank",
      "chrome,dialog,centerscreen,resizable=no,width=400,height=311",
      { onChanged: refreshTree }
    );
  }

  function hideSidebar() {
    sidebar.hidden = true;
    setBookmarksButtonOpen(false);
  }

  function createToolButton(label, iconName, onClick) {
    const btn = h("span", "bm-toolbtn");
    const btnIcon = icon(`${iconName}-inactive.png`);
    btn.append(btnIcon, h("span", null, label));
    btn.addEventListener("mouseenter", () => (btnIcon.src = iconURL(`${iconName}-active.png`)));
    btn.addEventListener("mouseleave", () => (btnIcon.src = iconURL(`${iconName}-inactive.png`)));
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      onClick();
    });
    return btn;
  }

  function ensureSidebar() {
    if (sidebar) return sidebar;

    sidebar = document.createXULElement("vbox");
    sidebar.id = "ie6-bookmarks-sidebar";
    sidebar.className = "sb-panel";
    sidebar.hidden = true;

    const closeBtn = icon("close.png", "sb-flatbtn sb-close-btn");
    closeBtn.title = "Close";
    closeBtn.addEventListener("click", hideSidebar);

    const titlebar = h("div", "sb-titlebar");
    titlebar.append(h("span", null, "Favorites"), closeBtn);

    const toolbar = h("div", "sb-toolbar");
    toolbar.append(
      createToolButton("Add...", "add", openAddFavoriteDialog),
      createToolButton("Organize...", "organize", openOrganizeFavoritesWindow)
    );

    listEl = h("div", "sb-list");
    const listWrapper = h("div", "sb-list-wrapper");
    listWrapper.appendChild(listEl);

    sidebar.append(titlebar, toolbar, listWrapper);

    const browserBox = document.getElementById("browser");
    browserBox.insertBefore(sidebar, browserBox.firstChild);

    window.__ie6Sidebars ||= {
      panels: {},
      register(id, hideFn) {
        this.panels[id] = hideFn;
      },
      closeOthers(exceptId) {
        for (const [id, hideFn] of Object.entries(this.panels)) {
          if (id !== exceptId) hideFn();
        }
      },
    };
    window.__ie6Sidebars.register("bookmarks", hideSidebar);

    return sidebar;
  }

  function toggleSidebar() {
    ensureSidebar();
    if (!sidebar.hidden) return hideSidebar();

    window.__ie6Sidebars?.closeOthers("bookmarks");
    sidebar.hidden = false;
    setBookmarksButtonOpen(true);
    buildTree();
  }

  window.ie6ToggleBookmarksSidebar = toggleSidebar;

  function init() {
    document.addEventListener(
      "popupshowing",
      (e) => {
        if (e.target.id !== "BMB_bookmarksPopup") return;
        e.preventDefault();
        e.stopPropagation();
        toggleSidebar();
      },
      true
    );

    document.addEventListener("click", (e) => {
      if (ctxMenuEl) ctxMenuEl.hidden = true;
      if (sidebar && !sidebar.contains(e.target)) selectItem(null);
    });
  }

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();