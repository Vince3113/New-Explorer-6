(function () {
  try {
    if (typeof gBrowser === "undefined" || document.getElementById("ie6-statusbar")) return;

    const { SitePermissions } = ChromeUtils.importESModule(
      "resource:///modules/SitePermissions.sys.mjs"
    );
    const wpl = Ci.nsIWebProgressListener;

    const PREF_HIDDEN = "ie6theme.statusbar.hidden";

    const isManuallyHidden = () => Services.prefs.getBoolPref(PREF_HIDDEN, false);
    const isMaximized = () => document.documentElement.getAttribute("sizemode") === "maximized";

    function createXUL(tag, id, attrs = {}) {
      const el = document.createXULElement(tag);
      el.id = id;
      for (const [key, val] of Object.entries(attrs)) el.setAttribute(key, val);
      return el;
    }

    function createIconCell(name) {
      const cell = createXUL("hbox", `ie6-statusbar-${name}`, { align: "center" });
      const icon = createXUL("image", `ie6-statusbar-${name}-icon`);
      icon.hidden = true;
      cell.appendChild(icon);
      return { cell, icon };
    }

    const bar = createXUL("hbox", "ie6-statusbar", { align: "center" });

    const textBox = createXUL("hbox", "ie6-statusbar-textbox", { align: "center", flex: "1" });
    const text = createXUL("label", "ie6-statusbar-text", { value: "Done", crop: "end" });
    textBox.append(createXUL("image", "ie6-statusbar-text-icon"), text);

    const progressDivider = createXUL("hbox", "ie6-statusbar-progress-divider");
    const progress = createXUL("hbox", "ie6-statusbar-progress");
    const progressFrame = document.createElementNS("http://www.w3.org/1999/xhtml", "progress");
    progressFrame.id = "ie6-statusbar-progress-frame";
    progressFrame.max = 100;
    progressFrame.value = 0;
    const progressFill = createXUL("hbox", "ie6-statusbar-progress-inner");
    progress.append(progressFrame, progressFill);

    const FILL_MAX_WIDTH = 88;
    const BLOCK_WIDTH = 8;
    const FINISH_DELAY = 300;

    const { cell: offlineCell, icon: offlineIcon } = createIconCell("offline");
    const { cell: micCell, icon: micIcon } = createIconCell("mic");
    const { cell: audioCell, icon: audioIcon } = createIconCell("audio");
    const { cell: permissionsCell, icon: permissionsIcon } = createIconCell("permissions");
    const { cell: lockCell, icon: lockIcon } = createIconCell("lock");

    const zone = createXUL("hbox", "ie6-statusbar-zone", { align: "center" });
    const zoneLabel = createXUL("label", "ie6-statusbar-zone-label", { value: "Internet" });
    zone.append(createXUL("image", "ie6-statusbar-zone-icon"), zoneLabel);

    const resizer = createXUL("hbox", "ie6-statusbar-resizer");

    bar.append(
      textBox,
      progressDivider,
      progress,
      offlineCell,
      micCell,
      audioCell,
      permissionsCell,
      lockCell,
      zone,
      resizer
    );
    document.documentElement.appendChild(bar);

    let isLoading = false;
    let progressTimer = null;
    let finishTimer = null;
    let progressKnown = false;
    let progressValue = 0;

    function setProgressValue(pct) {
      progressValue = Math.max(0, Math.min(100, pct));
      const width = Math.floor((FILL_MAX_WIDTH * progressValue) / 100 / BLOCK_WIDTH) * BLOCK_WIDTH;
      progressFill.style.width = `${width}px`;
    }

    function startProgress() {
      stopProgress();
      progressKnown = false;
      progressTimer = setInterval(() => {
        if (progressKnown) return;
        if (progressValue < 90) {
          setProgressValue(progressValue + Math.max(0.4, (90 - progressValue) * 0.06));
        }
      }, 100);
    }

    function stopProgress() {
      if (progressTimer) clearInterval(progressTimer);
      progressTimer = null;
      if (finishTimer) clearTimeout(finishTimer);
      finishTimer = null;
      bar.removeAttribute("finishing");
      setProgressValue(0);
    }

    function finishProgress() {
      if (progressTimer) clearInterval(progressTimer);
      progressTimer = null;
      setProgressValue(100);
      bar.setAttribute("finishing", "");
      finishTimer = setTimeout(stopProgress, FINISH_DELAY);
    }

    function setStatusState(loading, textValue) {
      if (loading !== isLoading) loading ? startProgress() : finishProgress();
      isLoading = loading;
      bar.toggleAttribute("loading", loading);
      text.setAttribute("value", textValue);
    }

    function updateZone() {
      const uri = gBrowser.currentURI;
      if (!uri) return;

      const isLocal = uri.schemeIs("file");
      zone.setAttribute("zone", isLocal ? "computer" : "internet");
      zoneLabel.setAttribute("value", isLocal ? "My Computer" : "Internet");
    }

    function applyLockState(state) {
      const uri = gBrowser.currentURI;
      if (!uri || (!uri.schemeIs("http") && !uri.schemeIs("https"))) {
        lockIcon.hidden = true;
        lockCell.removeAttribute("insecure");
        return;
      }

      const isSecure = !!(state & wpl.STATE_IS_SECURE) && !(state & wpl.STATE_IS_BROKEN);
      lockIcon.hidden = false;
      lockCell.toggleAttribute("insecure", !isSecure);
    }

    function updateLock() {
      let state = 0;
      try {
        state = gBrowser.securityUI.state;
      } catch (e) {}
      applyLockState(state);
    }

    function updateMicIcon() {
      const sharing = gBrowser.selectedTab?.getAttribute("sharing") ?? "";
      micIcon.hidden = !sharing.includes("microphone");
    }

    function updatePermissionsIcon() {
      try {
        const permissions = SitePermissions.getAllPermissionDetailsForBrowser(
          gBrowser.selectedBrowser
        );
        permissionsIcon.hidden = !permissions.length;
        permissionsCell.toggleAttribute(
          "restricted",
          permissions.some((p) => p.state === SitePermissions.BLOCK)
        );
      } catch (e) {
        permissionsIcon.hidden = true;
      }
    }

    function updateAudioIcon() {
      const tab = gBrowser.selectedTab;
      if (!tab) return;

      const muted = tab.hasAttribute("muted");
      audioIcon.hidden = !(muted || tab.hasAttribute("soundplaying"));
      audioCell.toggleAttribute("muted", muted);
    }

    function updateMediaIcons() {
      updatePermissionsIcon();
      updateMicIcon();
      updateAudioIcon();
    }

    function updateOfflineIcon() {
      offlineIcon.hidden = !Services.io.offline;
    }

    function updateWindowState() {
      const fullscreen = window.fullScreen;
      const hide = fullscreen || isManuallyHidden();

      resizer.hidden = isMaximized() || fullscreen;
      bar.hidden = hide;
      document.documentElement.toggleAttribute("ie6-statusbar-hidden", hide);
    }

    permissionsCell.addEventListener("click", () => {
      try {
        gPermissionPanel.setAnchor(permissionsCell);
        gPermissionPanel.openPopup();
      } catch (e) {}
    });

    resizer.addEventListener("mousedown", (e) => {
      if (e.button !== 0 || isMaximized() || window.fullScreen) return;

      const startX = e.screenX;
      const startY = e.screenY;
      const startWidth = window.outerWidth;
      const startHeight = window.outerHeight;

      const onMove = (ev) => {
        window.resizeTo(
          Math.max(400, startWidth + ev.screenX - startX),
          Math.max(300, startHeight + ev.screenY - startY)
        );
      };
      const onUp = () => {
        window.removeEventListener("mousemove", onMove);
        window.removeEventListener("mouseup", onUp);
      };

      window.addEventListener("mousemove", onMove);
      window.addEventListener("mouseup", onUp);
      e.preventDefault();
      e.stopPropagation();
    });

    gBrowser.tabContainer.addEventListener("TabAttrModified", (e) => {
      if (e.target === gBrowser.selectedTab) updateMediaIcons();
    });
    gBrowser.tabContainer.addEventListener("TabSelect", () => {
      updateMediaIcons();
      updateZone();
      updateLock();
    });

    const observer = {
      observe(subject, topic) {
        if (topic === "perm-changed") updatePermissionsIcon();
        else updateOfflineIcon();
      },
    };
    const OBSERVED_TOPICS = ["network:offline-status-changed", "perm-changed"];
    OBSERVED_TOPICS.forEach((topic) => Services.obs.addObserver(observer, topic));
    window.addEventListener(
      "unload",
      () => OBSERVED_TOPICS.forEach((topic) => Services.obs.removeObserver(observer, topic)),
      { once: true }
    );

    const STATE_TRANSFERRING = 0x00000008;

    gBrowser.addProgressListener({
      onStateChange(aWebProgress, aRequest, aStateFlags) {
        if (!aWebProgress?.isTopLevel) return;

        if (aStateFlags & wpl.STATE_START) {
          setStatusState(true, "Connecting to site...");
        } else if (aStateFlags & STATE_TRANSFERRING) {
          const url = aRequest?.name || gBrowser.currentURI?.spec || "";
          setStatusState(true, url ? `Opening page ${url}...` : "Opening page...");
        } else if (aStateFlags & wpl.STATE_STOP) {
          setStatusState(false, "Done");
        }
      },
      onProgressChange(aWebProgress, aRequest, aCurSelf, aMaxSelf, aCurTotal, aMaxTotal) {
        if (!aWebProgress?.isTopLevel || !isLoading) return;

        if (aMaxTotal > 0 && aCurTotal >= 0) {
          progressKnown = true;
          const real = Math.min(100, Math.round((aCurTotal * 100) / aMaxTotal));
          setProgressValue(Math.max(progressValue, real));
        }
      },
      onLocationChange(aWebProgress) {
        if (aWebProgress?.isTopLevel) {
          updateZone();
          updateLock();
          updatePermissionsIcon();
        }
      },
      onSecurityChange(aWebProgress, aRequest, aState) {
        if (aWebProgress?.isTopLevel) applyLockState(aState);
      },
    });

    const xulWindow = window.XULBrowserWindow;
    if (typeof xulWindow?.setOverLink === "function") {
      const originalSetOverLink = xulWindow.setOverLink.bind(xulWindow);
      xulWindow.setOverLink = function (url, anchorElt) {
        originalSetOverLink(url, anchorElt);
        text.setAttribute("value", url || (isLoading ? "Opening page..." : ""));
      };
    }

    window.addEventListener("resize", updateWindowState);
    window.addEventListener("fullscreen", updateWindowState);

    window.ie6StatusBar = {
      isVisible: () => !bar.hidden,
      setHidden(value) {
        Services.prefs.setBoolPref(PREF_HIDDEN, !!value);
        updateWindowState();
      },
    };

    updateWindowState();
    updateZone();
    updateLock();
    updateOfflineIcon();
    updateMediaIcons();
  } catch (ex) {}
})();