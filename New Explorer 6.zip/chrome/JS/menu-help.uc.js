(function () {
  const HELP_ITEMS = [
    ["ie6_contentsAndIndex", "Contents and Index", "C", () => openHhViewer()],
    ["ie6_tipOfTheDay", "Tip of the Day", "T", null],
    ["ie6_forNetscapeUsers", "For Netscape Users", "N", () => openHhViewer("tips-for-netscape-users")],
  ];

  function createItem(id, label, accesskey, onCommand) {
    const el = document.createXULElement("menuitem");
    el.id = id;
    el.setAttribute("label", label);
    el.setAttribute("accesskey", accesskey);
    el.setAttribute("class", "menuitem-iconic");
    if (onCommand) el.addEventListener("command", onCommand);
    return el;
  }

  function relabel(id, label, accesskey) {
    const el = document.getElementById(id);
    if (!el) return;
    el.setAttribute("label", label);
    el.setAttribute("accesskey", accesskey);
  }

  function openHhViewer(topicId) {
    const topic = typeof topicId === "string" ? topicId : null;
    const existing = Services.wm.getMostRecentWindow("ie6theme:hhviewer");
    if (existing) {
      if (topic && existing.ie6ShowTopic) existing.ie6ShowTopic(topic);
      existing.focus();
      return;
    }
    window.openDialog(
      "chrome://userscripts/content/index.xhtml",
      "",
      "chrome,dialog=no,resizable=no,minimizable=yes,centerscreen,width=815,height=527",
      topic
    );
  }

  function setupHelpMenu() {
    const popup = document.getElementById("menu_HelpPopup");
    if (!popup) return;

    const getHelp = document.getElementById("menu_openHelp");
    if (getHelp) {
      for (const [id, label, key, onCommand] of HELP_ITEMS) {
        if (!document.getElementById(id)) popup.insertBefore(createItem(id, label, key, onCommand), getHelp);
      }
    }

    relabel("menu_openHelp", "Online Support", "O");
    relabel("feedbackPage", "Send Feedback", "F");
    relabel("aboutName", "About Internet Explorer", "A");
  }

  window.addEventListener(
    "popupshowing",
    (e) => {
      if (e.target?.id === "menu_HelpPopup") setupHelpMenu();
    },
    true
  );
})();