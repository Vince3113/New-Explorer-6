(function () {
  const { PlacesUtils } = ChromeUtils.importESModule(
    "resource://gre/modules/PlacesUtils.sys.mjs"
  );
  const { BookmarkHTMLUtils } = ChromeUtils.importESModule(
    "resource://gre/modules/BookmarkHTMLUtils.sys.mjs"
  );
  const HTML_NS = "http://www.w3.org/1999/xhtml";

  const IMPLEMENTED = new Set(["export-favorites", "import-favorites", "export-cookies"]);

  const FLOWS = {
    "export-favorites": ["page-export-source", "page-export-dest", "page-complete"],
    "import-favorites": ["page-import-source", "page-complete"],
    "export-cookies": ["page-export-cookies", "page-complete"],
    "import-cookies": ["page-import-cookies", "page-complete"],
  };

  const DESCRIPTIONS = {
    "import-favorites": "Import favorites from another browser or file.",
    "export-favorites": "Export favorites to another browser or file.",
    "import-cookies": "Import cookies from another browser or file.",
    "export-cookies": "Export cookies to another browser or file.",
  };

  const NEXT_LABEL = {
    "page-export-dest": "Export",
    "page-import-source": "Import",
    "page-export-cookies": "Export",
    "page-complete": "Finish",
  };
  const FINAL_PAGES = new Set(["page-complete"]);

  const PATH_PAGES = {
    "page-export-dest": { input: "ie-export-path", file: "bookmark.htm" },
    "page-import-source": { input: "ie-import-path", file: "bookmark.htm" },
    "page-export-cookies": { input: "ie-cookies-export-path", file: "cookies.txt" },
  };

  const state = { action: "import-favorites", exportFolder: null };
  let currentId = "page-welcome";
  let busy = false;

  const $ = (id) => document.getElementById(id);

  function sequence() {
    return ["page-welcome", "page-selection", ...(FLOWS[state.action] || [])]
      .filter((id) => $(id));
  }

  function updateButtons() {
    const seq = sequence();
    const idx = seq.indexOf(currentId);
    const isFinal = FINAL_PAGES.has(currentId);
    const pathPage = PATH_PAGES[currentId];

    let canNext = idx < seq.length - 1;
    if (currentId === "page-selection") canNext = canNext && IMPLEMENTED.has(state.action);
    if (pathPage) canNext = $(pathPage.input).value.trim() !== "";
    if (isFinal) canNext = true;

    $("btn-back").hidden = isFinal;
    $("btn-cancel").hidden = isFinal;
    $("btn-back").disabled = busy || idx <= 0;
    $("btn-next").textContent = NEXT_LABEL[currentId] || "Next >";
    $("btn-next").disabled = busy || !canNext;
  }

  function show(id) {
    currentId = id;
    for (const el of document.querySelectorAll(".ie-page")) {
      el.classList.toggle("active", el.id === id);
    }
    if (id === "page-export-source") buildExportTree();
    const pathPage = PATH_PAGES[id];
    if (pathPage && !$(pathPage.input).value) {$(pathPage.input).value = defaultPath(pathPage.file);
    }
    updateButtons();
  }

  function go(delta) {
    const seq = sequence();
    const next = seq[seq.indexOf(currentId) + delta];
    if (next) show(next);
  }

  const list = $("ie-action-list");
  const items = [...list.querySelectorAll(".ie-list-item")];

  function select(item) {
    items.forEach((i) => i.classList.toggle("selected", i === item));
    state.action = item.dataset.action;
    $("ie-desc-text").textContent = DESCRIPTIONS[state.action];
    updateButtons();
  }

  items.forEach((item) => {
    item.addEventListener("click", () => select(item));
    item.addEventListener("dblclick", () => { if (!$("btn-next").disabled) go(1); });
  });
  list.addEventListener("keydown", (e) => {
    const i = items.findIndex((it) => it.classList.contains("selected"));
    if (e.key === "ArrowDown" && i < items.length - 1) { select(items[i + 1]); e.preventDefault(); }
    if (e.key === "ArrowUp" && i > 0) { select(items[i - 1]); e.preventDefault(); }
  });

  function iconURL(name) {
    const file = Services.dirsvc.get("ProfD", Ci.nsIFile);
    file.append("chrome");
    file.append("images");
    file.append(name);
    return Services.io.newFileURI(file).spec;
  }

  function mk(tag, cls) {
    const e = document.createElementNS(HTML_NS, tag);
    if (cls) e.className = cls;
    return e;
  }

  function isContainer(n) {
    return n.type === "text/x-moz-place-container" || n.typeCode === 2;
  }

  function isSeparator(n) {
    return n.type === "text/x-moz-place-separator" || n.typeCode === 3;
  }

  let exportTreeBuilt = false;

  function selectExportFolder(row, guid, title) {
    $("ie-export-tree")
      .querySelectorAll(".ie-row.selected")
      .forEach((r) => r.classList.remove("selected"));
    row.classList.add("selected");
    state.exportFolder = { guid, title };
  }

  function createRow(title, guid, iconName, extraIconClass) {
    const row = mk("div", "ie-row");
    const toggle = mk("img", "ie-toggle");
    const icon = mk("img", "ie-folder-icon" + (extraIconClass ? " " + extraIconClass : ""));
    icon.src = iconURL(iconName);
    const label = mk("span", "ie-node-label");
    label.textContent = title;
    row.append(toggle, icon, label);
    row.addEventListener("click", (e) => {
      e.stopPropagation();
      selectExportFolder(row, guid, title);
    });
    return { row, toggle };
  }

  function renderExportNode(node, title, parent) {
    const el = mk("div", "ie-node");
    const { row, toggle } = createRow(title, node.guid, "favourites-folder.png");
    const children = mk("div", "ie-children");
    children.hidden = true;
    el.append(row, children);

    const subFolders = (node.children || []).filter(isContainer);
    if (subFolders.length) {
      toggle.src = iconURL("expand.PNG");
      toggle.addEventListener("click", (e) => {
        e.stopPropagation();
        children.hidden = !children.hidden;
        toggle.src = iconURL(children.hidden ? "expand.PNG" : "hide.PNG");
      });
      for (const sub of subFolders) {
        renderExportNode(sub, sub.title || "(unnamed)", children);
      }
    } else {
      toggle.style.visibility = "hidden";
    }
    parent.appendChild(el);
  }

  async function buildExportTree() {
    if (exportTreeBuilt) return;
    exportTreeBuilt = true;
    try {
      const rootGuid = PlacesUtils.bookmarks.rootGuid;
      const tree = await PlacesUtils.promiseBookmarksTree(rootGuid, { includeItemIds: false });
      const byGuid = new Map((tree.children || []).map((c) => [c.guid, c]));

      const container = mk("div", "ie-tree-container");
      const rootNode = mk("div", "ie-node ie-root");
      const { row: rootRow, toggle: rootToggle } = createRow(
        "Favorites", rootGuid, "favorites-small.png", "ie-star-icon"
      );
      rootToggle.style.display = "none";
      const rootChildren = mk("div", "ie-children ie-root-children");
      rootNode.append(rootRow, rootChildren);
      container.appendChild(rootNode);

      const roots = [
        [PlacesUtils.bookmarks.toolbarGuid, "Favorites Bar"],
        [PlacesUtils.bookmarks.unfiledGuid, "Other Bookmarks"],
        [PlacesUtils.bookmarks.menuGuid, "Bookmarks Menu"],
      ];
      for (const [guid, label] of roots) {
        const node = byGuid.get(guid);
        if (node) renderExportNode(node, label, rootChildren);
      }

      $("ie-export-tree").appendChild(container);
      selectExportFolder(rootRow, rootGuid, "Favorites");
    } catch (e) {
      exportTreeBuilt = false;
    }
  }

  function defaultPath(name) {
    for (const key of ["Pers", "Home", "Desk"]) {
      try {
        const dir = Services.dirsvc.get(key, Ci.nsIFile);
        dir.append(name);
        return dir.path;
      } catch (e) {}
    }
    return name;
  }

  async function browsePath(input, save, kind = "html") {
    try {
      const fp = Cc["@mozilla.org/filepicker;1"].createInstance(Ci.nsIFilePicker);
      const mode = save ? Ci.nsIFilePicker.modeSave : Ci.nsIFilePicker.modeOpen;
      const title = save ? "Save As" : "Open";
      const isText = kind === "text";
      const fallbackName = isText ? "cookies.txt" : "bookmark.htm";
      try {
        fp.init(window.browsingContext, title, mode);
      } catch (e) {
        fp.init(window, title, mode);
      }
      if (isText) fp.appendFilter("Text Files", "*.txt");
      else fp.appendFilter("HTML Files", "*.htm; *.html");
      fp.appendFilters(Ci.nsIFilePicker.filterAll);
      fp.defaultExtension = isText ? "txt" : "htm";
      fp.defaultString = fallbackName;

      const current = input.value.trim();
      if (current) {
        try {
          const f = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
          f.initWithPath(current);
          fp.defaultString = f.leafName;
          if (f.parent && f.parent.exists()) fp.displayDirectory = f.parent;
        } catch (e) {}
      }

      const res = await new Promise((resolve) => fp.open(resolve));
      if (res === Ci.nsIFilePicker.returnOK || res === Ci.nsIFilePicker.returnReplace) {
        input.value = fp.file.path;
        updateButtons();
      }
    } catch (e) {}
  }

  $("btn-browse").addEventListener("click", () => browsePath($("ie-export-path"), true));
  $("btn-browse-import").addEventListener("click", () => browsePath($("ie-import-path"), false));
  $("btn-browse-cookies").addEventListener("click", () =>
    browsePath($("ie-cookies-export-path"), true, "text")
  );
  for (const { input } of Object.values(PATH_PAGES)) {
    $(input).addEventListener("input", updateButtons);
  }

  function esc(s) {
    return String(s ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  const secs = (us) => Math.floor((us || 0) / 1000000);

  function renderFolder(node, title, depth, out) {
    const pad = "    ".repeat(depth);
    const cpad = pad + "    ";
    out.push(
      `${pad}<DT><H3 ADD_DATE="${secs(node.dateAdded)}" LAST_MODIFIED="${secs(node.lastModified)}">${esc(title)}</H3>`,
      `${pad}<DL><p>`
    );
    for (const c of node.children || []) {
      if (isSeparator(c)) {
        out.push(`${cpad}<HR>`);
      } else if (isContainer(c)) {
        renderFolder(c, c.title || "(unnamed)", depth + 1, out);
      } else if (c.uri) {
        out.push(
          `${cpad}<DT><A HREF="${esc(c.uri)}" ADD_DATE="${secs(c.dateAdded)}" LAST_MODIFIED="${secs(c.lastModified)}">${esc(c.title || c.uri)}</A>`
        );
      }
    }
    out.push(`${pad}</DL><p>`);
  }

  async function exportFavorites(path) {
    const folder = state.exportFolder || { guid: PlacesUtils.bookmarks.rootGuid, title: "Favorites" };

    if (folder.guid === PlacesUtils.bookmarks.rootGuid) {
      await BookmarkHTMLUtils.exportToFile(path);
      return;
    }

    const tree = await PlacesUtils.promiseBookmarksTree(folder.guid, { includeItemIds: false });
    const out = [
      "<!DOCTYPE NETSCAPE-Bookmark-file-1>",
      "<!-- This is an automatically generated file. -->",
      '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">',
      "<TITLE>Bookmarks</TITLE>",
      "<H1>Bookmarks</H1>",
      "<DL><p>",
    ];
    renderFolder(tree, folder.title, 1, out);
    out.push("</DL>");
    await IOUtils.writeUTF8(path, out.join("\n") + "\n");
  }

  async function exportCookies(path) {
    const lines = [
      "# Netscape HTTP Cookie File",
      "# https://curl.se/docs/http-cookies.html",
      "# Generated by the Import/Export Wizard.",
      "",
    ];
    for (const c of Services.cookies.cookies) {
      if (c.originAttributes && c.originAttributes.privateBrowsingId > 0) continue;
      lines.push([
        (c.isHttpOnly ? "#HttpOnly_" : "") + c.host,
        c.host.startsWith(".") ? "TRUE" : "FALSE",
        c.path,
        c.isSecure ? "TRUE" : "FALSE",
        c.isSession ? 0 : c.expiry,
        c.name,
        c.value,
      ].join("\t"));
    }
    await IOUtils.writeUTF8(path, lines.join("\n") + "\n");
  }

  async function importFavorites(path) {
    if (!(await IOUtils.exists(path))) {
      const err = new Error("not-found");
      err.notFound = true;
      throw err;
    }
    try {
      await BookmarkHTMLUtils.importFromFile(path, { replace: false });
    } catch (e) {
      const f = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
      f.initWithPath(path);
      await BookmarkHTMLUtils.importFromFile(f, { replace: false });
    }
  }

  async function runTask({ inputId, task, doneText, errorText }) {
    const path = $(inputId).value.trim();
    if (!path) return;
    busy = true;
    updateButtons();
    try {
      await task(path);
      $("ie-complete-text").textContent = doneText;
      busy = false;
      go(1);
    } catch (e) {
      busy = false;
      updateButtons();
      Services.prompt.alert(
        window,
        "Import/Export Wizard",
        (e && e.notFound ? "The file could not be found:\n" : errorText + "\n") + path
      );
    }
  }

  const ACTIONS = {
    "page-export-dest": () => runTask({
      inputId: "ie-export-path",
      task: exportFavorites,
      doneText: "Your settings have been successfully exported.",
      errorText: "The favorites could not be exported to:",
    }),
    "page-import-source": () => runTask({
      inputId: "ie-import-path",
      task: importFavorites,
      doneText: "Your settings have been successfully imported.",
      errorText: "The favorites could not be imported from:",
    }),
    "page-export-cookies": () => runTask({
      inputId: "ie-cookies-export-path",
      task: exportCookies,
      doneText: "Your settings have been successfully exported.",
      errorText: "The cookies could not be exported to:",
    }),
  };

  $("btn-cancel").addEventListener("click", () => window.close());
  $("btn-back").addEventListener("click", () => go(-1));
  $("btn-next").addEventListener("click", () => {
    if (ACTIONS[currentId]) return ACTIONS[currentId]();
    if (FINAL_PAGES.has(currentId)) return window.close();
    go(1);
  });

  function syncColorScheme(parentWin) {
    const src = parentWin.document.documentElement;
    const dst = document.documentElement;
    const sync = () => {
      const v = src.getAttribute("ie6-colorscheme");
      if (v) dst.setAttribute("ie6-colorscheme", v);
      else dst.removeAttribute("ie6-colorscheme");
    };
    sync();
    const mo = new parentWin.MutationObserver(sync);
    mo.observe(src, { attributes: true, attributeFilter: ["ie6-colorscheme"] });
    window.addEventListener("unload", () => { try { mo.disconnect(); } catch (e) {} }, { once: true });
  }

  try {
    const parentWin = Services.wm.getMostRecentWindow("navigator:browser");
    if (parentWin) syncColorScheme(parentWin);
  } catch (e) {}

  select(items[0]);
  show("page-welcome");
})();