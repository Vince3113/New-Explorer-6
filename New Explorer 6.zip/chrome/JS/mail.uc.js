(function () {
  const MAIL_KEY = "Software\\Clients\\Mail";
  const MENU_ITEMS = ["Read Mail", "New Message...", "Send a Link...", "Send Page..."];

  function readRegistry(root, path) {
    try {
      const key = Cc["@mozilla.org/windows-registry-key;1"].createInstance(Ci.nsIWindowsRegKey);
      key.open(root, path, Ci.nsIWindowsRegKey.ACCESS_READ);
      try {
        return key.readStringValue("");
      } finally {
        key.close();
      }
    } catch (e) {
      return null;
    }
  }

  function openMailto(uriString) {
    try {
      const service = Cc["@mozilla.org/uriloader/external-protocol-service;1"]
        .getService(Ci.nsIExternalProtocolService);
      service.loadURI(Services.io.newURI(uriString), Services.scriptSecurityManager.getSystemPrincipal());
    } catch (e) {}
  }

  function readMailClientCommand(clientName) {
    const local = Ci.nsIWindowsRegKey.ROOT_KEY_LOCAL_MACHINE;
    const suffix = `${clientName}\\shell\\open\\command`;
    const command =
      readRegistry(local, `${MAIL_KEY}\\${suffix}`) ||
      readRegistry(local, `Software\\WOW6432Node\\Clients\\Mail\\${suffix}`);
    if (!command) throw new Error(`Command for mail client '${clientName}' not found`);
    return command;
  }

  function readMail() {
    try {
      const clientName = readRegistry(Ci.nsIWindowsRegKey.ROOT_KEY_CURRENT_USER, MAIL_KEY);
      const command = readMailClientCommand(clientName);
      const match = command.match(/^"([^"]+)"/) || command.match(/^(\S+)/);

      const file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
      file.initWithPath(match ? match[1] : command);
      const process = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
      process.init(file);
      process.run(false, [], 0);
    } catch (e) {
      openMailto("mailto:");
    }
  }

  function composeMail(win, buildBody, errorLabel) {
    try {
      const { gBrowser } = win;
      const url = gBrowser.selectedBrowser.currentURI.spec;
      const title = gBrowser.contentTitle || gBrowser.selectedTab.label || url;
      openMailto(
        "mailto:?subject=" + encodeURIComponent(title) +
        "&body=" + encodeURIComponent(buildBody(title, url))
      );
    } catch (e) {}
  }

  function buildMenu(doc, win) {
    const popup = doc.createXULElement("menupopup");
    popup.className = "ie6-mail-menupopup";

    const handlers = [
      readMail,
      () => openMailto("mailto:"),
      () => composeMail(win, (title, url) => url, "Send a Link"),
      () => composeMail(win, (title, url) => title + "\r\n" + url, "Send Page"),
    ];

    MENU_ITEMS.forEach((label, i) => {
      const item = doc.createXULElement("menuitem");
      item.setAttribute("label", label);
      item.addEventListener("command", handlers[i]);
      popup.appendChild(item);
    });
    return popup;
  }

  function initMailButton(win) {
    const doc = win.document;
    const button = doc.getElementById("email-link-button");
    if (!button || button.hasAttribute("mail-wired")) return;
    button.setAttribute("mail-wired", "true");

    const marker = doc.createXULElement("box");
    marker.className = "ie6-mail-dropmarker";
    const iconBox = button.querySelector(".toolbarbutton-icon") || button;
    (iconBox.parentNode || button).appendChild(marker);

    const popup = buildMenu(doc, win);
    button.appendChild(popup);
    const openMenu = () => popup.openPopup(button, "after_start", 0, 0, true, false);

    button.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      openMenu();
    });
    button.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      openMenu();
    }, true);
  }

  function wireMostRecentWindow() {
    const win = Services.wm.getMostRecentWindow("navigator:browser");
    if (win && win.document.readyState === "complete") initMailButton(win);
  }

  wireMostRecentWindow();
  Services.wm.addListener({
    onOpenWindow(xulWin) {
      const w = xulWin.docShell.domWindow;
      w.addEventListener("load", () => initMailButton(w), { once: true });
    },
    onCloseWindow() {},
  });
  setTimeout(wireMostRecentWindow, 1500);
})();