(function () {
  "use strict";

  const XHTML_NS = "http://www.w3.org/1999/xhtml";
  const WINDOW_TYPE = "ie6-privacy-report-window";
  const LEARN_MORE_URL = "https://support.mozilla.org/kb/enhanced-tracking-protection-firefox-desktop";
  const MSG_NONE = "Based on your privacy settings, no cookies were restricted or blocked.";
  const MSG_SOME = "Based on your privacy settings, some cookies were restricted or blocked.";

  const $ = (id) => document.getElementById(id);

  let report = { sites: [], anyRestricted: false, originAttributes: {} };
  let filter = "all";
  let selectedKey = null;

  function el(tag, className, text) {
    const node = document.createElementNS(XHTML_NS, tag);
    if (className) node.className = className;
    if (text != null) node.textContent = text;
    return node;
  }

  function getBrowserWindow() {
    const opener = window.opener;
    if (opener && !opener.closed && opener.gBrowser) return opener;
    return Services.wm.getMostRecentWindow("navigator:browser");
  }

  function focusExistingInstance() {
    const windows = Services.wm.getEnumerator(WINDOW_TYPE);
    while (windows.hasMoreElements()) {
      const other = windows.getNext();
      if (other === window) continue;
      other.focus();
      window.close();
      return true;
    }
    return false;
  }

  function syncColorScheme() {
    const parentWin = getBrowserWindow();
    if (!parentWin) return;
    try {
      const src = parentWin.document.documentElement;
      const apply = () => {
        const scheme = src.getAttribute("ie6-colorscheme");
        if (scheme) document.documentElement.setAttribute("ie6-colorscheme", scheme);
        else document.documentElement.removeAttribute("ie6-colorscheme");
      };
      apply();

      const observer = new parentWin.MutationObserver(apply);
      observer.observe(src, { attributes: true, attributeFilter: ["ie6-colorscheme"] });
      window.addEventListener("unload", () => observer.disconnect(), { once: true });
    } catch (e) {}
  }

  function fallbackReport(browser) {
    const uri = browser.currentURI;
    const isWeb = uri.schemeIs("http") || uri.schemeIs("https");
    return {
      supported: isWeb,
      pageUrl: isWeb ? uri.specIgnoringRef : "",
      sites: isWeb
        ? [{ key: uri.prePath, host: uri.host, label: uri.specIgnoringRef, status: "", restricted: false }]
        : [],
      anyRestricted: false,
      originAttributes: {},
    };
  }

  async function refresh() {
    const win = getBrowserWindow();
    if (!win) return;

    const browser = win.gBrowser.selectedBrowser;
    try {
      report = win.IE6PrivacyReport ? await win.IE6PrivacyReport.getReport(browser) : fallbackReport(browser);
    } catch (e) {
      report = fallbackReport(browser);
    }
    selectedKey = null;
    showView("report");
    render();
  }

  const visibleSites = () => report.sites.filter((site) => filter === "all" || site.restricted);

  function updateSummaryButton() {
    $("pr-btn-summary").disabled = !selectedKey;
  }

  function render() {
    $("pr-message").textContent = report.anyRestricted ? MSG_SOME : MSG_NONE;

    const rows = visibleSites().map((site) => {
      const row = el("div", site.key === selectedKey ? "row selected" : "row");
      row.dataset.key = site.key;
      row.append(el("div", "c-site", site.label), el("div", "c-cookies", site.status));
      return row;
    });
    $("pr-site-list").replaceChildren(...rows);
    updateSummaryButton();
  }

  $("pr-site-list").addEventListener("mousedown", (e) => {
    const row = e.target.closest(".row");
    if (!row) return;

    selectedKey = row.dataset.key;
    for (const selected of $("pr-site-list").querySelectorAll(".row.selected")) {
      selected.classList.remove("selected");
    }
    row.classList.add("selected");
    updateSummaryButton();
  });

  const combo = $("pr-show");
  const comboText = combo.querySelector(".pr-combo-text");
  const comboItems = [...combo.querySelectorAll(".pr-combo-item")];

  const isOpen = () => combo.classList.contains("open");
  const itemIndex = () => comboItems.findIndex((item) => item.dataset.value === filter);

  function setActive(item) {
    for (const other of comboItems) other.classList.toggle("active", other === item);
  }

  function openCombo() {
    combo.classList.add("open");
    setActive(comboItems[itemIndex()]);
  }

  function closeCombo() {
    combo.classList.remove("open");
  }

  function choose(item) {
    filter = item.dataset.value;
    comboText.textContent = item.textContent;
    closeCombo();
    selectedKey = null;
    render();
  }

  combo.addEventListener("mousedown", (e) => {
    const item = e.target.closest(".pr-combo-item");
    if (item) choose(item);
    else if (!e.target.closest(".pr-combo-list")) {
      if (isOpen()) closeCombo();
      else openCombo();
    }
    combo.focus();
    e.preventDefault();
  });

  for (const item of comboItems) item.addEventListener("mouseover", () => setActive(item));

  document.addEventListener("mousedown", (e) => {
    if (!combo.contains(e.target)) closeCombo();
  });

  combo.addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      const step = e.key === "ArrowDown" ? 1 : -1;
      const base = isOpen() ? comboItems.findIndex((item) => item.classList.contains("active")) : itemIndex();
      const next = comboItems[Math.min(comboItems.length - 1, Math.max(0, base + step))];
      if (isOpen()) setActive(next);
      else choose(next);
      e.preventDefault();
    } else if (e.key === "Enter" || e.key === " ") {
      if (isOpen()) choose(comboItems.find((item) => item.classList.contains("active")) || comboItems[itemIndex()]);
      else openCombo();
      e.preventDefault();
    }
  });

  function collectCookies(host, originAttributes) {
    const cookies = new Map();
    const add = (list) => {
      for (const cookie of list) {
        const key = `${cookie.host}|${cookie.path}|${cookie.name}`;
        if (!cookies.has(key)) cookies.set(key, cookie);
      }
    };

    try {
      add(Services.cookies.getCookiesFromHost(host, originAttributes || {}));
    } catch {}
    try {
      add(Services.cookies.getCookiesWithOriginAttributes("{}", host));
    } catch {}

    return [...cookies.values()]
      .map((cookie) => ({
        name: cookie.name,
        domain: cookie.host,
        path: cookie.path,
        expires: cookie.isSession ? "End of session" : new Date(cookie.expiry * 1000).toLocaleString(),
      }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }

  function showView(name) {
    const isSummary = name === "summary";
    $("pr-report-view").hidden = isSummary;
    $("pr-summary-view").hidden = !isSummary;
    document.title = isSummary ? "Privacy Summary" : "Privacy Report";
  }

  function showSummary() {
    const site = report.sites.find((s) => s.key === selectedKey);
    if (!site) return;

    $("ps-title").textContent = site.host ? `Cookies for ${site.host}:` : "Cookies for this Web site:";

    const rows = collectCookies(site.host, report.originAttributes).map((cookie) => {
      const row = el("div", "row");
      row.title = cookie.domain;
      row.append(el("div", "c-name", cookie.name), el("div", "c-path", cookie.path), el("div", "c-exp", cookie.expires));
      return row;
    });
    if (!rows.length) {
      const empty = el("div", "row empty");
      empty.append(el("div", "c-name", "No cookies stored"));
      rows.push(empty);
    }

    const list = $("ps-cookie-list");
    list.replaceChildren(...rows);
    list.scrollTop = 0;
    showView("summary");
  }

  $("pr-btn-summary").addEventListener("click", () => {
    if (!$("pr-btn-summary").disabled) showSummary();
  });

  $("pr-btn-settings").addEventListener("click", () => {
    const win = getBrowserWindow();
    if (!win) return;
    try {
      win.openPreferences("privacy");
    } catch {
      try {
        win.openTrustedLinkIn("about:preferences#privacy", "tab");
      } catch {}
    }
    win.focus();
  });

  $("pr-learn-more").addEventListener("click", (e) => {
    e.preventDefault();
    const win = getBrowserWindow();
    if (!win) return;
    try {
      win.openTrustedLinkIn(LEARN_MORE_URL, "tab");
    } catch {}
    win.focus();
  });

  $("pr-btn-close").addEventListener("click", () => window.close());
  $("ps-btn-back").addEventListener("click", () => showView("report"));

  window.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    if (!$("pr-summary-view").hidden) showView("report");
    else if (isOpen()) closeCombo();
    else window.close();
  });

  window.ie6PrivacyReportRefresh = refresh;

  if (!focusExistingInstance()) {
    syncColorScheme();
    refresh();
  }
})();