(function () {
  const { CustomizableUI } = ChromeUtils.importESModule(
    "moz-src:///browser/components/customizableui/CustomizableUI.sys.mjs"
  );

  CustomizableUI.createWidget({
    id: "ie6-media-button",
    type: "button",
    label: "Media",
    tooltiptext: "Media",
    onCommand() {
      window.ie6ToggleMediaSidebar?.();
    },
    onCreated(node) {
      const doc = node.ownerDocument;
      doc.defaultView.setTimeout(() => {
        if (node.querySelector(".ie6-btn-label")) return;
        const label = doc.createXULElement("label");
        label.className = "ie6-btn-label";
        label.setAttribute("value", "Media");
        node.appendChild(label);
      }, 0);
    },
  });
})();