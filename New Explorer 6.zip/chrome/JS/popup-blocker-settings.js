(function () {
  const HTML_NS = "http://www.w3.org/1999/xhtml";
  const WINDOW_TYPE = "ie6-popupblocker-settings";
  const PERM_TYPE = "popup";
  const PREF_SOUND = "extensions.ie6theme.popupblocker.playSound";
  const PREF_INFOBAR = "privacy.popups.showBrowserMessage";
  const PREF_FILTERLEVEL = "extensions.ie6theme.popupblocker.filterLevel";
  const PREF_ALLOWED_EVENTS = "dom.popup_allowed_events";
  const FAQ_URL = "https://support.mozilla.org/kb/pop-blocker-settings-exceptions-troubleshooting";

  const $ = (id) => document.getElementById(id);

  let selectedRow = null;
  let selectedPerm = null;

  function allowedPerms() {
    return [...Services.perms.all].filter(
      (perm) => perm.type === PERM_TYPE && perm.capability === Services.perms.ALLOW_ACTION
    );
  }

  function refreshList() {
    const list = $("ie6pb-list");
    const removeBtn = $("ie6pb-btn-remove");
    list.replaceChildren();
    selectedRow = null;
    selectedPerm = null;
    removeBtn.disabled = true;

    const perms = allowedPerms();
    $("ie6pb-btn-removeall").disabled = !perms.length;

    for (const perm of perms) {
      const row = document.createElementNS(HTML_NS, "div");
      row.className = "ie6pb-site-row";
      row.textContent = perm.principal.host || perm.principal.origin;
      row.addEventListener("click", () => {
        if (selectedRow) selectedRow.classList.remove("selected");
        selectedRow = row;
        selectedPerm = perm;
        row.classList.add("selected");
        removeBtn.disabled = false;
      });
      list.appendChild(row);
    }
  }

  function normalizeToURI(value) {
    let v = value.trim();
    if (!v) return null;
    if (!/^[a-z]+:\/\//i.test(v)) v = "https://" + v;
    try {
      return Services.io.newURI(v);
    } catch (e) {
      return null;
    }
  }

  function addSite() {
    const input = $("ie6pb-allow-input");
    const uri = normalizeToURI(input.value);
    if (!uri) return;
    try {
      const principal = Services.scriptSecurityManager.createContentPrincipal(uri, {});
      Services.perms.addFromPrincipal(principal, PERM_TYPE, Services.perms.ALLOW_ACTION);
      input.value = "";
      refreshList();
    } catch (e) {}
  }

  function removeSelected() {
    if (!selectedPerm) return;
    try {
      Services.perms.removeFromPrincipal(selectedPerm.principal, PERM_TYPE);
      refreshList();
    } catch (e) {}
  }

  function removeAll() {
    try {
      for (const perm of allowedPerms()) {
        Services.perms.removeFromPrincipal(perm.principal, PERM_TYPE);
      }
      refreshList();
    } catch (e) {}
  }

  function applyFilterLevel(level) {
    Services.prefs.setCharPref(PREF_FILTERLEVEL, level);
    if (level === "high") Services.prefs.setCharPref(PREF_ALLOWED_EVENTS, "");
    else Services.prefs.clearUserPref(PREF_ALLOWED_EVENTS);
  }

  function currentFilterLevel() {
    const level = Services.prefs.getCharPref(PREF_FILTERLEVEL, "medium");
    if (Services.prefs.getCharPref(PREF_ALLOWED_EVENTS, "x") === "") return "high";
    return level === "high" ? "medium" : level;
  }

  function setupCombo(initialValue, onChange) {
    const combo = $("ie6pb-filterlevel");
    const text = combo.querySelector(".ie6pb-combo-text");
    const items = [...combo.querySelectorAll(".ie6pb-combo-item")];
    const indexOf = (v) => items.findIndex((it) => it.dataset.value === v);

    let value = initialValue;
    let activeIndex = Math.max(0, indexOf(value));
    text.textContent = items[activeIndex].textContent;

    const isOpen = () => combo.classList.contains("open");
    const close = () => combo.classList.remove("open");

    function highlight(idx) {
      activeIndex = idx;
      items.forEach((it, i) => it.classList.toggle("active", i === idx));
    }

    function open() {
      highlight(indexOf(value));
      combo.classList.add("open");
    }

    function choose(idx) {
      value = items[idx].dataset.value;
      activeIndex = idx;
      text.textContent = items[idx].textContent;
      onChange(value);
    }

    combo.addEventListener("click", (e) => {
      const item = e.target.closest(".ie6pb-combo-item");
      if (item) {
        choose(items.indexOf(item));
        close();
      } else if (isOpen()) {
        close();
      } else {
        open();
      }
    });

    items.forEach((it, i) => it.addEventListener("mouseover", () => highlight(i)));

    combo.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && isOpen()) {
        e.preventDefault();
        e.stopPropagation();
        close();
      } else if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        const step = e.key === "ArrowDown" ? 1 : -1;
        const next = Math.min(items.length - 1, Math.max(0, activeIndex + step));
        if (isOpen()) highlight(next);
        else choose(next);
      } else if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        if (isOpen()) {
          choose(activeIndex);
          close();
        } else {
          open();
        }
      }
    });

    document.addEventListener("mousedown", (e) => {
      if (!combo.contains(e.target)) close();
    });
    window.addEventListener("blur", close);
  }

  function loadPrefs() {
    const soundChk = $("ie6pb-chk-sound");
    const infobarChk = $("ie6pb-chk-infobar");
    soundChk.checked = Services.prefs.getBoolPref(PREF_SOUND, true);
    infobarChk.checked = Services.prefs.getBoolPref(PREF_INFOBAR, true);

    soundChk.addEventListener("change", () => {
      Services.prefs.setBoolPref(PREF_SOUND, soundChk.checked);
    });
    infobarChk.addEventListener("change", () => {
      Services.prefs.setBoolPref(PREF_INFOBAR, infobarChk.checked);
    });

    setupCombo(currentFilterLevel(), applyFilterLevel);
  }

  function closeIfDuplicate() {
    try {
      const windows = Services.wm.getEnumerator(WINDOW_TYPE);
      let count = 0;
      let first = null;
      while (windows.hasMoreElements()) {
        const win = windows.getNext();
        count++;
        if (!first) first = win;
      }
      if (count > 1 && first && first !== window) {
        first.focus();
        window.close();
        return true;
      }
    } catch (e) {}
    return false;
  }

  function syncColorScheme(parentWin) {
    try {
      const srcRoot = parentWin.document.documentElement;
      const dstRoot = document.documentElement;
      const apply = () => {
        const v = srcRoot.getAttribute("ie6-colorscheme");
        if (v) dstRoot.setAttribute("ie6-colorscheme", v);
        else dstRoot.removeAttribute("ie6-colorscheme");
      };
      apply();
      const mo = new parentWin.MutationObserver(apply);
      mo.observe(srcRoot, { attributes: true, attributeFilter: ["ie6-colorscheme"] });
      window.addEventListener("unload", () => { try { mo.disconnect(); } catch (e) {} }, { once: true });
    } catch (e) {}
  }

  function init() {
    if (closeIfDuplicate()) return;

    const parentWin = Services.wm.getMostRecentWindow("navigator:browser");
    if (parentWin) syncColorScheme(parentWin);

    refreshList();
    loadPrefs();
    window.resizeTo(433, 480);

    $("ie6pb-btn-add").addEventListener("click", addSite);
    $("ie6pb-allow-input").addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        addSite();
      }
    });
    $("ie6pb-btn-remove").addEventListener("click", removeSelected);
    $("ie6pb-btn-removeall").addEventListener("click", removeAll);
    $("ie6pb-btn-close").addEventListener("click", () => window.close());
    $("ie6pb-link-faq").addEventListener("click", () => {
      if (!parentWin) return;
      parentWin.gBrowser.selectedTab = parentWin.gBrowser.addTab(FAQ_URL, {
        triggeringPrincipal: Services.scriptSecurityManager.getSystemPrincipal(),
      });
    });

    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        window.close();
      }
    });
  }

  window.addEventListener("load", init, { once: true });
})();