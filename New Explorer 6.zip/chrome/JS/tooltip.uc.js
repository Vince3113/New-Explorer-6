(function () {
  const BOX_ID = "custom-tooltip";
  const SHOW_DELAY = 500;
  const HIDE_DISTANCE = 15;
  const NATIVE_TOOLTIP_IDS = new Set(["bhTooltip", "remote-trot-tooltip", "aTooltip"]);

  let box = null;
  let showTimer = null;
  let contentShowTimer = null;
  let currentTarget = null;
  let panelOpen = false;
  let mouseX = 0;
  let mouseY = 0;

  try {
    ChromeUtils.registerWindowActor("IE6Tooltip", {
      parent: { esModuleURI: "resource://ie6theme/actors/IE6TooltipParent.sys.mjs" },
      child: {
        esModuleURI: "resource://ie6theme/actors/IE6TooltipChild.sys.mjs",
        events: {
          mouseover: { mozSystemGroup: true },
          mouseout: { mozSystemGroup: true },
        },
      },
      allFrames: true,
    });
  } catch (e) {
    if (!String(e).includes("already registered") && !String(e).includes("already exists")) {}
  }

  const isNativeTooltip = (el) =>
    !!el && (el.localName === "tooltip" || NATIVE_TOOLTIP_IDS.has(el.id));

  function ensureBox() {
    if (box && box.isConnected) return box;
    box = document.createElement("div");
    box.id = BOX_ID;
    document.documentElement.appendChild(box);
    return box;
  }

  function showBox(text, x, y, isToolbar) {
    if (!text) return;
    const b = ensureBox();
    b.textContent = text;
    b._originX = x;
    b._originY = y;

    b.style.display = "block";
    b.style.left = "0px";
    b.style.top = "0px";

    const boxWidth = b.offsetWidth;
    const boxHeight = b.offsetHeight;
    const winWidth = window.innerWidth;
    const winHeight = window.innerHeight;

    let left = x + 12;
    let top = y + (isToolbar ? 4 : 20);

    if (left + boxWidth > winWidth - 10) {
      left = winWidth - boxWidth - 10;
      if (left < x) left = Math.max(10, x - boxWidth - 5);
    }
    if (top + boxHeight > winHeight - 10) {
      top = y - boxHeight - 8;
    }

    if (isToolbar) {
      const urlbar = document.getElementById("urlbar");
      if (urlbar) {
        const r = urlbar.getBoundingClientRect();
        const overlapsVertically = top < r.bottom && top + boxHeight > r.top;
        const overlapsHorizontally = left < r.right && left + boxWidth > r.left;
        if (overlapsVertically && overlapsHorizontally) top = y - boxHeight - 8;
      }
    }

    b.style.left = Math.max(5, left) + "px";
    b.style.top = Math.max(5, top) + "px";
  }

  function hideBox() {
    clearTimeout(showTimer);
    if (box) {
      box.style.display = "none";
      delete box._originX;
      delete box._originY;
    }
    currentTarget = null;
  }

  window.__tooltipShowFromContent = function (text, x, y) {
    clearTimeout(contentShowTimer);
    hideBox();
    if (panelOpen) return;

    mouseX = x;
    mouseY = y;
    contentShowTimer = setTimeout(() => {
      if (!panelOpen) showBox(text, x, y, false);
    }, SHOW_DELAY);
  };

  window.__tooltipHideFromContent = function () {
    clearTimeout(contentShowTimer);
    hideBox();
  };

  function getTooltipText(node) {
    for (let el = node; el && el.nodeType === 1; el = el.parentElement || el.host || null) {
      if (el.id === "PlacesToolbarItems" || el.id === "PersonalToolbar") return null;

      if (el.id === "PlacesChevron") return "Mostrar más marcadores";

      if (el.id === "OtherBookmarks" || el.classList.contains("bookmarks-actions-menupopup")) {
        return el.getAttribute("label") || "Otros marcadores";
      }

      if (el.classList.contains("bookmark-item")) {
        if (el.getAttribute("container") === "true" && el.getAttribute("place")?.includes("unfiled")) {
          return el.getAttribute("label") || "Otros marcadores";
        }
        if (el._placesNode) {
          const title = el._placesNode.title;
          if (title === "unfiled" || title === "unfiled-bookmarks-folder") {
            return el.getAttribute("label") || "Otros marcadores";
          }
          return title || el._placesNode.uri || el.getAttribute("label");
        }
        return el.getAttribute("label") || el.getAttribute("aria-label");
      }

      if (el.localName === "tab") {
        return el.getAttribute("label") || el.getAttribute("tooltiptext");
      }
      if (el.classList.contains("tab-close-button")) return "Close Tab";

      if (el.getAttribute("tooltiptext")) return el.getAttribute("tooltiptext");
      if (el.getAttribute("title")) return el.getAttribute("title");
    }
    return null;
  }

  window.addEventListener("mousemove", (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;

    if (box && box.style.display === "block" && box._originX !== undefined) {
      if (Math.hypot(mouseX - box._originX, mouseY - box._originY) > HIDE_DISTANCE) hideBox();
    }
  }, true);

  window.addEventListener("mouseover", (e) => {
    if (e.target.localName === "browser" || e.target.localName === "stack") return;

    for (let el = e.target; el && el.nodeType === 1; el = el.parentElement) {
      if (el.hasAttribute("tooltiptext")) {
        el.setAttribute("data-tooltip", el.getAttribute("tooltiptext"));
        el.removeAttribute("tooltiptext");
      }
      if (el.hasAttribute("tooltip")) el.removeAttribute("tooltip");
    }

    const text = getTooltipText(e.target) || (e.target.getAttribute && e.target.getAttribute("data-tooltip"));
    if (!text) {
      hideBox();
      return;
    }

    if (e.target === currentTarget) return;
    hideBox();
    currentTarget = e.target;

    showTimer = setTimeout(() => {
      if (!panelOpen) {
        showBox(text, mouseX, mouseY, !!e.target.closest?.("#nav-bar"));
      }
    }, SHOW_DELAY);
  }, true);

  window.addEventListener("mouseout", (e) => {
    if (currentTarget && !currentTarget.contains(e.relatedTarget)) hideBox();
  }, true);

  window.addEventListener("popupshowing", (e) => {
    const t = e.target;
    if (!isNativeTooltip(t)) return;
    e.preventDefault();
    e.stopPropagation();

    let text = t.getAttribute("label") || "";
    if (!text && t.triggerNode) {
      text = getTooltipText(t.triggerNode) || t.triggerNode.getAttribute("title") || t.triggerNode.title || "";
    }
    if (text && !panelOpen) {
      hideBox();
      showBox(text, mouseX, mouseY, !!t.triggerNode?.closest?.("#nav-bar"));
    }
  }, true);

  window.addEventListener("popuphiding", (e) => {
    if (isNativeTooltip(e.target)) hideBox();
  }, true);

  const isPanelOrMenu = (el) => el.localName === "panel" || el.localName === "menupopup";

  window.addEventListener("popupshown", (e) => {
    if (isPanelOrMenu(e.target)) {
      panelOpen = true;
      hideBox();
    }
  }, true);

  window.addEventListener("popuphidden", (e) => {
    if (isPanelOrMenu(e.target)) panelOpen = false;
  }, true);

  for (const type of ["mousedown", "keydown", "scroll", "wheel"]) {
    window.addEventListener(type, hideBox, true);
  }
})();