(function () {
  "use strict";

  const LOG = "[suggestions]";
  const ROW_MIN_HEIGHT = "18px";
  const FAVICON_SIZE = "16px";
  const SELECTED_BG = "#316AC5";
  const SELECTED_FG = "#ffffff";
  const NORMAL_FG = "#000000";
  const IMG = "resource://ie6theme/images/";

  const BOOKMARK_ICON_STYLE = {
    "background-image": `url("${IMG}favorites-small.png")`,
    "background-repeat": "no-repeat",
    "background-position": "center",
    "background-size": "contain",
    width: "16px",
    height: "16px",
    "min-width": "16px",
    "min-height": "16px",
    "max-width": "16px",
    "max-height": "16px",
    display: "inline-block",
    "flex-shrink": "0",
    padding: "0",
    margin: "0",
    "margin-inline-start": "4px",
    "align-self": "center",
    "vertical-align": "middle",
    position: "static",
    top: "auto",
    left: "auto",
    right: "auto",
    bottom: "auto",
    transform: "none",
  };

  const SWITCH_TAB_STYLE = {
    "background-image": `url("${IMG}changetab.png")`,
    "background-repeat": "no-repeat",
    "background-position": "center",
    "background-size": "contain",
    width: "16px",
    height: "16px",
    "min-width": "16px",
    "min-height": "16px",
    padding: "0",
    margin: "0",
    "margin-inline-start": "4px",
    border: "none",
    "border-radius": "0",
    "background-color": "transparent",
    "box-shadow": "none",
    "flex-shrink": "0",
    "align-self": "center",
  };

  let mutationObserver = null;
  let rafScheduled = false;
  const pendingRows = new Set();

  const setStyles = (el, props, important = false) => {
    for (const [name, value] of Object.entries(props)) {
      el.style.setProperty(name, value, important ? "important" : "");
    }
  };

  const styleEl = document.createElement("style");
  styleEl.textContent = `
    @keyframes slideDown {
      from { max-height: 0; opacity: 0.5; }
      to { max-height: 400px; opacity: 1; }
    }

    #urlbar-results,
    .urlbarView {
      overflow: hidden !important;
      animation: slideDown 0.12s ease-out forwards !important;
      transform-origin: top !important;
    }

    .urlbarView-quickactions,
    .urlbarView-searchmode-buttons,
    .urlbarView-one-off-search-buttons {
      display: none !important;
    }
  `;
  document.head.appendChild(styleEl);

  function scheduleStyleRow(row) {
    pendingRows.add(row);
    if (rafScheduled) return;
    rafScheduled = true;
    requestAnimationFrame(() => {
      rafScheduled = false;
      const rows = [...pendingRows];
      pendingRows.clear();
      for (const row of rows) {
        try {
          styleRow(row);
        } catch (e) {}
      }
      if (mutationObserver) mutationObserver.takeRecords();
    });
  }

  function paintRow(row, active) {
    row.style.backgroundColor = active ? SELECTED_BG : "";
    const color = active ? SELECTED_FG : NORMAL_FG;
    for (const sel of [".urlbarView-url", ".urlbarView-title", ".urlbarView-action"]) {
      const el = row.querySelector(sel);
      if (el) el.style.color = color;
    }
  }

  function applyActiveState(row, active) {
    row.dataset.active = active ? "1" : "0";
    paintRow(row, active);
  }

  function hasBookmarkData(row, rowType, typeIcon) {
    if (rowType.includes("bookmark") || typeIcon.classList.contains("urlbarView-type-icon-bookmark")) {
      return true;
    }
    const result = row.result || row._resultForTesting;
    return !!(
      result &&
      (result.isBookmarked || result.payload?.isBookmarked || result.payload?.bookmarkTitle)
    );
  }

  function styleRow(row) {
    if (row.getAttribute("type") === "tabtosearch" || row.querySelector('[data-action="contextual-search"]')) {
      row.style.setProperty("display", "none", "important");
      return;
    }

    if (row.dataset.enforced !== "1") {
      row.dataset.enforced = "1";
      row.addEventListener("mouseenter", () => applyActiveState(row, true));
      row.addEventListener("mouseleave", () => applyActiveState(row, false));
    }

    setStyles(row, { "border-radius": "0", "margin-inline": "0" }, true);

    if (row.parentElement) {
      setStyles(row.parentElement, {
        "padding-top": "0",
        "padding-bottom": "0",
        "margin-top": "0",
        "margin-bottom": "0",
      }, true);
    }
    if (row.previousElementSibling === null) {
      setStyles(row, { "margin-top": "0", "padding-top": "0" }, true);
    }
    if (row.nextElementSibling === null) {
      setStyles(row, { "margin-bottom": "0", "padding-bottom": "0" }, true);
    }

    row.style.minHeight = ROW_MIN_HEIGHT;
    const inner = row.querySelector(".urlbarView-row-inner") || row;
    setStyles(inner, {
      "min-height": ROW_MIN_HEIGHT,
      "padding-block": "1px",
      "padding-inline-start": "4px",
      gap: "2px",
      display: "flex",
      "flex-direction": "row",
      "align-items": "center",
    });
    inner.style.setProperty("border-radius", "0", "important");

    const favicon = row.querySelector(".urlbarView-favicon") || row.querySelector("image, img");
    if (favicon) {
      setStyles(favicon, {
        width: FAVICON_SIZE,
        height: FAVICON_SIZE,
        "margin-inline-end": "4px",
        "flex-shrink": "0",
        "align-self": "center",
        "vertical-align": "middle",
        display: "block",
      });
    }

    const rowType = row.getAttribute("type") || row.dataset.type || "";
    const isSearchRow = rowType.includes("search") || row.getAttribute("search") !== null;

    const title = row.querySelector(".urlbarView-title");
    if (title) title.style.display = "none";

    if (isSearchRow) {
      if (favicon) {
        setStyles(favicon, {
          content: `url("${IMG}search14.png")`,
          "list-style-image": `url("${IMG}search14.png")`,
        }, true);
      }

      const searchAction = row.querySelector(".urlbarView-action");
      if (searchAction) {
        const query = document.getElementById("urlbar-input")?.value.trim() || "";
        searchAction.textContent = query ? `Search For "${query}"` : "Search";
        setStyles(searchAction, {
          display: "inline",
          color: NORMAL_FG,
          "font-size": "var(--ie6-font-size)",
          "font-family": "var(--ie6-font-family)",
        });
      }
    } else if (favicon) {
      favicon.style.removeProperty("content");
      favicon.style.removeProperty("list-style-image");
    }

    const separator = row.querySelector(".urlbarView-title-separator");
    if (separator) separator.style.display = "none";

    const url = row.querySelector(".urlbarView-url");
    if (url) {
      setStyles(url, {
        color: NORMAL_FG,
        "text-decoration": "none",
        "font-size": "var(--ie6-font-size)",
        "font-family": "var(--ie6-font-family)",
        "align-self": "center",
        "line-height": "normal",
      });
    }

    const menuButton = row.querySelector(".urlbarView-button-menu");
    if (menuButton) menuButton.style.setProperty("display", "none", "important");

    const typeIcon = row.querySelector(".urlbarView-type-icon");
    if (typeIcon) {
      if (hasBookmarkData(row, rowType, typeIcon)) {
        setStyles(typeIcon, BOOKMARK_ICON_STYLE, true);
        inner.appendChild(typeIcon);
      } else {
        typeIcon.style.setProperty("display", "none", "important");
      }
    }

    const switchToTab = row.querySelector(".urlbarView-action.urlbarView-switchToTab");
    if (switchToTab) {
      switchToTab.textContent = "";
      setStyles(switchToTab, SWITCH_TAB_STYLE);
      inner.appendChild(switchToTab);

      if (url) {
        setStyles(url, { display: "inline", visibility: "visible", opacity: "1" });
      }
    }

    const isSelected =
      row.hasAttribute("selected") ||
      row.getAttribute("aria-selected") === "true" ||
      inner.getAttribute("aria-selected") === "true";
    paintRow(row, row.dataset.active === "1" || isSelected);
  }

  function initObserver() {
    const urlbar = document.getElementById("urlbar");
    if (!urlbar) return;

    for (const sel of [
      ".urlbarView",
      "#urlbar-results",
      ".urlbarView-results",
      ".urlbarView-body-outer",
      ".urlbarView-body-inner",
    ]) {
      const el = document.querySelector(sel);
      if (el) {
        setStyles(el, {
          "margin-top": "0",
          "margin-bottom": "0",
          "padding-top": "0",
          "padding-bottom": "0",
          "border-radius": "0",
        }, true);
      }
    }

    mutationObserver = new MutationObserver((mutations) => {
      for (const m of mutations) {
        for (const node of m.addedNodes) {
          if (node.nodeType !== 1) continue;
          if (node.matches(".urlbarView-row")) scheduleStyleRow(node);
          node.querySelectorAll(".urlbarView-row").forEach(scheduleStyleRow);
        }
        const el = m.target.nodeType === 1 ? m.target : m.target.parentElement;
        const row = el?.closest(".urlbarView-row");
        if (row) scheduleStyleRow(row);
      }
      mutationObserver.takeRecords();
    });

    mutationObserver.observe(urlbar, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: ["selected", "aria-selected"],
    });

    urlbar.querySelectorAll(".urlbarView-row").forEach(styleRow);
  }

  if (gBrowserInit?.delayedStartupFinished) {
    initObserver();
    return;
  }

  const onStartup = (subject, topic) => {
    if (subject !== window) return;
    Services.obs.removeObserver(onStartup, topic);
    initObserver();
  };
  Services.obs.addObserver(onStartup, "browser-delayed-startup-finished");
})();