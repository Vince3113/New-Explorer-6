const { Downloads } = ChromeUtils.importESModule(
  "resource://gre/modules/Downloads.sys.mjs"
);

const XHTML = "http://www.w3.org/1999/xhtml";
const UNITS = ["bytes", "KB", "MB", "GB", "TB"];
const TOOLTIP_DELAY = 400;

const rows = new Map();
const nodes = new Map();

let download = window.arguments?.[0] || null;
let mode = "list";
let list = null;
let view = null;
let finished = false;
let selected = null;
let searchQuery = "";
let schemeObserver = null;

function $(id) {
  let node = nodes.get(id);
  if (!node) {
    node = document.getElementById(id);
    nodes.set(id, node);
  }
  return node;
}

function swallow() {}

function h(tag, className) {
  const el = document.createElementNS(XHTML, tag);
  if (className) el.className = className;
  return el;
}

function targetPath(d) {
  try {
    return d.target.path || "";
  } catch (e) {
    return "";
  }
}

function fileName(d) {
  return targetPath(d).split(/[\\/]/).pop() || "file";
}

function hostName(d) {
  try {
    return new URL(d.source.url).hostname;
  } catch (e) {
    return "";
  }
}

function sourceURL(d) {
  try {
    return d.source.url || "";
  } catch (e) {
    return "";
  }
}

function iconURL(name) {
  const dot = name.lastIndexOf(".");
  const ext = dot >= 0 ? name.slice(dot + 1) : "file";
  return `moz-icon://x.${encodeURIComponent(ext)}?size=24`;
}

function formatBytes(bytes) {
  let value = bytes > 0 ? bytes : 0;
  let i = 0;
  while (value >= 1024 && i < UNITS.length - 1) {
    value /= 1024;
    i++;
  }
  const decimals = i <= 1 ? 0 : 2;
  return `${value.toLocaleString(undefined, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })} ${UNITS[i]}`;
}

function formatTime(totalSeconds) {
  if (!isFinite(totalSeconds) || totalSeconds < 0) return "Unknown";
  const s = Math.max(1, Math.round(totalSeconds));
  const pad = (n) => String(n).padStart(2, "0");
  if (s < 60) return `${s} sec`;
  if (s < 3600) return `${Math.floor(s / 60)} min ${pad(s % 60)} sec`;
  return `${Math.floor(s / 3600)} hr ${pad(Math.floor((s % 3600) / 60))} min`;
}

function compactPath(path, max = 44) {
  if (path.length <= max) return path;
  const head = 18;
  return `${path.slice(0, head)}...${path.slice(path.length - (max - head - 3))}`;
}

function percent(d) {
  if (d.succeeded) return 100;
  if (!(d.totalBytes > 0)) return 0;
  return Math.min(100, Math.floor((d.currentBytes / d.totalBytes) * 100));
}

function isPaused(d) {
  return !!d && d.canceled && !d.error && !d.__userCanceled && d.hasPartialData;
}

function isRemovable(d) {
  return d.stopped && (!d.hasPartialData || !!d.error);
}

function stateOf(d) {
  if (!d.canceled || d.error) return "";
  return isPaused(d) ? "Paused" : "Canceled";
}

async function cancelAndClean(d) {
  d.__userCanceled = true;
  try {
    await d.cancel();
    await d.removePartialData();
  } catch (e) {}
  updateRow(d);
}

function restart(d) {
  d.__userCanceled = false;
  d.start().catch(swallow);
}

async function openDownloadsFolder() {
  try {
    const { FileUtils } = ChromeUtils.importESModule(
      "resource://gre/modules/FileUtils.sys.mjs"
    );
    const dir = new FileUtils.File(await Downloads.getPreferredDownloadsDirectory());
    try {
      dir.launch();
    } catch (e) {
      dir.reveal();
    }
  } catch (e) {
    console.error("download-window: could not open downloads folder", e);
  }
}

function setMode(next) {
  mode = next;
  $("dl-root").setAttribute("view", next);
}

function showList() {
  download = null;
  setMode("list");
  document.title = "Downloads";
}

function showDetail(d) {
  download = d;
  finished = d.succeeded;
  setMode("detail");
  render();
}

function render() {
  const d = download;
  if (!d) return;

  if (d.canceled && !d.error) {
    showList();
    return;
  }

  const name = fileName(d);
  const host = hostName(d);
  const path = targetPath(d);
  const done = d.succeeded;
  const failed = !!d.error;
  const started = d.currentBytes > 0 || done || failed;
  const hasTotal = d.totalBytes > 0;

  let status = "Getting File information:";
  let timeLabel = "Estimated time left:";
  let timeValue = "";
  let rate = "";
  let title = "File Download";

  if (done) {
    const seconds = Math.max(1, ((d.endTime || Date.now()) - (d.startTime || Date.now())) / 1000);
    const size = hasTotal ? d.totalBytes : d.currentBytes;
    status = "Saved:";
    timeLabel = "Downloaded:";
    timeValue = `${formatBytes(size)} in ${formatTime(seconds)}`;
    rate = `${formatBytes(size / seconds)}/Sec`;
    title = "Download Complete";
  } else if (failed) {
    status = "Download failed:";
    timeLabel = "Status:";
    timeValue = "Download failed";
  } else if (started) {
    const remaining =
      d.speed > 0 && hasTotal ? formatTime((d.totalBytes - d.currentBytes) / d.speed) : "Unknown";
    const copied = hasTotal
      ? `${formatBytes(d.currentBytes)} of ${formatBytes(d.totalBytes)} copied`
      : `${formatBytes(d.currentBytes)} copied`;
    status = "Saving:";
    timeValue = `${remaining} (${copied})`;
    rate = `${formatBytes(d.speed)}/Sec`;
  }

  $("dl-file").textContent = host ? `${name} from ${host}` : name;
  $("dl-fill").style.width = `${percent(d)}%`;
  $("dl-icon").classList.toggle("dl-done", done);
  $("dl-info").classList.toggle("dl-hidden", !started);
  $("dl-to-value").textContent = compactPath(path);
  $("dl-to-value").title = path;
  $("dl-status").textContent = status;
  $("dl-time-label").textContent = timeLabel;
  $("dl-time-value").textContent = timeValue;
  $("dl-rate-value").textContent = rate;
  $("dl-open").disabled = !done;
  $("dl-folder").disabled = !done;
  $("dl-cancel").textContent = done || failed ? "Close" : "Cancel";
  document.title = title;

  if (done && !finished) {
    finished = true;
    if ($("dl-close-check").checked) window.close();
  }
}

function createRow(d) {
  const root = h("div", "dl-row");
  const icon = h("img", "dl-row-icon");
  const name = h("div", "dl-row-name");
  const bar = h("div", "dl-row-bar");
  const frame = h("progress", "dl-row-frame");
  const track = h("div", "dl-row-track");
  const fill = h("div", "dl-row-fill");
  const status = h("div", "dl-row-status");

  frame.setAttribute("max", "100");
  frame.setAttribute("value", "0");
  track.appendChild(fill);
  bar.append(frame, track);
  root.append(icon, name, bar, status);
  root.addEventListener("click", () => select(d));

  return {
    root,
    icon,
    name,
    fill,
    status,
    state: null,
    nameText: null,
    haystack: "",
    pct: -1,
    key: "",
  };
}

function select(d) {
  if (selected) rows.get(selected)?.root.classList.remove("dl-selected");
  selected = d;
  if (d) rows.get(d)?.root.classList.add("dl-selected");
  updateToolbar();
}

function addRow(d) {
  if (rows.has(d)) return;
  const row = createRow(d);
  rows.set(d, row);
  $("dl-list").prepend(row.root);
  updateRow(d);
}

function removeRow(d) {
  const row = rows.get(d);
  if (!row) return;
  row.root.remove();
  rows.delete(d);
  if (selected === d) selected = null;
  updateDelete();
  updateToolbar();
}

function updateRow(d) {
  const row = rows.get(d);
  if (!row) return;

  const state = stateOf(d);
  if (row.state !== state) {
    row.state = state;
    row.root.classList.toggle("dl-stopped", !!state);
    row.status.textContent = state;
  }

  const name = fileName(d);
  if (row.nameText !== name) {
    row.nameText = name;
    row.name.textContent = name;
    row.icon.src = iconURL(name);
    row.haystack = `${name} ${sourceURL(d)}`.toLowerCase();
  }

  const pct = percent(d);
  if (row.pct !== pct) {
    row.pct = pct;
    row.fill.style.width = `${pct}%`;
  }

  if (searchQuery) applyRowFilter(d);

  const key = `${d.stopped}|${d.succeeded}|${d.hasPartialData}|${!!d.error}|${state}`;
  if (row.key !== key) {
    row.key = key;
    updateDelete();
    if (d === selected) updateToolbar();
  }
}

function updateDelete() {
  let removable = false;
  for (const d of rows.keys()) {
    if (isRemovable(d)) {
      removable = true;
      break;
    }
  }
  $("dl-list-delete").disabled = !removable;
}

function updateToolbar() {
  const d = selected;
  const paused = isPaused(d);
  const running = !!d && !d.stopped;
  const restartable = !!d && d.stopped && !d.succeeded && !paused;

  $("dl-slot-pause").style.display = paused ? "none" : "";
  $("dl-slot-resume").style.display = paused ? "" : "none";
  $("dl-slot-cancel").style.display = restartable ? "none" : "";
  $("dl-slot-retry").style.display = restartable ? "" : "none";
  $("dl-list-pause").disabled = !running;
  $("dl-list-resume").disabled = !paused;
  $("dl-list-cancel").disabled = !running && !paused;
  $("dl-list-retry").disabled = !restartable;
  $("dl-list-open").disabled = !d || (d.canceled && !d.error);
}

function applyRowFilter(d) {
  const row = rows.get(d);
  if (!row) return;
  const visible = !searchQuery || row.haystack.includes(searchQuery);
  const display = visible ? "" : "none";
  if (row.root.style.display !== display) row.root.style.display = display;
  if (!visible && selected === d) select(null);
}

function applyFilter() {
  for (const d of rows.keys()) applyRowFilter(d);
}

function runSearch() {
  searchQuery = $("dl-search-input").value.trim().toLowerCase();
  applyFilter();
}

function openSearch() {
  $("dl-toolbar").setAttribute("searching", "true");
  $("dl-search-input").focus();
}

function closeSearch() {
  $("dl-search-input").value = "";
  searchQuery = "";
  applyFilter();
  $("dl-toolbar").removeAttribute("searching");
}

function initSearch() {
  $("dl-list-search").addEventListener("click", openSearch);
  $("dl-search-go").addEventListener("click", runSearch);
  $("dl-search-back").addEventListener("click", closeSearch);
  $("dl-search-input").addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      runSearch();
    } else if (e.key === "Escape") {
      e.preventDefault();
      closeSearch();
    }
  });
}

function initTooltips() {
  const tip = $("dl-tip");
  const toolbar = $("dl-toolbar");
  let timer = null;
  let current = null;

  const hide = () => {
    clearTimeout(timer);
    tip.style.display = "none";
  };

  const show = (slot) => {
    tip.textContent = slot.dataset.tip;
    tip.style.display = "block";
    const box = slot.getBoundingClientRect();
    const maxLeft = document.documentElement.clientWidth - tip.offsetWidth - 2;
    tip.style.left = `${Math.max(2, Math.min(box.left, maxLeft))}px`;
    tip.style.top = `${box.bottom + 4}px`;
  };

  toolbar.addEventListener("mouseover", (e) => {
    const slot = e.target.closest?.(".dl-tool-slot") || null;
    if (slot === current) return;
    current = slot;
    hide();
    if (slot) timer = setTimeout(show, TOOLTIP_DELAY, slot);
  });
  toolbar.addEventListener("mouseleave", () => {
    current = null;
    hide();
  });
  toolbar.addEventListener("mousedown", hide);
}

function browserWindow() {
  try {
    if (window.opener && !window.opener.closed) return window.opener;
  } catch (e) {}
  return Services.wm.getMostRecentWindow("navigator:browser");
}

function syncColorScheme() {
  try {
    const parent = browserWindow();
    const src = parent.document.documentElement;
    const dst = document.documentElement;
    const sync = () => {
      const scheme = src.getAttribute("ie6-colorscheme");
      if (scheme) dst.setAttribute("ie6-colorscheme", scheme);
      else dst.removeAttribute("ie6-colorscheme");
    };
    sync();
    schemeObserver = new parent.MutationObserver(sync);
    schemeObserver.observe(src, { attributes: true, attributeFilter: ["ie6-colorscheme"] });
  } catch (e) {}
}

function bindActions() {
  const actions = {
    "dl-list-open": () => selected && showDetail(selected),
    "dl-list-folder": openDownloadsFolder,
    "dl-list-pause": () => {
      if (selected && !selected.stopped) selected.cancel().catch(swallow);
    },
    "dl-list-resume": () => {
      if (isPaused(selected)) restart(selected);
    },
    "dl-list-cancel": () => {
      if (selected && (!selected.stopped || isPaused(selected))) cancelAndClean(selected);
    },
    "dl-list-retry": () => {
      if (selected && selected.stopped && !selected.succeeded) restart(selected);
    },
    "dl-list-delete": () => list?.removeFinished().catch(swallow),
    "dl-open": () => download?.launch().catch(swallow),
    "dl-folder": () => download?.showContainingDirectory().catch(swallow),
    "dl-cancel": () => {
      if (!download || download.stopped) window.close();
      else cancelAndClean(download);
    },
    "dl-back": showList,
  };

  for (const [id, handler] of Object.entries(actions)) {
    $(id).addEventListener("click", handler);
  }

  document.addEventListener("click", (e) => {
    if (mode !== "list" || !selected) return;
    if (e.target.closest?.(".dl-row, #dl-toolbar")) return;
    select(null);
  });
}

window.DownloadsWindow = { showList, showDetail };

window.addEventListener(
  "load",
  async () => {
    syncColorScheme();
    initTooltips();
    initSearch();
    bindActions();

    if (download) showDetail(download);
    else showList();

    list = await Downloads.getList(Downloads.PUBLIC);
    view = {
      onDownloadAdded: addRow,
      onDownloadChanged(d) {
        updateRow(d);
        if (mode === "detail" && d === download) render();
      },
      onDownloadRemoved(d) {
        removeRow(d);
        if (d === download) window.close();
      },
    };
    await list.addView(view);
  },
  { once: true }
);

window.addEventListener(
  "unload",
  () => {
    try {
      schemeObserver?.disconnect();
    } catch (e) {}
    if (list && view) list.removeView(view).catch(swallow);
  },
  { once: true }
);