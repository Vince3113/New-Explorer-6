(function () {
  const IMG = "resource://ie6theme/images/";
  const MENU_ITEM_ID = "ie6_tipOfTheDay";

  const TIPS = [
    'To screen which websites can appear on your computer, click the <b>Tools</b> menu, click <b>Options</b>, click <b>Privacy &amp; Security</b>, and then enable <b>Blocked Content</b>.',
    'You can press <b>Ctrl+T</b> to open a new tab, or <b>Ctrl+Shift+T</b> to reopen the last tab you closed.',
    'To browse without saving your history, click <b>File</b>, then click <b>New Private Window</b>.',
    'You can drag a tab out of the window to open it in a window of its own.',
    'To find a word or phrase on the current page, press <b>Ctrl+F</b>.',
    'Middle-clicking a link opens it in a new tab without leaving the page you are on.',
    'To zoom in on a page, hold <b>Ctrl</b> and scroll the mouse wheel, or press <b>Ctrl</b> and the <b>Plus</b> key.',
    'You can choose which page opens when you start the browser from the <b>Tools</b> menu, <b>Options</b>, <b>Home</b>.',
    'To clear your browsing history, click the <b>Tools</b> menu, then click <b>Clear Recent History</b>.',
    'Typing a search term directly in the Address Bar sends it to your default search provider.',
    'To add the page you are viewing to your Favorites, press <b>Ctrl+D</b>.',
    'Right-clicking a picture on a webpage lets you save it to your computer.',
    'Pressing <b>F11</b> shows the current page in Full Screen view, hiding the toolbars.',
    'To manage your saved passwords, click the <b>Tools</b> menu, then click <b>Passwords</b>.',
    'You can right-click a tab and choose <b>Pin Tab</b> to keep it small and always in place.',
    'To reopen a window you just closed, press <b>Ctrl+Shift+N</b>.',
  ];

  let tipIndex = randomTipIndex();
  let bar = null;
  let tipOpen = false;

  function randomTipIndex() {
    return Math.floor(Math.random() * TIPS.length);
  }

  function create(tag, className) {
    const el = document.createElement(tag);
    el.className = className;
    return el;
  }

  function createImage(className, name) {
    const img = create("img", className);
    img.src = IMG + name;
    img.draggable = false;
    return img;
  }

  function buildBar() {
    const closeCol = create("div", "tip-close-col");
    closeCol.append(createImage("tip-close", "close.png"));

    const title = create("div", "tip-title");
    title.textContent = "Did you know...";
    const textBox = create("div", "tip-textbox");
    textBox.append(title, create("div", "tip-body"));

    const next = create("a", "tip-next");
    next.href = "#";
    next.textContent = "Next tip";

    const content = create("div", "tip-content");
    content.append(createImage("tip-icon", "tip.png"), textBox, next);

    const el = document.createElement("div");
    el.id = "tip-bar";
    el.hidden = true;
    el.append(closeCol, content);
    return el;
  }

  function renderTip() {
    const body = bar?.querySelector(".tip-body");
    if (body) body.innerHTML = TIPS[tipIndex];
  }

  function ensureBar() {
    if (bar) return;
    bar = buildBar();
    document.documentElement.appendChild(bar);
    renderTip();
  }

  function updateVisibility() {
    if (bar) bar.hidden = !tipOpen || window.fullScreen;
  }

  function setOpen(open) {
    ensureBar();
    if (open) {
      tipIndex = randomTipIndex();
      renderTip();
    }
    tipOpen = open;
    updateVisibility();
  }

  const toggleBar = () => setOpen(!tipOpen);

  document.addEventListener(
    "click",
    (e) => {
      if (e.target.closest?.(`#${MENU_ITEM_ID}`)) {
        toggleBar();
      } else if (e.target.closest?.(".tip-close")) {
        e.preventDefault();
        setOpen(false);
      } else if (e.target.closest?.(".tip-next")) {
        e.preventDefault();
        tipIndex = (tipIndex + 1) % TIPS.length;
        renderTip();
        window.ie6PlayClickSound?.();
      }
    },
    true
  );

  window.addEventListener("resize", updateVisibility);
  window.addEventListener("fullscreen", updateVisibility);

  window.ie6ToggleTipOfDay = toggleBar;
})();