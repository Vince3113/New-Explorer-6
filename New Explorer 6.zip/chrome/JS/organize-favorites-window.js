(function () {
  const { PlacesUtils } = ChromeUtils.importESModule("resource://gre/modules/PlacesUtils.sys.mjs");

  const HTML_NS = "http://www.w3.org/1999/xhtml";
  const IMG = "resource://ie6theme/images/";
  const OFFLINE_ANNOTATION = "ie6/makeAvailableOffline";

  const ROOTS = [
    { guid: PlacesUtils.bookmarks.toolbarGuid, label: "Favorites Bar" },
    { guid: PlacesUtils.bookmarks.unfiledGuid, label: "Other Favorites" },
  ];
  const ROOT_GUIDS = new Set(ROOTS.map((root) => root.guid));

  const args = window.arguments?.[0] || {};
  const parentWin = window.opener || Services.wm.getMostRecentWindow("navigator:browser");

  let selected = null;
  let selectionToken = 0;

  const $ = (id) => document.getElementById(id);

  function h(tag, className, text) {
    const el = document.createElementNS(HTML_NS, tag);
    if (className) el.className = className;
    if (text != null) el.textContent = text;
    return el;
  }

  function icon(name) {
    const img = h("img");
    img.src = IMG + name;
    return img;
  }

  const formatDate = (micros) => new Date(micros / 1000).toLocaleString();

  const isSeparator = (node) =>
    node.typeCode === PlacesUtils.bookmarks.TYPE_SEPARATOR ||
    node.type === PlacesUtils.TYPE_X_MOZ_PLACE_SEPARATOR;

  function syncColorScheme() {
    if (!parentWin) return;
    try {
      const src = parentWin.document.documentElement;
      const apply = () => {
        const scheme = src.getAttribute("ie6-colorscheme");
        if (scheme) document.documentElement.setAttribute("ie6-colorscheme", scheme);
        else document.documentElement.removeAttribute("ie6-colorscheme");
      };
      apply();

      const observer = new parentWin.MutationObserver(apply);
      observer.observe(src, { attributes: true, attributeFilter: ["ie6-colorscheme"] });
      window.addEventListener("unload", () => observer.disconnect(), { once: true });
    } catch (e) {}
  }

  function closeWithParent() {
    if (!parentWin) return;
    const closeSelf = () => window.close();
    parentWin.addEventListener("unload", closeSelf, { once: true });
    window.addEventListener(
      "unload",
      () => {
        try {
          parentWin.removeEventListener("unload", closeSelf);
        } catch (e) {}
      },
      { once: true }
    );
  }

  const notifyChanged = () => args.onChanged?.();

  const offlinePath = (guid) => PathUtils.join(PathUtils.profileDir, "offline_pages", `${guid}.html`);

  async function isOffline(guid) {
    try {
      return await PlacesUtils.annotations.itemHasAnnotation(guid, OFFLINE_ANNOTATION);
    } catch (e) {
      return false;
    }
  }

  async function setOffline({ guid, url }, enabled) {
    try {
      if (enabled) {
        await PlacesUtils.annotations.setItemAnnotation(
          guid,
          OFFLINE_ANNOTATION,
          "true",
          0,
          PlacesUtils.annotations.EXPIRE_NEVER
        );
        if (!url) return;
        const response = await fetch(url);
        const path = offlinePath(guid);
        await IOUtils.makeDirectory(PathUtils.parent(path), { createAncestors: true });
        await IOUtils.writeUTF8(path, await response.text());
      } else {
        await PlacesUtils.annotations.removeItemAnnotation(guid, OFFLINE_ANNOTATION);
        await IOUtils.remove(offlinePath(guid), { ignoreAbsent: true });
      }
    } catch (e) {}
  }

  async function getVisitStats(url) {
    try {
      const page = await PlacesUtils.history.fetch(url, { includeVisits: true });
      const visits = page?.visits || [];
      const last = visits.reduce((latest, visit) => (!latest || visit.date > latest ? visit.date : latest), null);
      return { count: visits.length, last };
    } catch (e) {
      return { count: 0, last: null };
    }
  }

  function buildOfflineRow(item, checked) {
    const row = h("div", "of-info-offline-row");
    const checkbox = h("input");
    checkbox.type = "checkbox";
    checkbox.id = "of-offline-checkbox";
    checkbox.checked = checked;
    checkbox.addEventListener("change", () => setOffline(item, checkbox.checked));

    const label = h("label", null, "Make available offline");
    label.htmlFor = checkbox.id;

    row.append(checkbox, label);
    return row;
  }

  async function showFolderInfo(info, item, token) {
    info.append(h("div", "of-info-name", item.title), h("div", null, "Favorites Folder"));

    let lastModified = item.lastModified;
    if (!lastModified) {
      try {
        lastModified = (await PlacesUtils.promiseBookmarksTree(item.guid)).lastModified;
      } catch (e) {}
    }
    if (token !== selectionToken) return;

    const block = h("div", "of-info-modified");
    block.append(h("div", "of-info-modified-label", "Modified:"));
    if (lastModified) block.append(h("div", null, formatDate(lastModified)));
    info.append(block);
  }

  async function showPageInfo(info, item, token) {
    info.append(h("div", "of-info-title", item.title), h("div", "of-info-url", item.url));

    const [visits, offline] = await Promise.all([getVisitStats(item.url), isOffline(item.guid)]);
    if (token !== selectionToken) return;

    info.append(
      h("div", null, `times visited: ${visits.count}`),
      h("div", null, `last visited: ${visits.last ? visits.last.toLocaleString() : ""}`),
      buildOfflineRow(item, offline)
    );
  }

  async function selectRow(row, item) {
    selected?.row.classList.remove("selected");
    selected = { row, ...item };
    row.classList.add("selected");

    const token = ++selectionToken;
    const info = $("of-info");
    info.textContent = "";

    if (item.isFolder) await showFolderInfo(info, item, token);
    else await showPageInfo(info, item, token);
  }

  function clearSelection() {
    selected = null;
    selectionToken++;
    $("of-info").textContent = "";
  }

  function createFolderRow(item) {
    const row = h("div", "of-folder");
    const folderIcon = icon("favourites-folder.png");
    row.append(folderIcon, h("span", "of-label", item.title));

    const children = h("div", "of-children");
    children.hidden = true;
    let loaded = false;

    row.addEventListener("click", (e) => {
      e.stopPropagation();
      selectRow(row, item);
    });

    row.addEventListener("dblclick", () => {
      children.hidden = !children.hidden;
      folderIcon.src = IMG + (children.hidden ? "favourites-folder.png" : "favourites-folder-open.png");
      if (!children.hidden && !loaded) {
        loaded = true;
        fillFolder(item.guid, children);
      }
    });

    return [row, children];
  }

  function createPageRow(item) {
    const row = h("div", "of-page");
    row.append(icon("page.png"), h("span", "of-label", item.title));
    row.addEventListener("click", (e) => {
      e.stopPropagation();
      selectRow(row, item);
    });
    return row;
  }

  async function fillFolder(guid, container) {
    const node = await PlacesUtils.promiseBookmarksTree(guid);

    for (const child of node.children || []) {
      if (isSeparator(child)) continue;

      const isFolder = !child.uri;
      const item = {
        guid: child.guid,
        title: child.title || (isFolder ? "(unnamed)" : child.uri),
        url: child.uri,
        isFolder,
        lastModified: child.lastModified,
      };

      if (isFolder) container.append(...createFolderRow(item));
      else container.append(createPageRow(item));
    }
  }

  function buildTree() {
    clearSelection();
    const rows = ROOTS.flatMap((root) => createFolderRow({ guid: root.guid, title: root.label, isFolder: true }));
    $("of-tree").replaceChildren(...rows);
  }

  function startInlineRename() {
    if (!selected || ROOT_GUIDS.has(selected.guid)) return;

    const { guid, row } = selected;
    const label = row.querySelector(".of-label");
    const original = label.textContent;

    const input = h("input", "of-rename-input");
    input.type = "text";
    input.value = original;
    label.replaceWith(input);
    input.focus();
    input.select();

    let finished = false;

    async function finish(save) {
      if (finished) return;
      finished = true;

      const name = input.value.trim();
      input.replaceWith(label);
      if (!save || !name || name === original) return;

      label.textContent = name;
      const nameEl = $("of-info").querySelector(".of-info-name, .of-info-title");
      if (nameEl) nameEl.textContent = name;

      try {
        await PlacesUtils.bookmarks.update({ guid, title: name });
        notifyChanged();
      } catch (e) {
        label.textContent = original;
        if (nameEl) nameEl.textContent = original;
      }
    }

    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        finish(true);
      } else if (e.key === "Escape") {
        e.preventDefault();
        finish(false);
      }
    });
    input.addEventListener("blur", () => finish(true));
  }

  async function deleteSelected() {
    if (!selected || ROOT_GUIDS.has(selected.guid)) return;
    try {
      await PlacesUtils.bookmarks.remove(selected.guid);
    } catch (e) {
      return;
    }
    buildTree();
    notifyChanged();
  }

  function openCreateFolderDialog() {
    const parentGuid = selected?.isFolder ? selected.guid : PlacesUtils.bookmarks.unfiledGuid;

    window.openDialog(
      "chrome://userscripts/content/create-folder-dialog.xhtml",
      "_blank",
      "chrome,dialog,centerscreen,resizable=no",
      {
        parentBrowserWin: parentWin,
        callback: async (name) => {
          if (!name) return;
          await PlacesUtils.bookmarks.insert({
            parentGuid,
            type: PlacesUtils.bookmarks.TYPE_FOLDER,
            title: name,
          });
          buildTree();
          notifyChanged();
        },
      }
    );
  }

  function openMoveToFolderDialog() {
    if (!selected || ROOT_GUIDS.has(selected.guid)) return;
    const { guid } = selected;

    window.openDialog(
      "chrome://userscripts/content/browse-for-folder-dialog.xhtml",
      "_blank",
      "chrome,dialog,centerscreen,width=320,height=330,resizable=no",
      {
        parentBrowserWin: parentWin,
        selectedGuid: guid,
        callback: async (targetFolderGuid) => {
          if (!targetFolderGuid) return;
          try {
            await PlacesUtils.bookmarks.update({
              guid,
              parentGuid: targetFolderGuid,
              index: PlacesUtils.bookmarks.DEFAULT_INDEX,
            });
            buildTree();
            notifyChanged();
          } catch (e) {}
        },
      }
    );
  }

  function init() {
    syncColorScheme();
    closeWithParent();

    $("of-btn-close").addEventListener("click", () => window.close());
    $("of-btn-createfolder").addEventListener("click", openCreateFolderDialog);
    $("of-btn-movetofolder").addEventListener("click", openMoveToFolderDialog);
    $("of-btn-rename").addEventListener("click", startInlineRename);
    $("of-btn-delete").addEventListener("click", deleteSelected);

    buildTree();

    window.ie6WireContainer?.(document.querySelector(".of-right-wrapper"));
  }

  window.addEventListener("load", init, { once: true });
})();