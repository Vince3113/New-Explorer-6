(function () {
  const HITZONE_WIDTH = 16;

  const TOOLBAR_LABELS = {
    "back-button": "Back",
    "forward-button": "Forward",
    "stop-button": "Stop",
    "reload-button": "Refresh",
    "home-button": "Home",
    "find-button": "Search",
    "bookmarks-menu-button": "Favorites",
    "history-panelmenu": "History",
    "history-button": "History",
    "email-link-button": "Mail",
    "print-button": "Print",
    "preferences-button": "Edit",
    "downloads-button": "Downloads",
    "unified-extensions-button": "Extensions",
    "save-page-button": "Save Page",
    "open-file-button": "Open File",
    "characterencoding-button": "Encoding",
    "logins-button": "Passwords",
    "privatebrowsing-button": "Incognito",
    "developer-button": "Developer",
    "screenshot-button": "Screenshot",
    "fullscreen-button": "Full Screen",
    "ie6-account-button": "Account",
    "ie6-media-button": "Media",
    "ie6-folders-button": "Folders",
    "ie6-messenger-button": "Messenger",
    "ie6-research-button": "Research",
  };

  const TOOLTIP_IDS = [
    "back-button",
    "forward-button",
    "stop-button",
    "reload-button",
    "home-button",
    "find-button",
    "bookmarks-menu-button",
    "history-panelmenu",
    "email-link-button",
    "print-button",
    "downloads-button",
    "fullscreen-button",
    "logins-button",
    "characterencoding-button",
    "developer-button",
  ];
  const CUSTOM_TOOLTIPS = {
    ...Object.fromEntries(TOOLTIP_IDS.map((id) => [id, TOOLBAR_LABELS[id]])),
    "preferences-button": "Settings",
    "cut-button": "Cut",
    "copy-button": "Copy",
    "paste-button": "Paste",
  };

  const LABELED_HERE = ["back-button", "find-button", "bookmarks-menu-button", "ie6-media-button"];
  const OWN_LABEL_IDS = new Set([...LABELED_HERE, "ie6-folders-button"]);
  const NATIVE_LABELED_HERE = LABELED_HERE.filter((id) => !id.startsWith("ie6-"));

  const $ = (id) => document.getElementById(id);

  function createLabel(text) {
    const label = document.createXULElement("label");
    label.className = "ie6-btn-label";
    label.setAttribute("value", text);
    return label;
  }

  function addButtonLabel(id, text) {
    const btn = $(id);
    if (!btn || btn.querySelector(".ie6-btn-label")) return;

    const label = createLabel(text);
    label.setAttribute("tooltiptext", btn.getAttribute("tooltiptext") || text);
    label.addEventListener("click", (ev) => {
      if (ev.button !== 0) return;
      ev.stopPropagation();
      btn.click();
    });
    btn.appendChild(label);
  }

  function ensureToolbarLabels() {
    const target = $("nav-bar-customization-target");
    if (!target) return;

    for (const id of NATIVE_LABELED_HERE) {
      const btn = $(id);
      if (btn && target.contains(btn)) addButtonLabel(id, TOOLBAR_LABELS[id]);
    }

    for (const btn of target.querySelectorAll("toolbarbutton.toolbarbutton-1")) {
      if (btn.closest("#edit-controls, #zoom-controls")) continue;
      if (OWN_LABEL_IDS.has(btn.id)) {
        btn.querySelectorAll(".ie6-btn-label[ie6-extra]").forEach((n) => n.remove());
        continue;
      }
      if (btn.querySelector(".ie6-btn-label")) continue;

      const text = TOOLBAR_LABELS[btn.id] || btn.getAttribute("label");
      if (!text) continue;

      const label = createLabel(text);
      label.setAttribute("ie6-extra", "true");
      btn.appendChild(label);
    }
  }

  let toolbarLabelsQueued = false;
  function queueEnsureToolbarLabels() {
    if (toolbarLabelsQueued) return;
    toolbarLabelsQueued = true;
    requestAnimationFrame(() => {
      toolbarLabelsQueued = false;
      ensureToolbarLabels();
    });
  }

  function applyCustomTooltip(btn, text) {
    if (btn.getAttribute("tooltiptext") === text) return;
    btn.removeAttribute("data-l10n-id");
    btn.setAttribute("tooltiptext", text);
  }

  const tooltipObserved = new WeakSet();
  function applyCustomTooltips() {
    for (const [id, text] of Object.entries(CUSTOM_TOOLTIPS)) {
      const btn = $(id);
      if (!btn) continue;

      applyCustomTooltip(btn, text);
      if (tooltipObserved.has(btn)) continue;

      tooltipObserved.add(btn);
      new MutationObserver(() => applyCustomTooltip(btn, text)).observe(btn, {
        attributes: true,
        attributeFilter: ["tooltiptext", "data-l10n-id"],
      });
    }
  }

  function buildHistoryDropdownPopup(direction) {
    const sessionHistory = gBrowser.selectedBrowser.browsingContext?.sessionHistory;
    if (!sessionHistory) return null;

    const popupSet = $("mainPopupSet") || document.querySelector("popupset");
    if (!popupSet) return null;

    let popup = $("ie6-history-dropdown-menu");
    if (!popup) {
      popup = document.createXULElement("menupopup");
      popup.id = "ie6-history-dropdown-menu";
      popupSet.appendChild(popup);
    }
    popup.replaceChildren();

    const { index, count } = sessionHistory;
    const indices = [];
    if (direction === "back") {
      for (let i = index - 1; i >= 0; i--) indices.push(i);
    } else {
      for (let i = index + 1; i < count; i++) indices.push(i);
    }
    if (!indices.length) return null;

    for (const i of indices) {
      const entry = sessionHistory.getEntryAtIndex(i);
      const item = document.createXULElement("menuitem");
      item.setAttribute("label", entry.title || entry.URI.spec);
      item.setAttribute("crop", "end");
      item.addEventListener("command", () => gBrowser.gotoIndex(i));
      popup.appendChild(item);
    }
    return popup;
  }

  function setupHistoryDropmarker(buttonId, direction) {
    const btn = $(buttonId);
    if (!btn || btn.querySelector(".ie6-history-dropmarker")) return;

    const marker = document.createXULElement("box");
    marker.className = "ie6-history-dropmarker";
    marker.setAttribute("tooltiptext", direction === "back" ? "Historial de atrás" : "Historial de adelante");
    btn.appendChild(marker);

    document.addEventListener(
      "click",
      (ev) => {
        if (!btn.contains(ev.target)) return;
        if (btn.getBoundingClientRect().right - ev.clientX > HITZONE_WIDTH) return;

        ev.preventDefault();
        ev.stopPropagation();
        try {
          buildHistoryDropdownPopup(direction)?.openPopup(marker, "after_start", 0, 0, true, false);
        } catch (e) {}
      },
      true
    );

    btn.addEventListener(
      "contextmenu",
      (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
      },
      true
    );
  }

  function ensureAddressLabel() {
    const urlbarContainer = $("urlbar-container");
    if (!urlbarContainer || $("ie6-address-label")) return;

    const label = document.createXULElement("label");
    label.id = "ie6-address-label";
    label.setAttribute("value", "Address");
    urlbarContainer.parentNode.insertBefore(label, urlbarContainer);
  }

  function ensureChevronProxy(addressToolbar) {
    if ($("ie6-chevron-proxy")) return;

    const proxy = document.createXULElement("toolbarbutton");
    proxy.id = "ie6-chevron-proxy";
    proxy.setAttribute("aria-label", "Mostrar más marcadores");

    const icon = document.createXULElement("image");
    icon.className = "toolbarbutton-icon";
    proxy.appendChild(icon);

    proxy.addEventListener("click", (ev) => {
      ev.stopPropagation();
      const popup = getChevronPopup();
      if (!popup) return;

      if (popup.state === "open" || popup.state === "showing") popup.hidePopup();
      else popup.openPopup(proxy, "after_start", 0, 0, true, false);
    });

    addressToolbar.appendChild(proxy);
  }

  function ensureGoButton(addressToolbar) {
    if ($("ie6-go-button")) return;

    const goBtn = document.createXULElement("toolbarbutton");
    goBtn.id = "ie6-go-button";
    goBtn.setAttribute("tooltiptext", "Go to");

    const goIcon = document.createXULElement("image");
    goIcon.id = "ie6-go-icon";
    const goLabel = document.createXULElement("label");
    goLabel.id = "ie6-go-label";
    goLabel.setAttribute("value", "Go");
    goBtn.append(goIcon, goLabel);

    goBtn.addEventListener("click", () => {
      try {
        gURLBar.handleCommand();
      } catch (ex) {}
    });
    addressToolbar.appendChild(goBtn);

    const linksLabel = document.createElement("span");
    linksLabel.id = "ie6-links-label-addressbar";
    linksLabel.textContent = "Links";
    linksLabel.style.display = "none";
    addressToolbar.appendChild(linksLabel);

    ensureChevronProxy(addressToolbar);
  }

  function ensureAddressBarOwnRow() {
    const navBar = $("nav-bar");
    const urlbarContainer = $("urlbar-container");
    if (!navBar || !urlbarContainer) return;

    let addressToolbar = $("ie6-address-toolbar");
    if (!addressToolbar) {
      addressToolbar = document.createXULElement("toolbar");
      addressToolbar.id = "ie6-address-toolbar";
      addressToolbar.setAttribute("customizable", "false");
      navBar.insertAdjacentElement("afterend", addressToolbar);
    }

    const addrLabel = $("ie6-address-label");
    if (addrLabel && addrLabel.parentNode !== addressToolbar) addressToolbar.appendChild(addrLabel);
    if (urlbarContainer.parentNode !== addressToolbar) addressToolbar.appendChild(urlbarContainer);

    ensureGoButton(addressToolbar);
  }

  function showLinksAndChevron() {
    const addressToolbar = $("ie6-address-toolbar");
    const linksLabel = $("ie6-links-label-addressbar");
    if (!addressToolbar || !linksLabel) return;

    addressToolbar.classList.add("ie6-links-active");
    linksLabel.style.display = "";
  }

  function hideBookmarksBar() {
    const personalToolbar = $("PersonalToolbar");
    if (!personalToolbar) return;

    personalToolbar.classList.add("ie6-fake-collapsed");
    personalToolbar.removeAttribute("collapsed");
    requestAnimationFrame(() => {
      window.dispatchEvent(new Event("resize"));
      requestAnimationFrame(showLinksAndChevron);
    });
  }

  function watchPersonalToolbarCollapse() {
    const personalToolbar = $("PersonalToolbar");
    if (!personalToolbar) {
      setTimeout(watchPersonalToolbarCollapse, 1000);
      return;
    }
    new MutationObserver(hideBookmarksBar).observe(personalToolbar, {
      attributes: true,
      attributeFilter: ["collapsed"],
    });
    hideBookmarksBar();
  }

  const getChevronPopup = () => $("PlacesChevron")?.querySelector("menupopup");
  const getChevronPopupTarget = (popup) => popup?.querySelector("arrowscrollbox") || popup;

  const FOLDER_NAMES = {
    OtherBookmarks: "Other Favorites",
  };

  function renameClone(clone, name) {
    clone.setAttribute("label", name);
    clone
      .querySelectorAll(":scope > .toolbarbutton-text, :scope > .menu-iconic-text, :scope > .menu-text")
      .forEach((node) => node.setAttribute("value", name));
  }

  function buildClonedItem(item, hostPopup) {
    const clone = item.cloneNode(true);
    clone.classList.add("ie6-chevron-clone");

    const folderName = FOLDER_NAMES[item.id];
    if (folderName) renameClone(clone, folderName);

    if (item.getAttribute("container") !== "true") {
      clone.addEventListener("click", (ev) => {
        ev.stopPropagation();
        hostPopup.hidePopup();
        item.click();
      });
      return clone;
    }

    clone.classList.add("ie6-chevron-folder");
    clone.removeAttribute("type");
    clone.querySelectorAll(":scope > menupopup").forEach((n) => n.remove());

    const subPopup = document.createXULElement("menupopup");
    clone.appendChild(subPopup);

    clone.addEventListener("click", (ev) => {
      ev.stopPropagation();
      const originalSubPopup = item.querySelector(":scope > menupopup");

      if (originalSubPopup && originalSubPopup.children.length === 0) {
        try {
          originalSubPopup.dispatchEvent(new Event("popupshowing", { bubbles: true, cancelable: true }));
        } catch (e) {}
      }

      subPopup.querySelectorAll(".ie6-chevron-clone").forEach((n) => n.remove());
      for (const subItem of originalSubPopup?.children || []) {
        subPopup.appendChild(buildClonedItem(subItem, subPopup));
      }

      try {
        subPopup.openPopup(clone, "end_before", 0, 0, false, false);
      } catch (e) {}
    });

    return clone;
  }

  function populateChevronPopup() {
    const popup = getChevronPopup();
    const target = getChevronPopupTarget(popup);
    const placesItems = $("PlacesToolbarItems");
    if (!target || !placesItems) return;

    target.querySelectorAll(".ie6-chevron-clone").forEach((n) => n.remove());

    for (const item of placesItems.children) {
      target.appendChild(buildClonedItem(item, popup));
    }
    const otherBookmarks = $("OtherBookmarks");
    if (otherBookmarks) target.appendChild(buildClonedItem(otherBookmarks, popup));
  }

  function restoreChevronPopupItems() {
    getChevronPopupTarget(getChevronPopup())
      ?.querySelectorAll(".ie6-chevron-clone")
      .forEach((n) => n.remove());
  }

  function setupChevronManualFill() {
    const popup = getChevronPopup();
    if (!popup) {
      setTimeout(setupChevronManualFill, 1000);
      return;
    }
    popup.addEventListener("popupshowing", (ev) => {
      if (ev.target === popup) populateChevronPopup();
    });
    popup.addEventListener("popuphiding", (ev) => {
      if (ev.target === popup) restoreChevronPopupItems();
    });
  }

  function keepStopButtonEnabled() {
    $("stop-button")?.removeAttribute("disabled");
  }

  function reorderStopBeforeReload() {
    const stopBtn = $("stop-button");
    const reloadBtn = $("reload-button");
    if (stopBtn?.parentNode && reloadBtn && stopBtn.nextElementSibling !== reloadBtn) {
      stopBtn.parentNode.insertBefore(stopBtn, reloadBtn);
    }
  }

  function stripStopReloadWrapperTooltip() {
    const wrapper = $("stop-reload-button");
    wrapper?.removeAttribute("data-l10n-id");
    wrapper?.removeAttribute("title");
    wrapper?.removeAttribute("tooltiptext");
  }

  function reorderHistoryMenu() {
    const menubar = $("toolbar-menubar")?.querySelector("menubar");
    const historyMenu = $("history-menu");
    const helpMenu = $("helpMenu");
    if (menubar && historyMenu && helpMenu && historyMenu.nextSibling !== helpMenu) {
      menubar.insertBefore(historyMenu, helpMenu);
    }
  }

  function observe(id, callback, attributeFilter) {
    const el = $(id);
    if (el) new MutationObserver(callback).observe(el, { attributes: true, attributeFilter });
  }

  function init() {
    applyCustomTooltips();
    LABELED_HERE.forEach((id) => addButtonLabel(id, TOOLBAR_LABELS[id]));
    setupHistoryDropmarker("back-button", "back");
    setupHistoryDropmarker("forward-button", "forward");

    ensureToolbarLabels();
    const customizationTarget = $("nav-bar-customization-target");
    if (customizationTarget) {
      new MutationObserver(queueEnsureToolbarLabels).observe(customizationTarget, {
        childList: true,
        subtree: true,
      });
    }

    ensureAddressLabel();
    ensureAddressBarOwnRow();

    reorderStopBeforeReload();
    keepStopButtonEnabled();
    stripStopReloadWrapperTooltip();
    reorderHistoryMenu();

    observe("stop-button", keepStopButtonEnabled, ["disabled"]);
    observe("stop-reload-button", stripStopReloadWrapperTooltip, ["title", "tooltiptext", "data-l10n-id"]);

    try {
      Services.prefs.setBoolPref("browser.tabs.hoverPreview.enabled", false);
    } catch (e) {}

    setTimeout(() => {
      reorderHistoryMenu();
      ensureToolbarLabels();
      ensureAddressLabel();
      ensureAddressBarOwnRow();
      reorderStopBeforeReload();
      keepStopButtonEnabled();
      applyCustomTooltips();
    }, 1000);

    watchPersonalToolbarCollapse();
    setupChevronManualFill();
  }

  try {
    init();
  } catch (ex) {}
})();