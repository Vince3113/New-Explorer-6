(function () {
  const POPUP_ID = "tabContextMenu";
  const HIDE_CLASS = "ie6-tabctx-hide";
  const SEP_CLASS = "ie6-tabctx-sep-hide";
  const COPY_ID = "context_copyLink";

  const HIDE_MATCH = [
    "#context_openANewTab",
    '[id*="split" i]',
    '[data-l10n-id*="split" i]',
    "#context_moveTabOptions",
    "#context_reopenInContainer",
    '[id*="container" i]',
    "#context_closeDuplicateTabs",
    "#context_closeTabOptions",
    "#context_unloadTab",
    "#context_shareTabURL",
    "#context_sendTabToDevice",
    '[id*="shareTab" i]',
    '[id*="sendTabToDevice" i]',
    ".share-tab-url-item",
    '[data-l10n-id="tab-context-share-url"]',
  ].join(",");

  const RENAMES = {
    context_reloadTab: {
      fn: (label) => label.replace(/^Reload/, "Refresh"),
      accesskey: "R",
    },
    context_bookmarkTab: {
      fn: (label) =>
        label.replace(/^Bookmark Tab(s?)(…|\.\.\.)?$/, (m, s, dots) =>
          "Add Tab" + s + " to Favorites" + (dots ? "..." : "")
        ),
      accesskey: "F",
    },
  };

  function applyRename(item, rule) {
    const label = item.getAttribute("label") || "";
    const next = rule.fn(label);
    if (next !== label) {
      item.setAttribute("label", next);
      item.setAttribute("accesskey", rule.accesskey);
    }
  }

  function copyLinks() {
    const tab = TabContextMenu.contextTab;
    const tabs = tab && tab.multiselected
      ? gBrowser.selectedTabs
      : [tab || gBrowser.selectedTab];
    const text = tabs.map((t) => t.linkedBrowser.currentURI.spec).join("\n");
    Cc["@mozilla.org/widget/clipboardhelper;1"]
      .getService(Ci.nsIClipboardHelper)
      .copyString(text);
  }

  function ensureCopyItem(popup) {
    let item = document.getElementById(COPY_ID);
    if (!item) {
      item = document.createXULElement("menuitem");
      item.id = COPY_ID;
      item.setAttribute("label", "Copy Link");
      item.setAttribute("accesskey", "L");
      item.addEventListener("command", copyLinks);
    }
    const share = popup.querySelector(
      '.share-tab-url-item, [data-l10n-id="tab-context-share-url"]'
    );
    const bookmark = document.getElementById("context_bookmarkTab");
    const anchor = share || (bookmark && bookmark.nextElementSibling);
    if (anchor && anchor !== item) {
      if (item.parentNode !== popup || item.nextElementSibling !== anchor) {
        popup.insertBefore(item, anchor);
      }
    } else if (!item.parentNode) {
      popup.appendChild(item);
    }
  }

  function hideItems(popup) {
    for (const el of popup.children) {
      if (el.localName !== "menuseparator") el.classList.toggle(HIDE_CLASS, el.matches(HIDE_MATCH));
    }
  }

  function cleanSeparators(popup) {
    const kids = [...popup.children];
    for (const k of kids) {
      if (k.localName === "menuseparator") k.classList.remove(SEP_CLASS);
    }
    let prevWasSep = true;
    let lastSep = null;
    for (const k of kids) {
      if (k.hidden || k.classList.contains(HIDE_CLASS)) continue;
      if (k.localName === "menuseparator") {
        if (prevWasSep) {
          k.classList.add(SEP_CLASS);
        } else {
          prevWasSep = true;
          lastSep = k;
        }
      } else {
        prevWasSep = false;
        lastSep = null;
      }
    }
    if (lastSep) lastSep.classList.add(SEP_CLASS);
  }

  function init() {
    const popup = document.getElementById(POPUP_ID);
    if (!popup || popup.dataset.tabCtxInit) return;
    popup.dataset.tabCtxInit = "1";

    for (const [id, rule] of Object.entries(RENAMES)) {
      const item = document.getElementById(id);
      if (!item) continue;
      applyRename(item, rule);
      new MutationObserver(() => applyRename(item, rule)).observe(item, {
        attributes: true,
        attributeFilter: ["label", "data-l10n-id"],
      });
    }

    popup.addEventListener("popupshowing", (event) => {
      if (event.target !== popup) return;
      ensureCopyItem(popup);
      hideItems(popup);
      cleanSeparators(popup);
    });
  }

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();