(function () {
  const PREF = "browser.toolbars.bookmarks.visibility";

  function forceNever() {
    if (Services.prefs.getStringPref(PREF, "") !== "never") {
      Services.prefs.setStringPref(PREF, "never");
    }
  }

  function init() {
    forceNever();
    Services.prefs.addObserver(PREF, forceNever);
  }

  if (gBrowserInit?.delayedStartupFinished) {
    init();
    return;
  }

  const onStartup = (subject, topic) => {
    if (subject !== window) return;
    Services.obs.removeObserver(onStartup, topic);
    init();
  };
  Services.obs.addObserver(onStartup, "browser-delayed-startup-finished");
})();