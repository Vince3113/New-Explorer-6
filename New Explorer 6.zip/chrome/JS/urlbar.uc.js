(function () {
  "use strict";

  const MIME_EXTENSION_MAP = {
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/gif": "gif",
    "image/webp": "webp",
    "image/bmp": "bmp",
    "image/svg+xml": "svg",
    "image/x-icon": "ico",
    "image/tiff": "tif",
    "text/plain": "txt",
    "text/css": "css",
    "text/javascript": "js",
    "application/javascript": "js",
    "application/json": "json",
    "application/xml": "xml",
    "text/xml": "xml",
    "text/csv": "csv",
    "application/pdf": "pdf",
    "audio/mpeg": "mp3",
    "audio/mp4": "m4a",
    "audio/wav": "wav",
    "audio/x-wav": "wav",
    "audio/ogg": "ogg",
    "audio/flac": "flac",
    "video/mp4": "mp4",
    "video/webm": "webm",
    "video/x-msvideo": "avi",
    "video/x-matroska": "mkv",
    "video/quicktime": "mov",
  };

  const KNOWN_EXTENSIONS = new Set([
    ...Object.values(MIME_EXTENSION_MAP),
    "jpeg",
    "tiff",
  ]);

  function getExtensionFromURI(uri) {
    try {
      const path = (uri.filePath || uri.pathQueryRef || uri.spec).split(/[?#]/)[0];
      return path.match(/\.([a-z0-9]{1,6})$/i)?.[1].toLowerCase() ?? null;
    } catch (e) {
      return null;
    }
  }

  function updatePageTypeIcon() {
    const icon = document.getElementById("ie6-urlbar-page-icon");
    const browser = gBrowser.selectedBrowser;
    if (!icon || !browser) return;

    const uriExt = browser.currentURI ? getExtensionFromURI(browser.currentURI) : null;
    const ext = KNOWN_EXTENSIONS.has(uriExt)
      ? uriExt
      : MIME_EXTENSION_MAP[(browser.documentContentType || "").toLowerCase()];

    if (ext) {
      icon.style.setProperty("--ie6-page-icon", `url("moz-icon://a.${ext}?size=16")`);
    } else {
      icon.style.removeProperty("--ie6-page-icon");
    }
  }

  function setupUrlbarBreakoutFix() {
    const urlbar = document.getElementById("urlbar");
    const container = document.getElementById("urlbar-container");
    if (!urlbar || !container) return;

    const fixWidth = () => {
      if (!urlbar.hasAttribute("breakout")) return;
      urlbar.style.setProperty(
        "--ie6-urlbar-max-width",
        `${container.getBoundingClientRect().width}px`
      );
    };

    const observer = new MutationObserver(() => requestAnimationFrame(fixWidth));
    observer.observe(urlbar, {
      attributes: true,
      attributeFilter: ["breakout", "breakout-extend"],
    });

    window.addEventListener("resize", fixWidth);
    window.addEventListener("unload", () => observer.disconnect(), { once: true });
  }

  function insertPageIcon() {
    if (document.getElementById("ie6-urlbar-page-icon")) return;

    const identityBox = document.getElementById("identity-box");
    if (!identityBox) return;

    const icon = document.createElement("image");
    icon.id = "ie6-urlbar-page-icon";
    identityBox.after(icon);
  }

  function insertDropmarker() {
    if (document.getElementById("ie6-urlbar-dropmarker")) return;

    const input = document.getElementById("urlbar-input");
    if (!input?.parentNode) return;

    const marker = document.createElement("image");
    marker.id = "ie6-urlbar-dropmarker";
    marker.setAttribute("role", "button");
    marker.setAttribute("aria-label", "Direcciones tipeadas recientemente");

    marker.addEventListener("mousedown", (e) => {
      e.preventDefault();
      e.stopPropagation();
    });

    marker.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (gURLBar.view?.isOpen) {
        gURLBar.view.close();
      } else {
        gURLBar.focus();
        gURLBar.search("");
      }
    });

    input.parentNode.insertBefore(marker, input.nextSibling);
  }

  function injectUrlbarElements() {
    insertPageIcon();
    insertDropmarker();
    updatePageTypeIcon();
    setupUrlbarBreakoutFix();

    window.addEventListener("TabSelect", updatePageTypeIcon);

    const progressListener = {
      onLocationChange(aBrowser) {
        if (aBrowser === gBrowser.selectedBrowser) {
          setTimeout(updatePageTypeIcon, 0);
          setTimeout(updatePageTypeIcon, 150);
        }
      },
    };
    gBrowser.addTabsProgressListener(progressListener);
    window.addEventListener(
      "unload",
      () => gBrowser.removeTabsProgressListener(progressListener),
      { once: true }
    );
  }

  if (gBrowserInit.delayedStartupFinished) {
    injectUrlbarElements();
  } else {
    const observer = {
      observe(subject, topic) {
        if (subject !== window) return;
        Services.obs.removeObserver(observer, topic);
        injectUrlbarElements();
      },
    };
    Services.obs.addObserver(observer, "browser-delayed-startup-finished");
  }
})();