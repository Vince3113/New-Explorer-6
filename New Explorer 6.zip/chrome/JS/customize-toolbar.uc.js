(function () {
  const WINDOW_TYPE = "ie6theme:customizetoolbar";
  const PREF_BRANCH = "ie6theme.toolbar.";

  function openCustomizeWindow() {
    const existing = Services.wm.getMostRecentWindow(WINDOW_TYPE);
    if (existing) {
      existing.focus();
      return;
    }
    window.openDialog(
      "chrome://userchrome/content/customize-toolbar-window.xhtml",
      WINDOW_TYPE,
      "chrome,dialog,centerscreen,width=545,height=280,resizable=no"
    );
  }

  function applyToolbarOptions() {
    const navBar = document.getElementById("nav-bar");
    if (!navBar) return;
    navBar.setAttribute(
      "ie6-text-mode",
      Services.prefs.getStringPref(PREF_BRANCH + "textMode", "selective")
    );
    navBar.setAttribute(
      "ie6-icon-size",
      Services.prefs.getStringPref(PREF_BRANCH + "iconSize", "large")
    );
  }

  const observer = { observe: applyToolbarOptions };
  Services.prefs.addObserver(PREF_BRANCH, observer);
  window.addEventListener(
    "unload",
    () => Services.prefs.removeObserver(PREF_BRANCH, observer),
    { once: true }
  );
  applyToolbarOptions();

  const MAX_ATTEMPTS = 50;
  let attempts = 0;
  function patchEntryPoint() {
    if (window.gCustomizeMode && typeof window.gCustomizeMode.enter === "function") {
      window.gCustomizeMode.enter = openCustomizeWindow;
      return;
    }
    if (++attempts >= MAX_ATTEMPTS) {
      return;
    }
    setTimeout(patchEntryPoint, 200);
  }
  patchEntryPoint();
})();