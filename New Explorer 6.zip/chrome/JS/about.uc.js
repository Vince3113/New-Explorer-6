(function () {
  const IE6_ABOUT_URL = "chrome://browser/content/aboutDialog.xhtml";
  const IE6_ABOUT_WINDOWTYPE = "Browser:About";

  function buildIE6Content(doc) {
    const win = doc.defaultView;
    const root = doc.getElementById("aboutDialog") || doc.documentElement;
    if (!root || root.getAttribute("data-ie6-about") === "true") return;
    root.setAttribute("data-ie6-about", "true");

    while (root.firstChild) root.removeChild(root.firstChild);

    root.setAttribute("id", "aboutDialog");

    const HTML_NS = "http://www.w3.org/1999/xhtml";
    function el(tag, attrs) {
      const e = doc.createElementNS(HTML_NS, tag);
      if (attrs) {
        for (const k in attrs) {
          if (k === "text") e.textContent = attrs[k];
          else e.setAttribute(k, attrs[k]);
        }
      }
      return e;
    }

    const cssLink = el("link", {
      rel: "stylesheet",
      href: "resource://ie6theme/css/96-about-dialog.css",
    });
    root.appendChild(cssLink);

    const sbCssLink = el("link", {
      rel: "stylesheet",
      href: "resource://ie6theme/css/xp-scrollbar-content.css",
    });
    root.appendChild(sbCssLink);

    root.appendChild(
      el("img", { id: "ie6-about-logo", src: "resource://ie6theme/images/about_logo.png" })
    );

    const versionBox = el("div", { id: "ie6-about-version" });
    versionBox.appendChild(el("div", { text: "Version: 6.0.2900.5512.xpsp.080413-2111" }));
    versionBox.appendChild(el("div", { text: "Cipher Strength: 128-bit" }));
    versionBox.appendChild(el("div", { text: "Product ID:76487-024-5236883-22915" }));
    versionBox.appendChild(el("div", { text: "Update Versions:; SP3;" }));
    root.appendChild(versionBox);

    const creditsBox = el("div", { id: "ie6-about-credits" });
    const creditsParagraphs = [
      "Based on NCSA Mosaic. NCSA Mosaic(TM); was developed at the National Center for Supercomputing Applications at the University of Illinois at Urbana-Champaign.",
      "Distributed under a licensing agreement with Spyglass, Inc.",
      "Contains security software licensed from RSA Data Security Inc.",
      "Portions of this software are based in part on the work of the Independent JPEG Group.",
      "Multimedia software components, including Indeo(R); video, Indeo(R) audio, and Web Design Effects are provided by Intel Corp.",
      "Unix version contains software licensed from Mainsoft Corporation. Copyright (c) 1998-1999 Mainsoft Corporation. All rights reserved. Mainsoft is a trademark of Mainsoft Corporation.",
      "Warning: This computer program is protected by copyright law and international treaties. Unauthorized reproduction or distribution of this program, or any portion of it, may result in severe civil and criminal penalties, and will be prosecuted to the maximum extent possible under the law.",
    ];
    for (const p of creditsParagraphs) {
      creditsBox.appendChild(el("p", { class: "ie6-about-credits-p", text: p }));
    }
    root.appendChild(creditsBox);

    if (typeof window !== "undefined" && window.XPScrollbarOverlay) {
      try {
        const sb = new window.XPScrollbarOverlay(creditsBox, { minThumb: 14, step: 20 });
        sb.overlay.classList.add("ie6-about-credits-sb");
      } catch (e) {}
    } else {}

    root.appendChild(
      el("img", {
        id: "ie6-about-winlogo",
        src: "resource://ie6theme/images/windows-logo.png",
      })
    );

    root.appendChild(
      el("div", {
        id: "ie6-about-copyright",
        text: "Copyright \u00A91995-2004 Microsoft Corp.",
      })
    );

    const okBtn = el("button", { id: "ie6-about-ok", text: "OK" });
    okBtn.addEventListener("click", () => win.close());
    root.appendChild(okBtn);

    win.setTimeout(() => {
      try {} catch (e) {}
    }, 500);

    function forceSize(tag) {
      try {
        win.resizeTo(430, 366);
      } catch (e) {}
    }

    forceSize("inmediato");
    win.setTimeout(() => forceSize("+50ms"), 50);
    win.setTimeout(() => forceSize("+300ms"), 300);
    win.setTimeout(() => forceSize("+1000ms"), 1000);
    win.addEventListener("load", () => forceSize("evento load"), { once: true });
  }

  function tryAttach(win) {
    try {
      const doc = win.document;
      const isAboutWin =
        doc.documentElement.getAttribute("windowtype") === IE6_ABOUT_WINDOWTYPE ||
        win.location.href === IE6_ABOUT_URL;
      if (!isAboutWin) return;
      if (doc.readyState === "complete" || doc.readyState === "interactive") {
        buildIE6Content(doc);
      }
      win.addEventListener("load", () => buildIE6Content(doc), { once: true });
    } catch (e) {}
  }

  const windowListener = {
    onOpenWindow(xulWin) {
      try {
        const win = xulWin.docShell.domWindow;
        win.addEventListener("DOMContentLoaded", () => tryAttach(win), {
          once: true,
        });
      } catch (e) {}
    },
    onCloseWindow() {},
  };

  Services.wm.addListener(windowListener);
})();