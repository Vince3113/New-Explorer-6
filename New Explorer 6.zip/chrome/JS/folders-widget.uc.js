(function () {
  const { CustomizableUI } = ChromeUtils.importESModule(
    "moz-src:///browser/components/customizableui/CustomizableUI.sys.mjs"
  );

  CustomizableUI.createWidget({
    id: "ie6-folders-button",
    type: "button",
    label: "Folders",
    tooltiptext: "Folders",
    onCommand() {
      window.ie6ToggleFoldersSidebar?.();
    },
    onCreated(node) {
      const doc = node.ownerDocument;
      doc.defaultView.setTimeout(() => {
        if (node.querySelector(".ie6-btn-label")) return;
        const label = doc.createXULElement("label");
        label.className = "ie6-btn-label";
        label.setAttribute("value", "Folders");
        node.appendChild(label);
      }, 0);
    },
  });
})();