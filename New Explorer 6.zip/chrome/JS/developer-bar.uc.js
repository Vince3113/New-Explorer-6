(function () {
  const IMG = "resource://ie6theme/images/";
  const STATUSBAR_HEIGHT = 23;

  function runKey(id, fallback) {
    const key = document.getElementById(id);
    if (typeof key?.doCommand === "function") {
      key.doCommand();
      return;
    }
    fallback?.();
  }

  function openTab(url) {
    if (typeof window.switchToTabHavingURI === "function" && url.startsWith("about:")) {
      window.switchToTabHavingURI(url, true);
    } else if (typeof window.openTrustedLinkIn === "function") {
      window.openTrustedLinkIn(url, "tab");
    } else {
      gBrowser.selectedTab = gBrowser.addTrustedTab(url);
    }
  }

  const ITEMS = [
    {
      label: "Web Developer Tools",
      icon: "webdevelopertool.png",
      shortcut: "Ctrl+Shift+I",
      run: () => runKey("key_toggleToolbox"),
    },
    {
      label: "Task Manager",
      icon: "taskmanager.png",
      shortcut: "Shift+Esc",
      run: () => openTab("about:processes"),
    },
    {
      label: "Remote Debugging",
      icon: "remotedebug.png",
      run: () => openTab("about:debugging"),
    },
    {
      label: "Browser Toolbox",
      icon: "browsertoolbox.png",
      shortcut: "Ctrl+Shift+Alt+I",
      run: () => runKey("key_browserToolbox"),
    },
    {
      label: "Browser Console",
      icon: "browserconsole.png",
      shortcut: "Ctrl+Shift+J",
      run: () => runKey("key_browserConsole"),
    },
    {
      label: "Responsive Design Mode",
      icon: "repsonsivedesign.png",
      shortcut: "Ctrl+Shift+M",
      run: () => runKey("key_responsiveDesignMode"),
    },
    {
      label: "Eyedropper",
      icon: "eyesdropper.png",
      run: () => runKey("key_eyedropper"),
    },
    {
      label: "Page Source",
      icon: "source.png",
      shortcut: "Ctrl+U",
      run: () => runKey("key_viewSource", () => openTab("view-source:" + gBrowser.currentURI.spec)),
    },
    {
      label: "Extensions for developers",
      icon: "extensions.png",
      run: () => openTab("https://extensionworkshop.com/"),
    },
  ];

  let bar = null;
  let barOpen = false;
  let lastButtonClick = 0;

  function create(tag, className, text) {
    const el = document.createElement(tag);
    el.className = className;
    if (text != null) el.textContent = text;
    return el;
  }

  function createImage(className, src) {
    const img = create("img", className);
    img.src = IMG + src;
    img.draggable = false;
    return img;
  }

  function buildButton(item, index) {
    const btn = create("div", "dev-btn");
    btn.setAttribute("role", "button");
    btn.dataset.index = String(index);

    if (item.icon) btn.append(createImage("dev-icon", "developer/" + item.icon));
    btn.append(create("span", "dev-label", item.label));
    if (item.shortcut) btn.append(create("span", "dev-key", item.shortcut));
    return btn;
  }

  function buildBar() {
    const closeCol = create("div", "dev-close-col");
    closeCol.append(createImage("dev-close", "close.png"));

    const content = create("div", "dev-content");
    content.append(...ITEMS.map(buildButton));

    const el = document.createElement("div");
    el.id = "dev-bar";
    el.hidden = true;
    el.append(closeCol, content);
    return el;
  }

  function updatePosition() {
    const tip = document.getElementById("tip-bar");
    const extra = tip && !tip.hidden ? tip.offsetHeight : 0;
    bar.style.bottom = STATUSBAR_HEIGHT + extra + "px";
  }

  function updateVisibility() {
    if (!bar) return;
    bar.hidden = !barOpen || window.fullScreen;
    if (!bar.hidden) updatePosition();
  }

  function setOpen(open) {
    if (!bar) {
      bar = buildBar();
      document.documentElement.appendChild(bar);
    }
    barOpen = open;
    updateVisibility();
  }

  const toggleBar = () => setOpen(!barOpen);

  document.addEventListener(
    "click",
    (e) => {
      const target = e.target;
      if (!target?.closest) return;

      if (target.closest("#developer-button")) {
        e.preventDefault();
        e.stopPropagation();
        lastButtonClick = performance.now();
        toggleBar();
        return;
      }

      if (target.closest(".dev-close")) {
        e.preventDefault();
        setOpen(false);
        return;
      }

      const btn = target.closest(".dev-btn");
      if (!btn) return;

      e.preventDefault();
      const item = ITEMS[Number(btn.dataset.index)];
      window.ie6PlayClickSound?.();
      setOpen(false);
      try {
        item?.run();
      } catch (ex) {}
    },
    true
  );

  document.addEventListener(
    "command",
    (e) => {
      if (!e.target?.closest?.("#developer-button")) return;
      e.stopPropagation();
      if (performance.now() - lastButtonClick > 300) toggleBar();
    },
    true
  );

  document.addEventListener(
    "keydown",
    (e) => {
      if (e.key === "Escape" && barOpen) setOpen(false);
    },
    true
  );

  window.addEventListener("resize", updateVisibility);
  window.addEventListener("fullscreen", updateVisibility);

  window.ie6ToggleDeveloperBar = toggleBar;
})();