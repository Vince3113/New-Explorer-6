(function () {
  const POPUP_ID = "contentAreaContextMenu";
  const IMG_HIDE_CLASS = "imgctx-hide";
  const IMG_SEP_CLASS = "imgctx-sep-hide";

  const IMG_HIDE = [/^Copy Image Link$/, /^View Image Info$/];

  const RENAMES = [
    { pattern: /^Open Link in New Tab$/, text: "Open Link", accesskey: "O" },
    { pattern: /^Open Image in New Tab/, text: "Show Picture", accesskey: "S" },
    { pattern: /^Save Image As/, text: "Save Picture As", accesskey: "v" },
    { pattern: /^Copy Image$/, text: "Copy Picture", accesskey: "y" },
    { pattern: /^Email Image/, text: "Email Picture", accesskey: "m", anchor: true },
    { pattern: /^Search Image with Google Lens$/, text: "Search Picture in the Internet", accesskey: "h" },
    {
      pattern: /^Set Image as Desktop Background.*$/,
      text: "Set as Background",
      accesskey: "B",
      separatorAbove: true,
    },
  ];

  let backgroundItem = null;
  let emailItem = null;
  let printItem = null;
  let picturesItem = null;
  let imageUrl = "";

  function tryRun(...attempts) {
    for (const fn of attempts) {
      try {
        if (fn() !== false) return;
      } catch (e) {}
    }
  }

  function cmd(id) {
    return () => {
      const el = document.getElementById(id);
      if (!el) return false;
      el.doCommand();
    };
  }

  const ACTIONS = {
    back: () => window.gBrowser.goBack(),
    forward: () => window.gBrowser.goForward(),
    selectAll: () => tryRun(() => window.goDoCommand("cmd_selectAll"), cmd("context-selectall")),
    createShortcut: () => tryRun(cmd("ie6-file-send-shortcut")),
    addFavorite: () =>
      tryRun(cmd("Browser:AddBookmarkAs"), () => window.PlacesCommandHook.bookmarkPage()),
    viewSource: () =>
      tryRun(cmd("View:PageSource"), () =>
        window.openTrustedLinkIn("view-source:" + window.gBrowser.selectedBrowser.currentURI.spec, "tab")
      ),
    autoEncoding: () =>
      tryRun(cmd("repair-text-encoding"), () => window.BrowserCommands.forceEncodingDetection()),
    print: () =>
      tryRun(cmd("cmd_print"), () =>
        window.PrintUtils.startPrintWindow(window.gBrowser.selectedBrowser.browsingContext)
      ),
    refresh: () => window.gBrowser.selectedBrowser.reload(),
    properties: () =>
      tryRun(
        () => window.BrowserCommands.pageInfo(),
        () => window.BrowserPageInfo(),
        cmd("context-viewinfo")
      ),
  };

  const LAYOUT = [
    { id: "back", label: "Back", accesskey: "k" },
    { id: "forward", label: "Forward", accesskey: "w" },
    "-",
    { id: "savebg", label: "Save Background As...", accesskey: "g", disabled: true },
    { id: "setbg", label: "Set as Background", accesskey: "B", disabled: true },
    { id: "copybg", label: "Copy Background", accesskey: "C", disabled: true },
    { id: "setdesktop", label: "Set as Desktop Item...", accesskey: "D", disabled: true },
    "-",
    { id: "selectAll", label: "Select All", accesskey: "A" },
    { id: "paste", label: "Paste", accesskey: "P", disabled: true },
    "-",
    { id: "createShortcut", label: "Create Shortcut", accesskey: "T" },
    { id: "addFavorite", label: "Add to Favorites...", accesskey: "F" },
    { id: "viewSource", label: "View Source", accesskey: "V" },
    "-",
    {
      id: "encoding",
      label: "Encoding",
      accesskey: "E",
      submenu: [{ id: "autoEncoding", label: "Auto-Select", accesskey: "A" }],
    },
    "-",
    { id: "print", label: "Print", accesskey: "P" },
    { id: "refresh", label: "Refresh", accesskey: "R" },
    "-",
    { id: "properties", label: "Properties", accesskey: "r" },
  ];

  function createNode(tag, { id, label, accesskey }) {
    const node = document.createXULElement(tag);
    node.id = "ie6-ctx-" + id;
    node.className = "ie6-ctx";
    node.setAttribute("label", label);
    if (accesskey) node.setAttribute("accesskey", accesskey);
    return node;
  }

  function makeItem(def) {
    const item = createNode("menuitem", def);
    if (def.disabled) item.setAttribute("disabled", "true");
    else if (ACTIONS[def.id]) item.addEventListener("command", ACTIONS[def.id]);
    return item;
  }

  function build(popup) {
    for (const entry of LAYOUT) {
      if (entry === "-") {
        const separator = document.createXULElement("menuseparator");
        separator.className = "ie6-ctx";
        popup.appendChild(separator);
      } else if (entry.submenu) {
        const menu = createNode("menu", entry);
        const sub = document.createXULElement("menupopup");
        for (const s of entry.submenu) sub.appendChild(makeItem(s));
        menu.appendChild(sub);
        popup.appendChild(menu);
      } else {
        popup.appendChild(makeItem(entry));
      }
    }
  }

  function printPicture() {
    if (!imageUrl) return;
    const tab = window.gBrowser.addTab(imageUrl, {
      triggeringPrincipal: Services.scriptSecurityManager.getSystemPrincipal(),
    });
    window.gBrowser.selectedTab = tab;
    const target = tab.linkedBrowser;
    const done = Ci.nsIWebProgressListener.STATE_STOP | Ci.nsIWebProgressListener.STATE_IS_WINDOW;
    const listener = {
      onStateChange(browser, webProgress, request, flags) {
        if (browser !== target || !webProgress.isTopLevel || (flags & done) !== done) return;
        if (target.currentURI.spec === "about:blank") return;
        window.gBrowser.removeTabsProgressListener(listener);
        window.PrintUtils.startPrintWindow(target.browsingContext);
      },
    };
    window.gBrowser.addTabsProgressListener(listener);
    tab.addEventListener(
      "TabClose",
      () => window.gBrowser.removeTabsProgressListener(listener),
      { once: true }
    );
  }

  function openMyPictures() {
    tryRun(
      () => {
        const dir = Services.dirsvc.get("Pers", Ci.nsIFile);
        dir.append("Pictures");
        dir.launch();
      },
      () => {
        const dir = Services.dirsvc.get("Home", Ci.nsIFile);
        dir.append("Documents");
        dir.append("Pictures");
        dir.launch();
      }
    );
  }

  function createAction(id, label, accesskey, handler) {
    const item = document.createXULElement("menuitem");
    item.id = id;
    item.setAttribute("label", label);
    item.setAttribute("accesskey", accesskey);
    item.addEventListener("command", handler);
    return item;
  }

  function ensureImageActions(cm) {
    if (!emailItem || !emailItem.isConnected) return;
    if (!printItem) {
      printItem = createAction("ctximg-print-picture", "Print Picture", "P", printPicture);
      picturesItem = createAction("ctximg-my-pictures", "Go to My Pictures", "G", openMyPictures);
    }
    if (emailItem.nextElementSibling !== printItem) emailItem.after(printItem);
    if (printItem.nextElementSibling !== picturesItem) printItem.after(picturesItem);
    const visible = !!cm && !!cm.onImage;
    printItem.classList.toggle(IMG_HIDE_CLASS, !visible);
    picturesItem.classList.toggle(IMG_HIDE_CLASS, !visible);
  }

  function isShown(el) {
    return !el.hidden && getComputedStyle(el).display !== "none";
  }

  function hideSeparatorAbove(item) {
    for (let prev = item.previousElementSibling; prev; prev = prev.previousElementSibling) {
      if (!isShown(prev)) continue;
      if (prev.localName === "menuseparator") prev.classList.add(IMG_SEP_CLASS);
      return;
    }
  }

  function adjustNativeItems(popup) {
    for (const el of popup.children) {
      if (el.localName === "menuseparator") {
        el.classList.remove(IMG_SEP_CLASS);
        continue;
      }
      const label = el.getAttribute("label") || "";
      el.classList.toggle(IMG_HIDE_CLASS, IMG_HIDE.some((p) => p.test(label)));
      for (const rule of RENAMES) {
        if (!rule.pattern.test(label)) continue;
        el.setAttribute("label", label.replace(rule.pattern, rule.text));
        el.setAttribute("accesskey", rule.accesskey);
        if (rule.separatorAbove) backgroundItem = el;
        if (rule.anchor) emailItem = el;
        break;
      }
    }
    const cm = window.gContextMenu;
    imageUrl = cm && cm.onImage ? cm.mediaURL || cm.imageURL || "" : "";
    ensureImageActions(cm);
    if (backgroundItem && backgroundItem.isConnected && cm && cm.onImage) {
      hideSeparatorAbove(backgroundItem);
    }
  }

  function isPlainPage(cm) {
    return (
      !!cm &&
      !(
        cm.onLink ||
        cm.onImage ||
        cm.onVideo ||
        cm.onAudio ||
        cm.onCanvas ||
        cm.onEditable ||
        cm.onTextInput ||
        cm.onKeywordField ||
        cm.isTextSelected
      )
    );
  }

  function setDisabled(id, disabled) {
    const el = document.getElementById(id);
    if (!el) return;
    if (disabled) el.setAttribute("disabled", "true");
    else el.removeAttribute("disabled");
  }

  function init() {
    const popup = document.getElementById(POPUP_ID);
    if (!popup || document.getElementById("ie6-ctx-back")) return;

    build(popup);

    popup.addEventListener("popupshowing", (event) => {
      if (event.target !== popup || event.defaultPrevented) return;

      adjustNativeItems(popup);

      if (isPlainPage(window.gContextMenu)) {
        popup.setAttribute("ie6-plain", "true");
        const browser = window.gBrowser.selectedBrowser;
        setDisabled("ie6-ctx-back", !browser.canGoBack);
        setDisabled("ie6-ctx-forward", !browser.canGoForward);
      } else {
        popup.removeAttribute("ie6-plain");
      }
    });
  }

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();