(function () {
  const HTML_NS = "http://www.w3.org/1999/xhtml";

  const ICON_DIR = (() => {
    const dir = Services.dirsvc.get("ProfD", Ci.nsIFile);
    dir.append("chrome");
    dir.append("images");
    return Services.io.newFileURI(dir).spec.replace(/\/?$/, "/");
  })();

  const SORT_OPTIONS = [
    { label: "Name (A-Z)", value: "name-asc" },
    { label: "Name (Z-A)", value: "name-desc" },
    { label: "Recently used", value: "recent" },
  ];

  let sidebar;
  let listEl;
  let countEl;
  let currentLogins = [];
  let currentSort = "name-asc";
  let activeSearchFilter = null;

  function h(tag, className, text) {
    const el = document.createElementNS(HTML_NS, tag);
    if (className) el.className = className;
    if (text != null) el.textContent = text;
    return el;
  }

  function icon(path, className) {
    const img = h("img", className);
    img.src = ICON_DIR + path;
    return img;
  }

  function createInput(className = "lg-field-input") {
    const input = h("input", className);
    input.type = "text";
    return input;
  }

  function createUserField() {
    const wrap = h("div", "lg-input-icon-wrap");
    const input = createInput("lg-field-input lg-field-input-icon");
    wrap.append(icon("passwords/profile.png", "lg-user-icon"), input);
    return { wrap, input };
  }

  const maskPassword = (pw) => "\u2022".repeat(pw ? pw.length : 0);

  function getCleanHost(login) {
    const rawHost = login.hostname || login.origin || login.formSubmitURL || "";
    return rawHost.replace(/^https?:\/\//, "").replace(/\/.*$/, "");
  }

  async function loadLogins() {
    try {
      const logins = await (Services.logins.getAllLoginsAsync?.() ?? Services.logins.getAllLogins());
      currentLogins = Array.isArray(logins) ? logins : [];
    } catch (e) {
      currentLogins = [];
    }
    renderLogins();
  }

  async function deleteLoginWithConfirm(login, host) {
    const ps = Services.prompt;
    const flags =
      ps.BUTTON_TITLE_IS_STRING * ps.BUTTON_POS_0 +
      ps.BUTTON_TITLE_IS_STRING * ps.BUTTON_POS_1;
    const buttonIndex = ps.confirmEx(
      window,
      "Delete Password",
      `Are you sure you want to delete the saved password for "${host}"? This cannot be undone.`,
      flags,
      "Delete",
      "Cancel",
      null,
      null,
      {}
    );
    if (buttonIndex !== 0) return;

    try {
      Services.logins.removeLogin(login);
    } catch (e) {
      ps.alert(window, "Error", "Could not delete this password.");
      return;
    }
    await loadLogins();
  }

  const createLoginInfo = (...args) =>
    new (Components.Constructor("@mozilla.org/login-manager/loginInfo;1", "nsILoginInfo", "init"))(...args);

  async function saveLoginEdit(login, newUsername, newPassword) {
    try {
      const updated = createLoginInfo(
        login.origin || login.hostname,
        login.formActionOrigin ?? login.formSubmitURL ?? null,
        login.httpRealm ?? null,
        newUsername,
        newPassword,
        login.usernameField || "",
        login.passwordField || ""
      );
      Services.logins.modifyLogin(login, updated);
    } catch (e) {
      Services.prompt.alert(window, "Error", "Could not save changes to this password.");
      return;
    }
    await loadLogins();
  }

  function createCustomSelect(options, initialValue, onChange) {
    const el = h("div", "sb-select");
    el.tabIndex = 0;

    const selectText = h("span", "sb-select-text");
    el.append(selectText, h("div", "sb-dropmarker"));

    const menu = h("div", "sb-dropdown");
    menu.hidden = true;
    document.body.appendChild(menu);

    const isOpen = () => !menu.hidden;
    let currentIndex = Math.max(0, options.findIndex((o) => o.value === initialValue));
    let highlightedIndex = 0;
    selectText.textContent = options[currentIndex].label;

    const items = options.map((opt, index) => {
      const item = h("div", "sb-dropdown-item", opt.label);
      item.addEventListener("mouseenter", () => setHighlight(index));
      item.addEventListener("click", (e) => {
        e.stopPropagation();
        selectOption(index);
      });
      menu.appendChild(item);
      return item;
    });

    function setHighlight(index) {
      highlightedIndex = index;
      items.forEach((item, i) => item.classList.toggle("selected", i === index));
    }

    function selectOption(index) {
      currentIndex = index;
      selectText.textContent = options[index].label;
      menu.hidden = true;
      el.focus();
      onChange?.(options[index].value);
    }

    el.addEventListener("click", (e) => {
      e.stopPropagation();
      if (isOpen()) {
        menu.hidden = true;
        return;
      }
      const rect = el.getBoundingClientRect();
      menu.style.top = `${rect.bottom}px`;
      menu.style.left = `${rect.left}px`;
      menu.style.width = `${rect.width}px`;
      menu.hidden = false;
      setHighlight(currentIndex);
    });

    el.addEventListener("keydown", (e) => {
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        if (!isOpen()) {
          el.click();
          return;
        }
        const step = e.key === "ArrowDown" ? 1 : -1;
        setHighlight((highlightedIndex + step + options.length) % options.length);
      } else if (e.key === "Enter") {
        e.preventDefault();
        if (isOpen()) selectOption(highlightedIndex);
      } else if (e.key === "Escape") {
        e.preventDefault();
        menu.hidden = true;
      }
    });

    window.addEventListener("click", () => {
      menu.hidden = true;
    });

    return { el };
  }

  function matchesSearch(login) {
    if (!activeSearchFilter) return true;
    const { site, user, pass } = activeSearchFilter;

    if (site && !getCleanHost(login).toLowerCase().includes(site)) return false;
    if (user && !(login.username || "").toLowerCase().includes(user)) return false;
    if (pass && !(login.password || "").includes(pass)) return false;
    return true;
  }

  function compareLogins(a, b) {
    const hostA = getCleanHost(a).toLowerCase();
    const hostB = getCleanHost(b).toLowerCase();
    if (currentSort === "name-asc") return hostA.localeCompare(hostB);
    if (currentSort === "name-desc") return hostB.localeCompare(hostA);
    return (b.timePasswordChanged || 0) - (a.timePasswordChanged || 0);
  }

  function createLoginItem(login) {
    const host = getCleanHost(login);
    const fullUrl = login.hostname || login.origin || "#";
    const showPassword = () => passInput.value = showPassCb.checked ? login.password : maskPassword(login.password);

    const container = h("div", "lg-item");
    const header = h("div", "lg-item-header");
    header.append(icon("passwords/key.png", "lg-key-icon"), h("span", "lg-item-title", host));

    const details = h("div", "lg-item-details");
    details.hidden = true;

    const userField = createUserField();
    const userInput = userField.input;
    userInput.value = login.username;
    userInput.readOnly = true;

    const passInput = createInput();
    passInput.value = maskPassword(login.password);
    passInput.readOnly = true;
    passInput.setAttribute("autocomplete", "off");

    const showPassCb = h("input", "sb-checkbox");
    showPassCb.type = "checkbox";
    showPassCb.addEventListener("change", showPassword);
    const showPassWrap = h("label", "lg-checkbox-label");
    showPassWrap.append(showPassCb, document.createTextNode(" Show this password"));

    const siteLink = h("a", "lg-site-link", fullUrl);
    siteLink.href = fullUrl;
    siteLink.addEventListener("click", (e) => {
      e.preventDefault();
      if (window.openTrustedLinkIn) window.openTrustedLinkIn(fullUrl, "tab");
      else window.open(fullUrl, "_blank");
    });

    const editBtn = h("button", null, "Edit");
    const deleteBtn = h("button", null, "Delete");
    const saveBtn = h("button", null, "Save");
    const cancelBtn = h("button", null, "Cancel");
    saveBtn.hidden = true;
    cancelBtn.hidden = true;
    const actions = h("div", "lg-actions");
    actions.append(editBtn, deleteBtn, saveBtn, cancelBtn);

    function setEditing(editing) {
      userInput.readOnly = !editing;
      passInput.readOnly = !editing;
      editBtn.hidden = editing;
      deleteBtn.hidden = editing;
      saveBtn.hidden = !editing;
      cancelBtn.hidden = !editing;
    }

    editBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      setEditing(true);
      passInput.value = login.password;
      showPassCb.checked = true;
      userInput.focus();
    });

    cancelBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      setEditing(false);
      userInput.value = login.username;
      showPassword();
    });

    saveBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      saveLoginEdit(login, userInput.value, passInput.value);
    });

    deleteBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      deleteLoginWithConfirm(login, host);
    });

    details.append(
      h("div", "lg-sub-title", "Credentials:"),
      h("label", "lg-field-label", "User:"),
      userField.wrap,
      h("label", "lg-field-label", "Password"),
      passInput,
      showPassWrap,
      h("label", "lg-field-label", "Site Address:"),
      siteLink,
      actions
    );

    header.addEventListener("click", () => {
      const wasExpanded = !details.hidden;

      listEl.querySelectorAll(".lg-item-details").forEach((d) => (d.hidden = true));
      listEl.querySelectorAll(".lg-item").forEach((c) => c.classList.remove("selected"));

      if (!wasExpanded) {
        details.hidden = false;
        container.classList.add("selected");
      }
    });

    container.append(header, details);
    return container;
  }

  function renderLogins() {
    if (!listEl) return;
    listEl.textContent = "";

    const logins = currentLogins.filter(matchesSearch);
    if (countEl) countEl.textContent = `(${logins.length})`;

    if (!logins.length) {
      listEl.appendChild(
        h("div", "lg-empty-msg", activeSearchFilter ? "No passwords match your search." : "No saved passwords.")
      );
      return;
    }

    listEl.append(...logins.sort(compareLogins).map(createLoginItem));
  }

  function buildAddView() {
    const siteInput = createInput();
    siteInput.placeholder = "https://www.example.com";
    const userField = createUserField();
    const passInput = createInput();
    const saveBtn = h("button", null, "Save");
    const cancelBtn = h("button", null, "Cancel");

    const actions = h("div", "lg-actions");
    actions.append(saveBtn, cancelBtn);

    const wrap = h("div", "lg-form");
    wrap.hidden = true;
    wrap.append(
      h("label", "lg-field-label", "Website address:"),
      siteInput,
      h("label", "lg-field-label", "User:"),
      userField.wrap,
      h("label", "lg-field-label", "Password:"),
      passInput,
      actions
    );

    return {
      wrap,
      saveBtn,
      cancelBtn,
      siteInput,
      userInput: userField.input,
      passInput,
      reset() {
        siteInput.value = "";
        userField.input.value = "";
        passInput.value = "";
      },
    };
  }

  function buildSearchView() {
    const siteInput = createInput();
    const userField = createUserField();
    const passInput = createInput();
    const goBtn = h("button", null, "Search");
    const stopBtn = h("button", null, "Stop");

    const actions = h("div", "lg-actions");
    actions.append(goBtn, stopBtn);

    const wrap = h("div", "lg-form");
    wrap.hidden = true;
    wrap.append(
      h("label", "lg-field-label", "Website address:"),
      siteInput,
      h("label", "lg-field-label", "User:"),
      userField.wrap,
      h("label", "lg-field-label", "Password:"),
      passInput,
      h("div", "lg-search-warning", "Warning: password matches are searched in plain text and are case-sensitive."),
      actions
    );

    return {
      wrap,
      goBtn,
      stopBtn,
      siteInput,
      userInput: userField.input,
      passInput,
      reset() {
        siteInput.value = "";
        userField.input.value = "";
        passInput.value = "";
      },
    };
  }

  async function saveNewLogin(addView) {
    const rawSite = addView.siteInput.value.trim();
    const username = addView.userInput.value;
    const password = addView.passInput.value;
    const alertError = (message) => Services.prompt.alert(window, "Error", message);

    if (!rawSite) return alertError("Please enter a website address.");
    if (!password) return alertError("Please enter a password.");

    let origin;
    try {
      const url = new URL(rawSite);
      if (url.protocol !== "http:" && url.protocol !== "https:") throw new Error("invalid protocol");
      origin = url.origin;
    } catch (e) {
      return alertError("Please enter a valid website address (e.g. https://www.example.com).");
    }

    try {
      const newLogin = createLoginInfo(origin, origin, null, username, password, "", "");
      if (Services.logins.addLoginAsync) await Services.logins.addLoginAsync(newLogin);
      else Services.logins.addLogin(newLogin);
    } catch (e) {
      return alertError("Could not save this password. It may already exist for this site.");
    }

    return true;
  }

  function setLoginsButtonOpen(isOpen) {
    const btn = document.getElementById("logins-button");
    if (!btn) return;
    if (isOpen) btn.setAttribute("open", "true");
    else btn.removeAttribute("open");
  }

  function hideSidebar() {
    sidebar.hidden = true;
    setLoginsButtonOpen(false);
  }

  function buildTitlebar() {
    const closeBtn = icon("close.png", "sb-flatbtn sb-close-btn");
    closeBtn.title = "Close";
    closeBtn.addEventListener("click", hideSidebar);

    const titlebar = h("div", "sb-titlebar");
    titlebar.append(h("span", null, "Passwords"), closeBtn);
    return titlebar;
  }

  function createToolbarItem(iconPath, label) {
    const item = h("span", "lg-toolbar-item");
    item.append(icon(iconPath, "lg-toolbar-icon"), h("span", null, label));
    return item;
  }

  function ensureSidebar() {
    if (sidebar) return sidebar;

    sidebar = document.createXULElement("vbox");
    sidebar.id = "ie6-logins-sidebar";
    sidebar.className = "sb-panel";
    sidebar.hidden = true;

    const searchEl = createToolbarItem("passwords/search.png", "Search");
    const addEl = createToolbarItem("passwords/add.png", "Add");
    const toolbar = h("div", "lg-toolbar");
    toolbar.append(searchEl, addEl);

    const banner = h("div", "lg-banner");
    banner.appendChild(icon("passwords/bannerpasswords.png", "lg-banner-img"));

    const filterSelect = createCustomSelect(SORT_OPTIONS, currentSort, (value) => {
      currentSort = value;
      renderLogins();
    });
    countEl = h("span", "lg-count-label", "(0)");
    const filterBar = h("div", "lg-filter-bar");
    filterBar.append(h("label", "lg-filter-label", "Filter by:"), filterSelect.el, countEl);

    listEl = h("div", "lg-list");
    const listWrap = h("div", "lg-list-wrap");
    listWrap.appendChild(listEl);

    const addView = buildAddView();
    const searchView = buildSearchView();

    sidebar.append(buildTitlebar(), toolbar, banner, filterBar, listWrap, addView.wrap, searchView.wrap);

    const setView = (view) => {
      filterBar.hidden = view !== "list";
      listWrap.hidden = view !== "list";
      addView.wrap.hidden = view !== "add";
      searchView.wrap.hidden = view !== "search";
    };

    const runSearchFilter = () => {
      const site = searchView.siteInput.value.trim().toLowerCase();
      const user = searchView.userInput.value.trim().toLowerCase();
      const pass = searchView.passInput.value;
      activeSearchFilter = site || user || pass ? { site, user, pass } : null;
      setView("list");
      renderLogins();
    };

    const clearSearchFilter = () => {
      activeSearchFilter = null;
      searchView.reset();
      setView("list");
      renderLogins();
    };

    const clickHandlers = new Map([
      [searchEl, () => {
        setView("search");
        searchView.siteInput.focus();
      }],
      [addEl, () => {
        setView("add");
        addView.reset();
        addView.siteInput.focus();
      }],
      [addView.cancelBtn, () => setView("list")],
      [addView.saveBtn, async () => {
        if (!(await saveNewLogin(addView))) return;
        setView("list");
        await loadLogins();
      }],
      [searchView.goBtn, runSearchFilter],
      [searchView.stopBtn, clearSearchFilter],
    ]);

    document.addEventListener(
      "click",
      (e) => {
        const target = e.target.closest?.(".lg-toolbar-item, #ie6-logins-sidebar button");
        clickHandlers.get(target)?.();
      },
      true
    );

    const browserBox = document.getElementById("browser");
    browserBox.insertBefore(sidebar, browserBox.firstChild);

    window.__ie6Sidebars ||= {
      panels: {},
      register(id, hideFn) {
        this.panels[id] = hideFn;
      },
      closeOthers(exceptId) {
        for (const [id, hideFn] of Object.entries(this.panels)) {
          if (id !== exceptId) hideFn();
        }
      },
    };
    window.__ie6Sidebars.register("logins", hideSidebar);

    return sidebar;
  }

  async function toggleLoginsSidebar() {
    ensureSidebar();
    if (!sidebar.hidden) return hideSidebar();

    window.__ie6Sidebars?.closeOthers("logins");
    await loadLogins();
    sidebar.hidden = false;
    setLoginsButtonOpen(true);
  }

  window.ie6ToggleLoginsSidebar = toggleLoginsSidebar;

  function hookLoginsButton(e) {
    if (!e.target.closest?.("#logins-button")) return;
    e.preventDefault();
    e.stopPropagation();
    toggleLoginsSidebar();
  }
  document.addEventListener("click", hookLoginsButton, true);
  document.addEventListener("command", hookLoginsButton, true);
})();