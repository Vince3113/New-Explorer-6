(function () {
  const TABS_PREF = "ie6theme.tabs.forcehidden";
  const TABS_ITEM_ID = "toggle-tabs-menuitem";
  const URLBAR_HEIGHT = 22;
  const MENUBAR_TOGGLE =
    'menuitem:not(.toolbar-toggle):is([toolbarId="toolbar-menubar"], [id*="menubar" i], [label="Menu Bar"])';
  const NATIVE_TOGGLE =
    'menuitem:not(.toolbar-toggle):is([type="checkbox"], [toolbarId], [id*="menubar" i], [label="Menu Bar"])';

  const FLAGS = [
    { id: "toggle-standard-menuitem", label: "Standard Buttons", pref: "ie6theme.standard.hidden", attr: "ie6-standard-hidden" },
    { id: "toggle-address-menuitem", label: "Address Bar", pref: "ie6theme.address.hidden", attr: "ie6-address-hidden" },
    { id: "toggle-links-menuitem", label: "Links", pref: "ie6theme.links.hidden", attr: "ie6-links-hidden" },
  ];

  const root = document.documentElement;
  const getToolbar = () => document.getElementById("TabsToolbar");

  function setFlag(el, name, on) {
    if (on) el.setAttribute(name, "true");
    else el.removeAttribute(name);
  }

  function hideElement(el) {
    el.hidden = true;
    el.style.setProperty("display", "none", "important");
  }

  function guardPopup(popup, hide) {
    const run = () => hide(popup);
    run();
    new MutationObserver(run).observe(popup, { childList: true });
    popup.addEventListener("popupshowing", (event) => {
      if (event.target === popup) run();
    });
  }

  function keepMenubarVisible() {
    const menubar = document.getElementById("toolbar-menubar");
    if (!menubar) return;
    if (menubar.getAttribute("autohide") !== "false") {
      try {
        CustomizableUI.setToolbarVisibility("toolbar-menubar", true);
      } catch (e) {}
      menubar.setAttribute("autohide", "false");
    }
    menubar.removeAttribute("inactive");
  }

  function watchMenubar() {
    const menubar = document.getElementById("toolbar-menubar");
    if (!menubar) return;
    menubar.setAttribute("autohide", "false");
    menubar.removeAttribute("inactive");
  }

  function hideMenubarToggle(popup) {
    for (const item of popup.querySelectorAll(MENUBAR_TOGGLE)) hideElement(item);
  }

  function hideNativeToggles(popup) {
    for (const item of popup.querySelectorAll(NATIVE_TOGGLE)) hideElement(item);
  }

  function syncUrlbarTop() {
    const container = document.getElementById("urlbar-container");
    const urlbar = document.getElementById("urlbar");
    if (!container || !urlbar) return;
    const box = container.getBoundingClientRect();
    if (!box.height) return;
    const parent = urlbar.offsetParent;
    const base = parent ? parent.getBoundingClientRect().top + parent.clientTop : 0;
    const top = box.top + (box.height - URLBAR_HEIGHT) / 2 - base;
    root.style.setProperty("--urlbar-top", top + "px");
  }

  function watchUrlbarPosition() {
    const toolbox = document.getElementById("navigator-toolbox");
    if (!toolbox) return;
    new ResizeObserver(syncUrlbarTop).observe(toolbox);
    window.addEventListener("resize", syncUrlbarTop);
    syncUrlbarTop();
  }

  function toggleTabs() {
    const toolbar = getToolbar();
    if (!toolbar) return;
    const hide = !toolbar.hasAttribute("ie6-hidden");
    Services.prefs.setBoolPref(TABS_PREF, hide);
    setFlag(toolbar, "ie6-hidden", hide);
  }

  function toggleFlag(flag) {
    const hide = !root.hasAttribute(flag.attr);
    Services.prefs.setBoolPref(flag.pref, hide);
    setFlag(root, flag.attr, hide);
    syncBookmarks();
  }

  function placeTabsItem(menu, menuitem) {
    const separator = document.getElementById("viewToolbarsMenuSeparator");
    if (separator?.parentNode) {
      if (separator.previousElementSibling !== menuitem) {
        separator.parentNode.insertBefore(menuitem, separator);
      }
      return;
    }
    const menubarToggle = document.getElementById("toggle_toolbar_menubar");
    if (menubarToggle?.parentNode) {
      menubarToggle.parentNode.insertBefore(menuitem, menubarToggle.nextSibling);
      return;
    }
    menu.appendChild(menuitem);
  }

  function createItem(id, label, onCommand) {
    const menuitem = document.createXULElement("menuitem");
    menuitem.id = id;
    menuitem.className = "toolbar-toggle";
    menuitem.setAttribute("type", "checkbox");
    menuitem.setAttribute("autocheck", "false");
    menuitem.setAttribute("label", label);
    menuitem.addEventListener("command", onCommand);
    return menuitem;
  }

  function buildToggles(idPrefix) {
    const tabs = createItem(idPrefix + TABS_ITEM_ID, "Tabs", toggleTabs);
    const flags = FLAGS.map((flag) => ({
      flag,
      item: createItem(idPrefix + flag.id, flag.label, () => toggleFlag(flag)),
    }));
    return { tabs, flags, all: [tabs, ...flags.map(({ item }) => item)] };
  }

  function syncChecked({ tabs, flags }) {
    const toolbar = getToolbar();
    setFlag(tabs, "checked", !!toolbar && !toolbar.hasAttribute("ie6-hidden"));
    for (const { flag, item } of flags) {
      setFlag(item, "checked", !root.hasAttribute(flag.attr));
    }
  }

  function addContextItems() {
    const menu = document.getElementById("toolbar-context-menu");
    if (!menu || document.getElementById(TABS_ITEM_ID)) return;

    const toggles = buildToggles("");

    const place = () => {
      placeTabsItem(menu, toggles.tabs);
      let previous = toggles.tabs;
      for (const { item } of toggles.flags) {
        if (previous.nextElementSibling !== item) previous.after(item);
        previous = item;
      }
    };
    place();
    guardPopup(menu, hideMenubarToggle);

    menu.addEventListener("popupshowing", (event) => {
      if (event.target !== menu) return;
      place();
      syncChecked(toggles);
    });
  }

  function addViewItems() {
    const popup = document.querySelector("#viewToolbarsMenu > menupopup");
    if (!popup || document.getElementById("view-" + TABS_ITEM_ID)) return;

    const toggles = buildToggles("view-");

    const place = () => {
      const anchor =
        popup.querySelector(":scope > menuseparator") ||
        popup.querySelector(':scope > menuitem[command="cmd_CustomizeToolbars"]');
      for (const item of toggles.all) {
        if (anchor) anchor.before(item);
        else popup.append(item);
      }
    };
    place();
    guardPopup(popup, hideNativeToggles);

    popup.addEventListener("popupshowing", (event) => {
      if (event.target !== popup) return;
      place();
      syncChecked(toggles);
    });
  }

  let homeParent = null;
  let homeNext = null;

  function syncBookmarks(attempt = 0) {
    const items = document.getElementById("personal-bookmarks");
    const address = document.getElementById("ie6-address-toolbar");
    if (!items || !address) {
      if (attempt < 20) setTimeout(() => syncBookmarks(attempt + 1), 500);
      return;
    }
    const inRow = root.hasAttribute("ie6-address-hidden") && !root.hasAttribute("ie6-links-hidden");
    if (inRow) {
      if (items.parentNode === address) return;
      homeParent = items.parentNode;
      homeNext = items.nextSibling;
      address.appendChild(items);
      return;
    }
    if (items.parentNode !== address || !homeParent) return;
    const next = homeNext?.parentNode === homeParent ? homeNext : null;
    homeParent.insertBefore(items, next);
  }

  function init() {
    for (const flag of FLAGS) {
      setFlag(root, flag.attr, Services.prefs.getBoolPref(flag.pref, false));
    }
    addContextItems();
    addViewItems();
    watchMenubar();
    syncBookmarks();
    watchUrlbarPosition();
  }

  if (gBrowserInit?.delayedStartupFinished) {
    init();
    return;
  }

  const onStartup = (subject, topic) => {
    if (subject !== window) return;
    Services.obs.removeObserver(onStartup, topic);
    init();
  };
  Services.obs.addObserver(onStartup, "browser-delayed-startup-finished");
})();