(function () {
  const $ = (id) => document.getElementById(id);

  let targetBrowser = null;
  let lastSearch = null;

  function doFind() {
    const finder = targetBrowser && targetBrowser.finder;
    const text = $("find-input").value;
    if (!finder || !text) return;

    finder.caseSensitive = $("find-matchcase").checked;
    finder.entireWord = $("find-wholeword").checked;

    if (text !== lastSearch) {
      finder.fastFind(text, false, false);
      lastSearch = text;
    } else {
      finder.findAgain(text, $("find-dir-up").checked, false, false);
    }
  }

  function closeWindow() {
    try { window.close(); } catch (e) {}
  }

  function closeIfDuplicate() {
    const windows = Services.wm.getEnumerator("ie6-find-window");
    let count = 0;
    let first = null;
    while (windows.hasMoreElements()) {
      const win = windows.getNext();
      count++;
      first = first || win;
    }
    if (count > 1 && first !== window) {
      first.focus();
      closeWindow();
      return true;
    }
    return false;
  }

  function syncColorScheme(parentWin) {
    const src = parentWin.document.documentElement;
    const dst = document.documentElement;
    const sync = () => {
      const v = src.getAttribute("ie6-colorscheme");
      if (v) dst.setAttribute("ie6-colorscheme", v);
      else dst.removeAttribute("ie6-colorscheme");
    };
    sync();
    const mo = new parentWin.MutationObserver(sync);
    mo.observe(src, { attributes: true, attributeFilter: ["ie6-colorscheme"] });
    window.addEventListener("unload", () => { try { mo.disconnect(); } catch (e) {} }, { once: true });
  }

  function closeWithTarget(parentWin) {
    const onTabClose = (e) => {
      if (e.target.linkedBrowser === targetBrowser) closeWindow();
    };
    parentWin.addEventListener("unload", closeWindow, { once: true });
    parentWin.gBrowser.tabContainer.addEventListener("TabClose", onTabClose);
    window.addEventListener("unload", () => {
      try {
        parentWin.removeEventListener("unload", closeWindow);
        parentWin.gBrowser.tabContainer.removeEventListener("TabClose", onTabClose);
      } catch (e) {}
    }, { once: true });
  }

  function init() {
    try {
      if (closeIfDuplicate()) return;
    } catch (e) {}

    const parentWin = Services.wm.getMostRecentWindow("navigator:browser");
    if (!parentWin || !parentWin.gBrowser) {
      closeWindow();
      return;
    }
    targetBrowser = parentWin.gBrowser.selectedBrowser;

    try {
      syncColorScheme(parentWin);
    } catch (e) {}
    closeWithTarget(parentWin);

    const input = $("find-input");
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        doFind();
      }
    });
    setTimeout(() => input.focus(), 50);

    $("find-btn-next").addEventListener("click", doFind);
    $("find-btn-cancel").addEventListener("click", closeWindow);
    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        closeWindow();
      }
    });
  }

  window.addEventListener("load", init, { once: true });
})();