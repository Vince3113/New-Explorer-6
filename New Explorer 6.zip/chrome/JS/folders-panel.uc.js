(function () {
  const HTML_NS = "http://www.w3.org/1999/xhtml";

  const ICON_DIR = (() => {
    const dir = Services.dirsvc.get("ProfD", Ci.nsIFile);
    dir.append("chrome");
    dir.append("images");
    return Services.io.newFileURI(dir).spec.replace(/\/?$/, "/");
  })();

  const RENDERABLE_EXT = new Set([
    "jpg", "jpeg", "png", "gif", "bmp", "webp", "svg", "ico",
    "txt", "log", "csv", "md", "json", "xml",
    "html", "htm", "pdf",
    "mp4", "m4v", "webm", "ogv", "ogg",
    "mp3", "oga", "wav", "flac", "m4a", "aac", "opus",
  ]);

  const HIDDEN_NAMES = new Set([
    "desktop.ini",
    "thumbs.db",
    "default.rdp",
    "$recycle.bin",
    "system volume information",
  ]);

  const CUSTOM_FOLDERS = [];

  const CONTROL_PANEL_GUID = "{26EE0668-A00A-44D7-9371-BEB064C98683}";

  const CONTROL_PANEL_CATEGORIES = [
    { label: "Accessibility Options", icon: "accessibility.png", category: 7 },
    { label: "Add or Remove Programs", icon: "programs.png", category: 8 },
    { label: "Appearance and Themes", icon: "appearance.png", category: 1 },
    { label: "Date, Time, Language, and Regional Options", icon: "region.png", category: 6 },
    { label: "Network and Internet Connections", icon: "netinter.png", category: 3 },
    { label: "Performance and Maintenance", icon: "performance.png", category: 5 },
    { label: "Sounds, Speech, and Audio Devices", icon: "sounds.png", category: 2 },
    { label: "User Accounts", icon: "accounts.png", category: 9 },
  ];

  const DRIVE_LETTERS = "CDEFGHIJKLMNOPQRSTUVWXYZ".split("");

  let sidebar;
  let listEl;
  let selectedRow = null;

  function h(tag, className, text) {
    const el = document.createElementNS(HTML_NS, tag);
    if (className) el.className = className;
    if (text != null) el.textContent = text;
    return el;
  }

  function icon(src, className = "fd-icon") {
    const img = h("img", className);
    img.src = src;
    return img;
  }

  const iconURL = (name) => ICON_DIR + name;
  const mozIconURL = (path) => "moz-icon://" + encodeURIComponent(path) + "?size=16";

  function nsFile(path) {
    const file = Components.classes["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
    file.initWithPath(path);
    return file;
  }

  function extOf(name) {
    const i = name.lastIndexOf(".");
    return i === -1 ? "" : name.slice(i + 1).toLowerCase();
  }

  function selectRow(row) {
    selectedRow?.classList.remove("fd-selected");
    selectedRow = row;
    row.classList.add("fd-selected");
  }

  const pathExists = (path) => IOUtils.exists(path).catch(() => false);

  function runExplorer(arg) {
    try {
      const process = Components.classes["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
      process.init(nsFile("C:\\Windows\\explorer.exe"));
      process.runAsync([arg], 1);
    } catch (e) {}
  }

  const openRecycleBin = () => runExplorer("shell:RecycleBinFolder");
  const openControlPanelCategory = (id) => runExplorer(`shell:::${CONTROL_PANEL_GUID}\\${id}`);

  function openFile(path) {
    const file = nsFile(path);
    if (RENDERABLE_EXT.has(extOf(file.leafName))) {
      gBrowser.selectedTab = gBrowser.addTrustedTab(Services.io.newFileURI(file).spec);
      return;
    }
    try {
      file.launch();
    } catch (e) {}
  }

  function createLeafRow(label, iconSrc, depth, onClick) {
    const row = h("div", "fd-row" + (onClick ? "" : " fd-disabled"));
    row.style.paddingLeft = 4 + depth * 12 + "px";
    row.append(h("span", "fd-expander-spacer"), icon(iconSrc), h("span", "fd-label", label));

    if (onClick) {
      row.addEventListener("click", () => {
        selectRow(row);
        onClick();
      });
    }
    return row;
  }
  
  function appendFolder(container, label, iconSrc, depth, fill) {
    const expander = icon(iconURL("expand.PNG"), "fd-expander");
    const row = h("div", "fd-row fd-folder");
    row.style.paddingLeft = 4 + depth * 12 + "px";
    row.append(expander, icon(iconSrc), h("span", "fd-label", label));

    const box = h("div", "fd-children");
    container.append(row, box);

    row.addEventListener("click", () => {
      selectRow(row);
      const opening = !box.classList.contains("fd-open");
      box.classList.toggle("fd-open", opening);
      expander.src = iconURL(opening ? "hide.PNG" : "expand.PNG");
      if (opening && !box.dataset.filled) fill(box);
    });
  }

  const appendRealFolder = (container, label, iconName, path, depth) =>
    appendFolder(container, label, iconURL(iconName), depth, (box) => fillRealFolder(path, box, depth + 1));

  async function readEntries(path) {
    const children = await IOUtils.getChildren(path);
    const entries = await Promise.all(
      children.map(async (childPath) => {
        try {
          const info = await IOUtils.stat(childPath);
          const name = childPath.split(/[\\/]/).pop();
          if (HIDDEN_NAMES.has(name.toLowerCase())) return null;
          return { path: childPath, name, isDir: info.type === "directory" };
        } catch (e) {
          return null;
        }
      })
    );
    return entries.filter(Boolean);
  }

  async function fillRealFolder(path, container, depth, { foldersOnly = false, appendOnly = false } = {}) {
    let entries;
    try {
      entries = await readEntries(path);
    } catch (e) {
      container.appendChild(h("div", "fd-empty", "(could not read folder)"));
      container.dataset.filled = "1";
      return;
    }

    if (foldersOnly) entries = entries.filter((e) => e.isDir);

    entries.sort((a, b) => {
      if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
      return a.name.localeCompare(b.name, undefined, { sensitivity: "base" });
    });

    if (!entries.length && !appendOnly) {
      container.appendChild(h("div", "fd-empty", "(empty)"));
    }

    for (const entry of entries) {
      if (entry.isDir) {
        appendRealFolder(container, entry.name, "folder.png", entry.path, depth);
      } else {
        container.appendChild(
          createLeafRow(entry.name, mozIconURL(entry.path), depth, () => openFile(entry.path))
        );
      }
    }

    if (!appendOnly) container.dataset.filled = "1";
  }

  function fillControlPanel(container, depth) {
    for (const cat of CONTROL_PANEL_CATEGORIES) {
      container.appendChild(
        createLeafRow(cat.label, iconURL(cat.icon), depth, () => openControlPanelCategory(cat.category))
      );
    }
    container.dataset.filled = "1";
  }

  async function fillDrives(container, depth) {
    const exists = await Promise.all(DRIVE_LETTERS.map((letter) => pathExists(letter + ":\\")));

    DRIVE_LETTERS.forEach((letter, i) => {
      if (exists[i]) {
        appendRealFolder(container, `Local Disk (${letter}:)`, "drive.png", letter + ":\\", depth);
      }
    });
  }

  async function existingHomePath(getDir) {
    try {
      const dir = getDir(Services.dirsvc.get("Home", Ci.nsIFile));
      return dir && (await pathExists(dir.path)) ? dir.path : null;
    } catch (e) {
      return null;
    }
  }

  const resolveMyDocumentsPath = () =>
    existingHomePath((home) => {
      home.append("Documents");
      return home;
    });

  const resolveSharedDocsPath = () =>
    existingHomePath((home) => {
      const shared = home.parent;
      shared?.append("Public");
      shared?.append("Documents");
      return shared;
    });

  async function fillMyComputer(container, depth) {
    const sharedPath = await resolveSharedDocsPath();
    if (sharedPath) appendRealFolder(container, "Shared Documents", "folder.png", sharedPath, depth);

    const userDocsPath = await resolveMyDocumentsPath();
    if (userDocsPath) appendRealFolder(container, "User's Documents", "folder.png", userDocsPath, depth);

    await fillDrives(container, depth);

    appendFolder(container, "Control Panel", iconURL("controlpanel.png"), depth, (box) =>
      fillControlPanel(box, depth + 1)
    );

    container.dataset.filled = "1";
  }

  async function fillDesktopRoot(desktopPath, container, depth) {
    const docsPath = await resolveMyDocumentsPath();
    if (docsPath) appendRealFolder(container, "My Documents", "documents.png", docsPath, depth);

    appendFolder(container, "My Computer", iconURL("computer.png"), depth, (box) =>
      fillMyComputer(box, depth + 1)
    );

    container.append(
      createLeafRow("My Network Places", iconURL("network.png"), depth, null),
      createLeafRow("Recycle Bin", iconURL("recycle-bin.png"), depth, openRecycleBin)
    );

    await fillRealFolder(desktopPath, container, depth, { foldersOnly: true, appendOnly: true });

    for (const custom of CUSTOM_FOLDERS) {
      appendRealFolder(container, custom.label, "folder.png", custom.path, depth);
    }

    container.dataset.filled = "1";
  }

  function buildRoots() {
    listEl.textContent = "";
    selectedRow = null;

    let desktopPath = null;
    try {
      desktopPath = Services.dirsvc.get("Desk", Ci.nsIFile).path;
    } catch (e) {}

    if (!desktopPath) {
      listEl.appendChild(h("div", "fd-empty", "(could not resolve Desktop)"));
      return;
    }

    const row = h("div", "fd-row fd-root");
    row.append(icon(iconURL("desktop.png")), h("span", "fd-label", "Desktop"));

    const box = h("div", "fd-children fd-open");
    listEl.append(row, box);

    row.addEventListener("click", () => {
      selectRow(row);
      const opening = !box.classList.contains("fd-open");
      box.classList.toggle("fd-open", opening);
      if (opening && !box.dataset.filled) fillDesktopRoot(desktopPath, box, 0);
    });

    fillDesktopRoot(desktopPath, box, 0);
  }

  function setFoldersButtonOpen(isOpen) {
    const btn = document.getElementById("ie6-folders-button");
    if (!btn) return;
    if (isOpen) btn.setAttribute("open", "true");
    else btn.removeAttribute("open");
  }

  function hideSidebar() {
    sidebar.hidden = true;
    setFoldersButtonOpen(false);
  }

  function ensureSidebar() {
    if (sidebar) return sidebar;

    sidebar = document.createXULElement("vbox");
    sidebar.id = "ie6-folders-sidebar";
    sidebar.className = "sb-panel";
    sidebar.hidden = true;

    const closeBtn = icon(iconURL("close.png"), "sb-flatbtn sb-close-btn");
    closeBtn.title = "Close";
    closeBtn.addEventListener("click", hideSidebar);

    const titlebar = h("div", "sb-titlebar");
    titlebar.append(h("span", null, "Folders"), closeBtn);

    listEl = h("div", "fd-list");
    const listWrap = h("div", "fd-list-wrap");
    listWrap.appendChild(listEl);

    listEl.addEventListener(
      "click",
      (e) => {
        if (e.target.closest(".fd-folder")) window.ie6PlayClickSound?.();
      },
      true
    );

    sidebar.append(titlebar, listWrap);

    const browserBox = document.getElementById("browser");
    browserBox.insertBefore(sidebar, browserBox.firstChild);

    window.__ie6Sidebars ||= {
      panels: {},
      register(id, hideFn) {
        this.panels[id] = hideFn;
      },
      closeOthers(exceptId) {
        for (const [id, hideFn] of Object.entries(this.panels)) {
          if (id !== exceptId) hideFn();
        }
      },
    };
    window.__ie6Sidebars.register("folders", hideSidebar);

    return sidebar;
  }

  function toggleFoldersSidebar() {
    ensureSidebar();
    if (!sidebar.hidden) return hideSidebar();

    window.__ie6Sidebars?.closeOthers("folders");
    sidebar.hidden = false;
    setFoldersButtonOpen(true);
    buildRoots();
  }

  window.ie6ToggleFoldersSidebar = toggleFoldersSidebar;
})();