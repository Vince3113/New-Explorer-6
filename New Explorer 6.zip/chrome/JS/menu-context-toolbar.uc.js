(function () {
  const POPUP_ID = "toolbar-context-menu";
  const NEW_LABEL = "Customize...";
  const NEW_ACCESSKEY = "C";

  function findItem(popup) {
    return (
      popup.querySelector("#toolbar-context-customize") ||
      popup.querySelector("menuitem.viewCustomizeToolbar") ||
      popup.querySelector('menuitem[observes="cmd_CustomizeToolbars"]') ||
      popup.querySelector('menuitem[command="cmd_CustomizeToolbars"]')
    );
  }

  function apply(item) {
    if (item.getAttribute("label") !== NEW_LABEL) item.setAttribute("label", NEW_LABEL);
    if (item.getAttribute("accesskey") !== NEW_ACCESSKEY) item.setAttribute("accesskey", NEW_ACCESSKEY);
  }

  function init() {
    const popup = document.getElementById(POPUP_ID);
    const item = popup && findItem(popup);
    if (!item) return;

    apply(item);
    new MutationObserver(() => apply(item)).observe(item, {
      attributes: true,
      attributeFilter: ["label", "accesskey", "data-l10n-id"],
    });
    popup.addEventListener("popupshowing", (e) => {
      if (e.target === popup) apply(item);
    });
  }

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();