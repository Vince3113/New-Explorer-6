(function () {
  const { PlacesUtils } = ChromeUtils.importESModule(
    "resource://gre/modules/PlacesUtils.sys.mjs"
  );

  const HTML_NS = "http://www.w3.org/1999/xhtml";
  const IMG = "resource://ie6theme/images/";
  const WINDOW_TYPE = "ie6-add-favorite-window";

  const WIDTH = 440;
  const HEIGHT_COLLAPSED = 144;
  const HEIGHT_EXPANDED = 333;

  const ROOTS = [
    { guid: PlacesUtils.bookmarks.toolbarGuid, label: "Favorites Bar" },
    { guid: PlacesUtils.bookmarks.unfiledGuid, label: "Other Favorites" },
  ];

  const args = window.arguments?.[0] || {};
  const parentWin = window.opener || Services.wm.getMostRecentWindow("navigator:browser");

  let selectedGuid = PlacesUtils.bookmarks.toolbarGuid;
  let selectedRow = null;
  let expanded = false;
  let pickerBuilt = false;
  let childFolderWin = null;

  const $ = (id) => document.getElementById(id);

  function h(tag, className, text) {
    const el = document.createElementNS(HTML_NS, tag);
    if (className) el.className = className;
    if (text != null) el.textContent = text;
    return el;
  }

  function icon(name, className) {
    const img = h("img", className);
    img.src = IMG + name;
    return img;
  }

  function focusExistingInstance() {
    const windows = Services.wm.getEnumerator(WINDOW_TYPE);
    while (windows.hasMoreElements()) {
      const other = windows.getNext();
      if (other === window) continue;
      other.focus();
      window.close();
      return true;
    }
    return false;
  }

  function closeChildFolderWindow() {
    try {
      childFolderWin?.close();
    } catch (e) {}
  }

  function syncColorScheme() {
    if (!parentWin) return;
    try {
      const src = parentWin.document.documentElement;
      const apply = () => {
        const scheme = src.getAttribute("ie6-colorscheme");
        if (scheme) document.documentElement.setAttribute("ie6-colorscheme", scheme);
        else document.documentElement.removeAttribute("ie6-colorscheme");
      };
      apply();

      const observer = new parentWin.MutationObserver(apply);
      observer.observe(src, { attributes: true, attributeFilter: ["ie6-colorscheme"] });
      window.addEventListener("unload", () => observer.disconnect(), { once: true });
    } catch (e) {}
  }

  function closeWithParent() {
    if (!parentWin || parentWin === window) return;

    const closeSelf = () => {
      closeChildFolderWindow();
      window.close();
    };
    parentWin.addEventListener("unload", closeSelf, { once: true });
    window.addEventListener(
      "unload",
      () => {
        try {
          parentWin.removeEventListener("unload", closeSelf);
        } catch (e) {}
        closeChildFolderWindow();
      },
      { once: true }
    );
  }

  const isFolder = (node) =>
    node.typeCode === PlacesUtils.bookmarks.TYPE_FOLDER ||
    node.type === PlacesUtils.TYPE_X_MOZ_PLACE_CONTAINER;

  const subFolders = (node) => (node.children || []).filter(isFolder);

  const containsSelected = (node) =>
    subFolders(node).some((child) => child.guid === selectedGuid || containsSelected(child));

  function selectRow(row, guid) {
    selectedRow?.classList.remove("selected");
    selectedRow = row;
    selectedGuid = guid;
    row.classList.add("selected");
  }

  function appendFolder(container, node, label) {
    const nodeEl = h("div", "af-node");
    const row = h("div", "af-row");
    row.append(icon("favourites-folder.png", "af-icon"), h("span", "af-label", label));
    nodeEl.appendChild(row);

    if (node.guid === selectedGuid) {
      selectedRow = row;
      row.classList.add("selected");
    }
    row.addEventListener("click", (e) => {
      e.stopPropagation();
      selectRow(row, node.guid);
    });

    const children = subFolders(node);
    if (children.length) {
      const toggle = icon("expand.PNG", "af-toggle");
      row.prepend(toggle);

      const childrenEl = h("div", "af-children");
      nodeEl.appendChild(childrenEl);
      for (const child of children) appendFolder(childrenEl, child, child.title || "(unnamed)");

      let open = containsSelected(node);
      const render = () => {
        childrenEl.hidden = !open;
        toggle.src = IMG + (open ? "hide.PNG" : "expand.PNG");
      };
      toggle.addEventListener("click", (e) => {
        e.stopPropagation();
        open = !open;
        render();
      });
      render();
    }

    container.appendChild(nodeEl);
  }

  async function buildFolderPicker() {
    let trees;
    try {
      trees = await Promise.all(ROOTS.map((root) => PlacesUtils.promiseBookmarksTree(root.guid)));
    } catch (e) {
      return;
    }

    selectedRow = null;

    const rootRow = h("div", "af-row");
    rootRow.append(icon("favorites-small.png", "af-icon af-icon-star"), h("span", "af-label", "Favorites"));
    const rootChildren = h("div", "af-children af-root-children");
    const rootNode = h("div", "af-node af-root");
    rootNode.append(rootRow, rootChildren);

    trees.forEach((tree, i) => appendFolder(rootChildren, tree, ROOTS[i].label));

    const container = h("div", "af-tree");
    container.appendChild(rootNode);
    $("folderbox").replaceChildren(container);
    pickerBuilt = true;
  }

  function toggleFolders() {
    expanded = !expanded;
    $("createlabel").hidden = !expanded;
    $("folderbox").hidden = !expanded;
    $("newfolder").hidden = !expanded;
    $("toggle").textContent = expanded ? "Create in <<" : "Create in >>";
    window.resizeTo(WIDTH, expanded ? HEIGHT_EXPANDED : HEIGHT_COLLAPSED);

    if (expanded && !pickerBuilt) buildFolderPicker();
  }

  function createNewFolder() {
    if (childFolderWin && !childFolderWin.closed) {
      childFolderWin.focus();
      return;
    }

    const dialogArgs = {
      value: "",
      confirmed: false,
      parentBrowserWin: Services.wm.getMostRecentWindow("navigator:browser"),
      callback: async (folderName) => {
        if (!folderName) return;
        try {
          const folder = await PlacesUtils.bookmarks.insert({
            type: PlacesUtils.bookmarks.TYPE_FOLDER,
            parentGuid: selectedGuid,
            title: folderName,
          });
          selectedGuid = folder.guid;
          await buildFolderPicker();
        } catch (e) {}
      },
    };

    childFolderWin = window.openDialog(
      "chrome://userscripts/content/create-folder-dialog.xhtml",
      "ie6_create_folder_dialog",
      "chrome,dependent,centerscreen,resizable=no,width=375,height=100",
      dialogArgs
    );
  }

  function savePageOffline(title) {
    try {
      const browser = Services.wm.getMostRecentWindow("navigator:browser").gBrowser.selectedBrowser;

      const dir = Services.dirsvc.get("ProfD", Ci.nsIFile);
      dir.append("Favoritos_Offline");
      if (!dir.exists()) dir.create(Ci.nsIFile.DIRECTORY_TYPE, 0o755);

      const file = dir.clone();
      file.append((title.replace(/[\/\\:*?"<>|]/g, "_") || "pagina_offline") + ".html");

      const persist = Cc["@mozilla.org/embedding/browser/nsWebBrowserPersist;1"].createInstance(
        Ci.nsIWebBrowserPersist
      );
      persist.persistFlags =
        Ci.nsIWebBrowserPersist.PERSIST_FLAGS_REPLACE_EXISTING_FILES |
        Ci.nsIWebBrowserPersist.PERSIST_FLAGS_AUTODETECT_APPLY_CONVERSION;
      persist.saveURI(browser.currentURI, browser.contentPrincipal, null, null, null, null, file, null);

      return Services.io.newFileURI(file).spec;
    } catch (e) {
      return args.url;
    }
  }

  async function confirmAdd() {
    const okBtn = $("ok");
    okBtn.disabled = true; 

    const title = $("name").value.trim();
    const url = $("offline").checked ? savePageOffline(title) : args.url;

    try {
      await PlacesUtils.bookmarks.insert({ parentGuid: selectedGuid, title, url });
    } catch (e) {
      okBtn.disabled = false;
      return;
    }

    args.onCreated?.();
    window.close();
  }

  function init() {
    if (focusExistingInstance()) return;

    syncColorScheme();
    closeWithParent();

    const nameInput = $("name");
    nameInput.value = args.title || args.url || "";
    nameInput.addEventListener("keydown", (e) => {
      if (e.key !== "Enter") return;
      e.preventDefault();
      e.stopPropagation();
      confirmAdd();
    });

    const offline = $("offline");
    offline.addEventListener("change", () => ($("customize").disabled = !offline.checked));

    $("ok").addEventListener("click", confirmAdd);
    $("cancel").addEventListener("click", () => window.close());
    $("toggle").addEventListener("click", toggleFolders);
    $("newfolder").addEventListener("click", createNewFolder);

    window.addEventListener("keydown", (e) => {
      if (e.key !== "Escape") return;
      e.preventDefault();
      e.stopPropagation();
      window.close();
    });

    window.resizeTo(WIDTH, HEIGHT_COLLAPSED);
  }

  if (document.readyState === "loading") window.addEventListener("DOMContentLoaded", init, { once: true });
  else init();
})();