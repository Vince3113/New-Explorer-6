(function () {
  const { classes: Cc, interfaces: Ci } = Components;

  const SCHEMES = ["olive", "silver", "zune", "royalenoir", "royale", "embedded"];
  const POLL_INTERVAL_MS = 2000;

  function readSchemeFromRegistry() {
    let regKey;
    try {
      regKey = Cc["@mozilla.org/windows-registry-key;1"]
        .createInstance(Ci.nsIWindowsRegKey);
      regKey.open(
        Ci.nsIWindowsRegKey.ROOT_KEY_CURRENT_USER,
        "Software\\Microsoft\\Windows\\CurrentVersion\\ThemeManager",
        Ci.nsIWindowsRegKey.ACCESS_READ
      );
      const dllName = regKey.readStringValue("DllName").toLowerCase();
      return SCHEMES.find(name => dllName.includes(`${name}.msstyles`)) ?? "luna";
    } catch (e) {
      return "luna";
    } finally {
      regKey?.close();
    }
  }

  function applyScheme() {
    const scheme = readSchemeFromRegistry();
    const root = document.documentElement;
    if (root.getAttribute("ie6-colorscheme") !== scheme) {
      root.setAttribute("ie6-colorscheme", scheme);
    }
  }

  applyScheme();
  setInterval(applyScheme, POLL_INTERVAL_MS);
})();