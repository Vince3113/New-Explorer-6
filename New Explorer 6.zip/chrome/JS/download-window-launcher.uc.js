(function () {
  if (window.location.href !== "chrome://browser/content/browser.xhtml") return;

  const { Downloads } = ChromeUtils.importESModule(
    "resource://gre/modules/Downloads.sys.mjs"
  );

  const WINDOW_URL = "chrome://userscripts/content/download-window.xhtml";
  const WINDOW_TYPE = "downloads-window";
  const FEATURES = "chrome,titlebar,close,dialog=no,resizable=no,centerscreen";

  let mainWin = null;

  function getMainWindow() {
    try {
      if (mainWin && !mainWin.closed) return mainWin;
    } catch (e) {}
    mainWin = Services.wm.getMostRecentWindow(WINDOW_TYPE);
    return mainWin;
  }

  function present(download) {
    const existing = getMainWindow();
    if (existing) {
      if (download) existing.DownloadsWindow?.showDetail(download);
      else existing.DownloadsWindow?.showList();
      existing.focus();
      return;
    }

    try {
      mainWin = window.openDialog(WINDOW_URL, "", FEATURES, download);
    } catch (e) {
      console.error("download-window launcher: openDialog failed", e);
    }
  }

  function openWindow(download) {
    if (download.__windowOpened) return;
    download.__windowOpened = true;
    present(download);
  }

  function openList() {
    present();
  }

  function silenceQuitPrompt() {
    try {
      const { DownloadUIHelper } = ChromeUtils.importESModule(
        "resource://gre/modules/DownloadUIHelper.sys.mjs"
      );
      const proto = Object.getPrototypeOf(DownloadUIHelper.getPrompter());
      if (proto.__quitPromptSilenced) return;

      const original = proto.confirmCancelDownloads;
      proto.confirmCancelDownloads = function (count, type) {
        if (this.ON_QUIT !== undefined && type === this.ON_QUIT) return false;
        return original.call(this, count, type);
      };
      proto.__quitPromptSilenced = true;
    } catch (e) {
      console.error("download-window launcher: could not silence quit prompt", e);
    }
  }

  async function watchDownloads() {
    try {
      const list = await Downloads.getList(Downloads.PUBLIC);
      const existing = new Set(await list.getAll());
      const handle = (download) => {
        if (!existing.has(download)) openWindow(download);
      };
      await list.addView({
        onDownloadAdded: handle,
        onDownloadChanged: handle,
      });
    } catch (e) {
      console.error("download-window launcher: watch failed", e);
    }
  }

  function clearOpenState(btn) {
    btn.removeAttribute("open");
    btn.removeAttribute("checked");
  }

  function hookMenuItem() {
    const menuItem = document.getElementById("menu_openDownloads");
    if (!menuItem || menuItem.dataset.dlHooked) return;

    menuItem.dataset.dlHooked = "true";
    menuItem.removeAttribute("command");
    menuItem.addEventListener("command", (e) => {
      e.preventDefault();
      e.stopPropagation();
      openList();
    });
  }

  function hookButton() {
    const btn = document.getElementById("downloads-button");
    if (!btn) return;

    btn.addEventListener("command", openList, true);
    btn.addEventListener(
      "click",
      (e) => {
        if (e.button === 0) openList();
      },
      true
    );

    document.getElementById("downloadsPanel")?.addEventListener(
      "popupshowing",
      (e) => {
        e.preventDefault();
        e.stopPropagation();
        clearOpenState(btn);
      },
      true
    );

    new MutationObserver(() => clearOpenState(btn)).observe(btn, {
      attributes: true,
      attributeFilter: ["open", "checked"],
    });
  }

  function init() {
    silenceQuitPrompt();
    hookMenuItem();
    hookButton();
    watchDownloads();
  }

  if (typeof gBrowserInit !== "undefined" && gBrowserInit.delayedStartupFinished) {
    init();
  } else {
    const observer = (subject, topic) => {
      if (subject === window) {
        Services.obs.removeObserver(observer, topic);
        init();
      }
    };
    Services.obs.addObserver(observer, "browser-delayed-startup-finished");
  }

  window.IE6Downloads = { openWindow, openList };
})();