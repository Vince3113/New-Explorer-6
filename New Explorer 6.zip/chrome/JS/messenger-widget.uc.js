(function () {
  const { CustomizableUI } = ChromeUtils.importESModule(
    "moz-src:///browser/components/customizableui/CustomizableUI.sys.mjs"
  );

  const MESSENGER_PATH = "C:\\Program Files (x86)\\Messenger\\msmsgs.exe";
  const EXPLORER_PATH = "C:\\Windows\\explorer.exe";

  function newFile(path) {
    const file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
    file.initWithPath(path);
    return file;
  }

  function launchMessenger() {
    try {
      if (!newFile(MESSENGER_PATH).exists()) return;
      const process = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
      process.init(newFile(EXPLORER_PATH));
      process.run(false, [MESSENGER_PATH], 1);
    } catch (e) {}
  }

  CustomizableUI.createWidget({
    id: "ie6-messenger-button",
    type: "button",
    label: "Messenger",
    tooltiptext: "Messenger",
    onCommand: launchMessenger,
  });
})();