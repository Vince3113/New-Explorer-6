(function () {
  function init() {
    const filePopup = document.getElementById("menu_FilePopup");
    const pageInfo = document.getElementById("menu_pageInfo");
    if (!filePopup || !pageInfo) return;

    const workOffline = document.getElementById("goOfflineMenuitem");
    if (workOffline) {
      filePopup.insertBefore(pageInfo, workOffline);
    } else {
      filePopup.appendChild(pageInfo);
    }
  }

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();