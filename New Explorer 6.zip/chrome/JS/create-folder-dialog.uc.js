(function () {
  const WINDOW_ID = "ie6-create-folder-window";
  if (document.documentElement?.id !== WINDOW_ID) return;

  const args = window.arguments?.[0] || null;
  const parentWin = args?.parentBrowserWin || Services.wm.getMostRecentWindow("navigator:browser");

  const $ = (id) => document.getElementById(id);

  function focusExistingInstance() {
    const windows = Services.wm.getEnumerator(WINDOW_ID);
    while (windows.hasMoreElements()) {
      const other = windows.getNext();
      if (other === window) continue;
      other.focus();
      window.close();
      return true;
    }
    return false;
  }

  function syncColorScheme() {
    if (!parentWin) return;
    try {
      const src = parentWin.document.documentElement;
      const apply = () => {
        const scheme = src.getAttribute("ie6-colorscheme");
        if (scheme) document.documentElement.setAttribute("ie6-colorscheme", scheme);
        else document.documentElement.removeAttribute("ie6-colorscheme");
      };
      apply();

      const observer = new parentWin.MutationObserver(apply);
      observer.observe(src, { attributes: true, attributeFilter: ["ie6-colorscheme"] });
      window.addEventListener("unload", () => observer.disconnect(), { once: true });
    } catch (e) {}
  }

  function closeWithParent() {
    if (!parentWin) return;
    const closeSelf = () => window.close();
    parentWin.addEventListener("unload", closeSelf, { once: true });
    window.addEventListener(
      "unload",
      () => {
        try {
          parentWin.removeEventListener("unload", closeSelf);
        } catch (e) {}
      },
      { once: true }
    );
  }

  function confirmName() {
    const value = $("cf-input").value.trim();
    if (args) {
      args.value = value;
      args.confirmed = true;
      if (typeof args.callback === "function") args.callback(value);
    }
    window.close();
  }

  function cancel() {
    if (args) args.confirmed = false;
    window.close();
  }

  function init() {
    if (focusExistingInstance()) return;

    syncColorScheme();
    closeWithParent();

    const input = $("cf-input");
    setTimeout(() => {
      input.focus();
      input.select();
    }, 50);

    input.addEventListener("keydown", (e) => {
      if (e.key !== "Enter") return;
      e.preventDefault();
      e.stopPropagation();
      confirmName();
    });

    $("cf-ok").addEventListener("click", (e) => {
      e.preventDefault();
      confirmName();
    });
    $("cf-cancel").addEventListener("click", (e) => {
      e.preventDefault();
      cancel();
    });

    window.addEventListener("keydown", (e) => {
      if (e.key !== "Escape") return;
      e.preventDefault();
      cancel();
    });
  }

  window.addEventListener("DOMContentLoaded", init, { once: true });
})();