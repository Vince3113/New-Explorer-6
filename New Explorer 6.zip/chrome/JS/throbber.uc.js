(function () {
  try {
    if (document.getElementById("ie6-throbber")) return;

    const menubar = document.getElementById("toolbar-menubar");
    if (!menubar) return;

    const throbber = document.createXULElement("image");
    throbber.id = "ie6-throbber";
    menubar.appendChild(throbber);

    const updateBusy = () => {
      throbber.toggleAttribute("busy", gBrowser.selectedTab.hasAttribute("busy"));
    };

    updateBusy();

    gBrowser.tabContainer.addEventListener("TabAttrModified", (e) => {
      if (e.target === gBrowser.selectedTab) updateBusy();
    });
    gBrowser.tabContainer.addEventListener("TabSelect", updateBusy);
  } catch (ex) {}
})();