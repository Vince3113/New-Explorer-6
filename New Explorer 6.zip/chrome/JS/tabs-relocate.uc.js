(function () {
  "use strict";

  function moveTabsBelowNavBar() {
    const toolbox = document.getElementById("navigator-toolbox");
    const tabsToolbar = document.getElementById("TabsToolbar");
    const navBar = document.getElementById("nav-bar");
    if (!toolbox || !tabsToolbar || !navBar) return;
    if (tabsToolbar.parentElement === toolbox) return;

    toolbox.insertBefore(tabsToolbar, navBar.nextSibling);
  }

  if (gBrowserInit?.delayedStartupFinished) {
    moveTabsBelowNavBar();
    return;
  }

  const observer = (subject, topic) => {
    if (subject !== window) return;
    Services.obs.removeObserver(observer, topic);
    moveTabsBelowNavBar();
  };
  Services.obs.addObserver(observer, "browser-delayed-startup-finished");
})();