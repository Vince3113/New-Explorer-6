(function () {
  function syncColorScheme() {
    const parentWin = window.opener || Services.wm.getMostRecentWindow("navigator:browser");
    if (!parentWin) return;
    try {
      const srcRoot = parentWin.document.documentElement;
      const dstRoot = document.documentElement;
      const apply = () => {
        const v = srcRoot.getAttribute("ie6-colorscheme");
        if (v) dstRoot.setAttribute("ie6-colorscheme", v);
        else dstRoot.removeAttribute("ie6-colorscheme");
      };
      apply();
      const mo = new parentWin.MutationObserver(apply);
      mo.observe(srcRoot, { attributes: true, attributeFilter: ["ie6-colorscheme"] });
      window.addEventListener("unload", () => { try { mo.disconnect(); } catch (e) {} }, { once: true });
    } catch (e) {}
  }

  syncColorScheme();

  const HTML_NS = "http://www.w3.org/1999/xhtml";
  const BASE = "resource://ie6theme/images/index/";
  const ICON = {
    topic: BASE + "category.png",
    bookClosed: BASE + "catalog.png",
    bookOpen: BASE + "catalog-open.png",
  };
  const HOME_ID = "getting-started-with-internet-explorer";
  const ITEM = ".hh-search-item";
  const PANELS = ["contents", "index", "search", "favorites"];
  const FAVORITES_PREF = "ie6theme.hhviewer.favorites";

  const TREE = [
    { label: "Getting started with Internet Explorer" },
    {
      label: "Finding the Web Pages You Want",
      children: [
        { label: "Finding the information you want on the Web" },
        { label: "Listing your favorite pages for quick viewing" },
        { label: "Changing your home page" },
        { label: "Sharing bookmarks and favorites" },
        { label: "Finding pages you've recently visited" },
        { label: "Entering Web information more easily" },
      ],
    },
    {
      label: "Browsing the Web Offline",
      children: [
        { label: "Making Web pages available offline" },
        { label: "Viewing Web pages without being connected" },
      ],
    },
    {
      label: "Printing and Saving Information",
      children: [
        { label: "Printing a Web page" },
        { label: "Saving a Web page on your computer" },
        { label: "Saving text from a Web page" },
        { label: "Saving a picture from a Web page" },
        { label: "Printing a picture from a Web page" },
      ],
    },
    {
      label: "Sending Information over the Internet Safely",
      children: [
        { label: "Understanding security and privacy features" },
        { label: "Using secure Internet sites for transactions" },
        { label: "Protecting your identity over the Internet" },
        { label: "Securely sharing personal information" },
        { label: "What you need to know about cookies" },
      ],
    },
    {
      label: "Understanding Security and Privacy on the Web",
      children: [
        { label: "Understanding security and privacy features" },
        { label: "Protecting your computer from unsafe software" },
      ],
    },
    {
      label: "Controlling Access to Inappropriate Internet Content",
      children: [
        {
          label: "Content Advisor",
          children: [
            { label: "Using Content Advisor to control access" },
            { label: "Turning on Content Advisor and setting limits" },
            { label: "Allowing others to view restricted content" },
            { label: "Specifying Web sites that others can always see" },
          ],
        },
      ],
    },
    {
      label: "Customizing Your Web Browser",
      children: [
        { label: "Tips for Netscape users" },
        { label: "Changing the appearance of the Windows toolbar" },
        { label: "Changing Web page fonts and background colors" },
        { label: "Correctly displaying Web pages encoding" },
        { label: "Turning off graphics to display all Web pages faster" },
        { label: "Creating more space for temporary Internet pages" },
      ],
    },
    {
      label: "Accessibility",
      children: [
        { label: "Accessibility for people with disabilities" },
        { label: "Using accessibility features in Internet Explorer" },
        { label: "Specifying fonts and colors to always use for Web pages" },
        { label: "Using Internet Explorer keyboard shortcuts" },
      ],
    },
  ];
  const DOCS = {
    "finding-the-information-you-want-on-the-web": {
      title: "Finding the information you want on the Internet",
      blocks: [
        { p: "You can find information on the Web in a variety of ways:" },
        {
          bullets: [
            "Click the **Search** button on the toolbar to gain access to a number of search providers. Type a word or phrase in the **Search** box.",
            "Type **go**, **find**, or **?** followed by a word or phrase in the Address bar. Internet Explorer starts a search using its predetermined search provider.",
            "After you go to a Web page, you can search for specific text on that page by clicking the **Edit** menu, and then clicking **Find (on this page)**.",
          ],
        },
        {
          note: [
            "If a Web address doesn't work, Internet Explorer asks if you want to search for similar Web addresses. You can change this setting so that Internet Explorer searches automatically without prompting. For more information, click **Related Topics**.",
          ],
        },
        { related: "Related Topics" },
      ],
    },
    "listing-your-favorite-pages-for-quick-viewing": {
      title: "Listing your favorite pages for quick viewing",
      blocks: [
        { p: "When you find Web sites or pages that you like, you can keep track of them, so it's easy to open them in the future." },
        {
          bullets: [
            { text: "Add a Web page to your list of favorite pages. Any time you want to open that page, just click the **Favorites** button on the toolbar, and then click the shortcut in the Favorites list.", link: "Add a page to your list of favorite pages" },
            { text: "If you have a handful of sites or pages that you visit often, add them to your Links bar.", link: "Add a page to your Links bar" },
            { text: "If there is one page you visit most, you can make it your home page so that it appears every time you start Internet Explorer or click the **Home** button on the toolbar.", link: "Change your home page" },
          ],
        },
        {
          note: [
            "If you forget to add Web pages to your Favorites or Links bar, click the **History** button on the toolbar. The History list shows where you've been—today, yesterday, or a few weeks ago. Click a name from the list to display the page.",
          ],
        },
      ],
    },
    "changing-your-home-page": {
      title: "To change your home page",
      blocks: [
        { p: "Your home page is the page that appears every time you open Internet Explorer. Choose a page that you want to view frequently, or one that you can customize to get quick access to all the information you want, such as the [[msn.com]] home page." },
        {
          steps: [
            "Go to the page you want to appear when you start Internet Explorer.",
            "On the **Tools** menu, click **Internet Options**.",
            "Click the **General** tab.",
            "Under **Home page**, click **Use Current**.",
          ],
        },
        { note: ["To restore your original home page, click **Use Default**."] },
        { related: "Related Topics" },
      ],
    },
    "sharing-bookmarks-and-favorites": {
      title: "Sharing bookmarks and favorites",
      blocks: [
        { p: "Favorites, known as bookmarks in Netscape Navigator, are a convenient way to organize and link to Web pages that you visit frequently." },
        { p: "Internet Explorer automatically imports all your Netscape bookmarks. On the **Favorites** menu, click the **Imported Bookmarks** folder to view them." },
        { p: "If you use Internet Explorer on several computers, you can easily share favorite items among computers by importing them. Also, if you use both Internet Explorer and Netscape Navigator, you can keep your favorites and bookmarks up-to-date with each other by importing them between programs." },
        {
          bullets: [
            "To import bookmarks or favorites, on the **File** menu, click **Import and Export**.",
            "To export favorites to bookmarks or favorites on the same or another computer, on the **File** menu, click **Import and Export**.",
          ],
        },
        {
          label: "Notes",
          note: [
            "Exported favorites are saved as regular HTML files, so either Internet Explorer or Netscape Navigator can import them. You can export a selected folder in your Favorites list, or all of your favorites.",
            "The exported favorites file is fairly small, so if you want to share the favorite items with other people, you can copy it to a floppy disk or folder on a network, or attach it to an e-mail message.",
          ],
        },
      ],
    },
    "finding-pages-you-ve-recently-visited": {
      title: "Finding pages you've recently visited",
      blocks: [
        { p: "There are several ways to find Web sites and pages you've viewed in the last few days, hours, or minutes." },
        { sub: "To find a page you've seen in the last few days" },
        {
          steps: [
            { text: "On the toolbar, click the **History** button.", extra: ["The History bar appears, containing links for Web sites and pages visited in previous days and weeks."] },
            { text: "In the History bar, click a week or day, click a Web site folder to display individual pages, and then click the page icon to display the Web page.", extra: ["To sort or search the History bar, click the arrow next to the **View** button at the top of the History bar."] },
          ],
        },
        { sub: "To find a page that you just visited" },
        {
          bullets: [
            "To return to the last page you viewed, click the **Back** button on the toolbar.",
            "To view one of the last nine pages you visited in this session, click the arrow to the side of the **Back** or **Forward** button, and then click the page you want from the list.",
          ],
        },
        {
          label: "Notes",
          note: [
            "You can hide the History bar by clicking the **History** button again.",
            "You can change the number of days that pages are saved in the History list. The more days you specify, the more disk space is used on your computer to save that information.",
          ],
        },
        { related: "Related Topics" },
      ],
    },
    "entering-web-information-more-easily": {
      title: "To enter Web information more easily",
      blocks: [
        { p: "The AutoComplete feature saves previous entries you've made for Web addresses, forms, and passwords. Then, when you type information in one of these fields, AutoComplete suggests possible matches. These matches can include folder and program names you type into the Address bar, and search queries, stock quotes, or information for just about any other field you fill in on a Web page." },
        {
          steps: [
            { text: "In the Address bar, a field on a Web page, or a box for a user name or password, start typing the information.", extra: ["If you've typed a similar entry before, AutoComplete lists possible matches as you type."] },
            { text: "If a suggestion in the list matches what you want to enter in that field, click the suggestion.", extra: ["If no suggestion matches what you are typing, continue typing."] },
          ],
        },
        {
          label: "Notes",
          note: [
            "The information used for suggested matches is stored on your computer and is encrypted to protect your privacy.",
            "Web sites cannot gain access to this information. They can receive only what you explicitly enter in forms.",
            "When typing information in Web forms, and typing passwords, you can remove an item from the list of suggestions by clicking the item and then pressing the DELETE key. To learn how to delete entries from the Address bar list, click **Related Topics** below.",
          ],
        },
        { related: "Related Topics" },
      ],
    },
    "making-web-pages-available-offline": {
      title: "Making pages available for offline viewing",
      blocks: [
        { p: "When you make a Web page available offline, you can read its content when your computer is not connected to the Internet. For example, you can view Web pages on your laptop computer when you don't have a network or Internet connection. Or you can read Web pages at home without tying up a phone line." },
        { p: "You can specify how much content you want available, such as just a page, or a page and all its links, and choose how you want to update that content on your computer." },
        { p: "If you just want to view a Web page offline, and you don't need to update the content, you can save the page on your computer. There are several ways you can save the Web page, from just saving the text to saving all of the images and text needed to display that page as it appears on the Web." },
        { h: "What would you like to do?" },
        {
          bullets: [
            { text: "Make the current Web page available offline.", link: "Make the current Web page available offline" },
            { text: "Make an existing favorite item available offline.", link: "Make an existing favorite item available offline" },
            { text: "Save a Web page on your computer.", link: "Save a Web page on your computer" }
          ]
        },
        {
          label: "Notes",
          note: [
            "In previous versions of Internet Explorer, offline viewing was referred to as 'subscribing'.",
            "If you used channels in a previous version of Internet Explorer, you can find them in the Channels folder in your Favorites list.",
          ],
        },
      ],
    },
    "viewing-web-pages-without-being-connected": {
      title: "To view Web pages without being connected to the Internet",
      blocks: [
        { p: "After you mark your favorite pages for viewing offline, you can view them offline by following these steps:" },
        {
          steps: [
            "Before you disconnect from the Internet, on the **Tools** menu, click **Synchronize**.",
            "When you're ready to work offline, on the **File** menu, click **Work Offline**.",
            "In your Favorites list, click the item you want to view.",
          ],
        },
        {
          label: "Note",
          note: ["When you choose to work offline, Internet Explorer will always start in Offline mode until you click **Work Offline** again to clear the check mark."],
        },
        { related: "Related Topics" },
      ],
    },
    "printing-a-web-page": {
      title: "To print a Web page",
      blocks: [
        {
          steps: [
            "On the **File** menu, click **Print**.",
            "Set the printing options you want.",
          ],
        },
        {
          label: "Notes",
          note: [
            "To print a frame or item on a Web page, right-click the frame or item, and then click **Print**.",
            "You can preview how a Web page will look and see how many printed pages it will be by clicking the **File** menu and then clicking **Print Preview**.",
            "For Help on an item, click the question mark icon at the top of the dialog box, and then click the item.",
          ],
        },
        { related: "Related Topics" },
      ],
    },
    "saving-a-web-page-on-your-computer": {
      title: "To save a Web page on your computer",
      blocks: [
        {
          steps: [
            "On the **File** menu, click **Save As**.",
            "Double-click the folder you want to save the page in.",
            "In the **File name** box, type a name for the page.",
            "In the **Save as type** box, select a file type.",
            {
              text: "Do one of the following:",
              extra: [
                "• To save all files needed to display the page, including graphics, frames, and style sheets, select **Web Page, complete**. This option saves each file in its original format.",
                "• To save all required information in a single MIME-encoded file, select **Web Archive**. This creates a snapshot of the current Web page (requires Outlook Express 5 or later).",
                "• To save only the HTML page, select **Web Page, HTML only**. This saves page text and structure without images or extra files.",
                "• To save only the unformatted text, select **Text Only**."
              ]
            }
          ]
        },
        {
          label: "Notes",
          note: [
            "With **Web Page, complete** and **Web Archive**, you can view the Web page offline without adding it to your Favorites list or marking it for offline viewing.",
            "When you choose **Web Page, complete**, only the current page is saved. To view linked pages offline, click **Related Topics** below."
          ]
        },
        { related: "Related Topics" }
      ]
    },
    "saving-a-picture-from-a-web-page": {
      title: "To save an image from a Web page",
      blocks: [
        {
          steps: [
            { text: "In Internet Explorer, point to the image you want to save.", extra: ["The image toolbar appears over the corner of the image."] },
            "Click {{save.png}}.",
          ],
        },
        {
          label: "Notes",
          note: [
            "The image toolbar does not display for all images. The image must be at least 200 x 200 pixels to use the image toolbar. To save a smaller image, right-click anywhere on the image, and then click save.",
            "Images are saved in the My Pictures folder unless you specify a different location. To open the My Pictures folder, click {{picture.png}}.",
          ],
        },
        { related: "Related Topics" },
      ],
    },
    "printing-a-picture-from-a-web-page": {
      title: "To print an image from a Web page",
      blocks: [
        {
          steps: [
            { text: "In Internet Explorer, point to the image you want to print.", extra: ["The image toolbar appears over the corner of the image."] },
            "Click {{print.png}}.",
          ],
        },
        {
          label: "Note",
          note: ["The image toolbar does not appear for all images. The image must be at least 200 x 200 pixels to use the image toolbar."],
        },
        { related: "Related Topics" },
      ],
    },
    "saving-text-from-a-web-page": {
      title: "Saving pictures or text from a Web page",
      blocks: [
        { p: "As you view pages on the Web, you'll find information that you'd like to save for future reference or share with other people. You can save the entire Web page or any part of it: text, graphics, or links. You can print Web pages for people who don't have access to the Web or a computer." },
        { p: "{{info.png}}" },
        { related: "Related Topics" },
      ],
    },
    "understanding-security-and-privacy-features": {
      title: "Understanding security and privacy features",
      blocks: [
        { p: "Internet Explorer provides a number of features that help to protect your privacy and make your computer and your personally identifiable information more secure." },
        { p: "Privacy features allow you to protect your personally identifiable information by helping you to understand how Web sites you view may be using this information and by allowing you to specify privacy settings that determine whether or not you want to allow Web sites to save cookies on your computer." },
        { p: "Privacy features in Internet Explorer include:" },
        {
          bullets: [
            "Privacy settings that specify how your computer deals with cookies. Cookies are files created by a Web site that store information on your computer, such as your preferences when visiting that site. Cookies may also store personally identifiable information, such as your name or e-mail address.",
            "Privacy alerts that let you know when you try to gain access to a site that doesn't meet the criteria in your privacy settings.",
            "The ability to view a Web site's P3P privacy policy.",
          ],
        },
        { p: "Security features help to prevent people from gaining access to information that you have not given them permission to access, such as credit card information you enter when shopping on the Internet. Security features can also protect your computer from unsafe software." },
        { p: "Security features in Internet Explorer include:" },
        {
          bullets: [
            "Certificates, which verify the identity of a person or the security of a Web site.",
            "128-bit secure connection for using secure Web sites.",
            "Microsoft Authenticode technology, which verifies the identity of programs you download.",
          ],
        },
        { p: "For more information on the security and privacy features in Internet Explorer, click **Related Topics**." },
        { related: "Related Topics" },
      ],
    },
    "using-secure-internet-sites-for-transactions": {
      title: "Using secure Internet sites for transactions",
      blocks: [
        { p: "Many Internet sites are set up to prevent unauthorized people from seeing the information that is sent to or from those sites. These are called secure sites. Because Internet Explorer supports the security protocols used by secure sites, you can send information to a secure site with safety and confidence. (A protocol is a set of rules and standards that enable computers to exchange information.)" },
        { p: "When you visit a secure Web site, it automatically sends you its certificate, and Internet Explorer displays a lock icon on the status bar. (A certificate is a statement verifying the identity of a person or the security of a Web site. For more information, click **Related Topics** below.)" },
        { p: "If you are about to send information (such as your credit card number) to an insecure site, Internet Explorer can warn you that the site is not secure. If the site claims to be secure but its security credentials are suspect, Internet Explorer can warn you that the site might have been tampered with or might be misrepresenting itself." },
        { related: "Related Topics" },
      ],
    },
    "tips-for-netscape-users": {
      title: "Tips for Netscape users",
      blocks: [
        { p: "Whether you are switching from Netscape Navigator or just want to use more than one browser, it's easy to learn and use Internet Explorer. From keyboard shortcuts to bookmarks, you can make the transition simple and fast." },
        {
          bullets: [
            { text: "Keep unique and separate settings for Internet Explorer and Netscape Navigator. If you installed another Web browser after installing Internet Explorer and Internet Tools, some of your Internet Explorer settings may have changed. For more information, click:", link: "Resetting Internet Explorer settings" },
            { text: "Compare terms in Navigator and Internet Explorer. If you've used Navigator in the past, you may find that words for common actions or features are different in Internet Explorer. For more information, click:", link: "Browser terms in Navigator and Internet Explorer" },
            { text: "Keep all of your bookmarks as favorites. Internet Explorer automatically imports all of your bookmarks (without altering your bookmarks as they are displayed in Navigator) as Internet Explorer favorites. For more information, click:", link: "Sharing bookmarks and favorites" },
            { text: "Use your favorite keyboard shortcuts. Internet Explorer and Navigator share many of the same keyboard shortcuts. In addition, Internet Explorer is fully accessible using the keyboard, so you can park your mouse if you want to. For more information, click:", link: "Internet Explorer keyboard shortcuts" },
            "Customize how Internet Explorer looks, how you connect, your security settings, and many other options. These settings and more are available by clicking the **Tools** menu and then clicking **Internet Options**.",
          ],
        },
      ],
    },
    "changing-the-appearance-of-the-windows-toolbar": {
      blocks: [
        { h: "To change the appearance of the Windows toolbar" },
        {
          bullets: [
            "You can add or remove standard toolbar buttons, use smaller toolbar buttons like the ones used in Microsoft Office, and change the order they are displayed on the toolbar. Just right-click the toolbar, and then click **Customize**.",
            "You can move or resize the Address bar and Links bar by dragging them up, down, left, or right. You can even move them into the menu bar!",
            "You can hide the Address bar or Links bar by right-clicking the toolbar, and then clearing the check mark for each item you want to hide.",
            "You can add items to the Links bar by dragging the icon from the Address bar or dragging a link from a Web page.",
            "You can rearrange items on the Links bar by dragging them to a new location on the bar.",
          ],
        },
      ],
    },
    "changing-web-page-fonts-and-background-colors": {
      title: "Changing Web page fonts and background colors",
      blocks: [
        { p: "When Web authors and designers create Web pages, they often specify particular type (font) faces, colors, sizes, and background colors. These settings are specified for each item, or in a \"style sheet,\" which is a type of template for specifying how different styles should appear throughout a Web page or site." },
        { p: "You can override any or all of these settings, which is useful if you have limited or low vision. You can specify your font and color preferences for all pages that do not use style sheets, and then you can specify whether to use any or all of your preferences on pages that use style sheets." },
        { p: "For more information, click **Related Topics** below." },
        { related: "Related Topics" },
      ],
    },
    "correctly-displaying-web-pages-encoding": {
      blocks: [
        { h: "To correctly display Web pages encoded in any language" },
        { p: "Most Web pages contain information that tells the browser what language encoding (the language and character set) to use." },
        { p: "If the page does not include that information, and you have the Language Encoding Auto-Select feature on, Internet Explorer can usually determine the appropriate language encoding." },
        { sub: "To turn Auto-Select on" },
        {
          bullets: [
            { text: "On the **View** menu in Internet Explorer, point to **Encoding**, and then make sure **Auto-Select** has a check mark. If it doesn't, select it.", extra: ["If you are prompted to download language support components, click **Download**."] },
          ],
        },
        { p: "If Auto-Select cannot determine the correct language encoding, and you know what language encoding it should be, you can manually select it." },
        { sub: "To select the language encoding for a Web page" },
        {
          bullets: [
            { text: "On the **View** menu, point to **Encoding**, point to **More**, and then click the appropriate language.", extra: ["If you are prompted to download language support components, click **Download**."] },
          ],
        },
        {
          label: "Notes",
          note: [
            "If the Auto-Select feature or a specific language pack is not installed on your computer, Internet Explorer prompts you to download the files as needed.",
            "Adding languages does not guarantee that your computer has a font that can display Web pages in your preferred languages. To be prompted when fonts need to be added, on the **Tools** menu, click **Internet Options**, click the **Advanced** tab, and then select the **Enable Install On Demand** check box. Or you can download a [[Multilanguage support pack]] to display pages in this language.",
            "You can add a **Language Encoding** button to your toolbar to make switching between languages quicker.",
          ],
        },
        { related: "Related Topics" },
      ],
    },
    "turning-off-graphics-to-display-all-web-pages-faster": {
      blocks: [
        { h: "To turn off graphics to display all Web pages faster" },
        {
          steps: [
            "On the **Tools** menu in Internet Explorer, click **Internet Options**.",
            "Click the **Advanced** tab.",
            "Under **Multimedia**, clear one or more of the **Show pictures**, **Play animations**, **Play videos**, or **Play sounds** check boxes.",
          ],
        },
        {
          label: "Notes",
          note: [
            "If the **Show pictures** or **Play videos** check box is cleared, you can still display an individual picture or animation on a Web page by right-clicking its icon, and then clicking **Show Picture**.",
            "If the pictures on the current page are still visible after you clear the **Show pictures** check box, you can hide them by clicking the **View** menu, and then clicking **Refresh**.",
          ],
        },
      ],
    },
    "creating-more-space-for-temporary-internet-pages": {
      blocks: [
        { h: "To create more space for temporary Internet pages" },
        {
          steps: [
            "In Internet Explorer, on the **Tools** menu, click **Internet Options**.",
            "On the **General** tab, click **Settings**.",
            "To create more space to store pages temporarily, move the slider to the right.",
          ],
        },
        { related: "Related Topics" },
      ],
    },
    "accessibility-for-people-with-disabilities": {
      title: "Accessibility for people with disabilities",
      blocks: [
        { p: "Microsoft is committed to making its products and services easier for everyone to use. The following articles provide information on features, products, and services that make Microsoft Windows operating systems more accessible for people with disabilities:" },
        { p: "[[Customizing Windows for people with disabilities]]" },
        { p: "[[Microsoft services for people who are deaf or hard-of-hearing]]" },
        { p: "[[Microsoft documentation in alternative formats]]" },
        { p: "[[Utilities to enhance accessibility]]" },
        { p: "[[Getting more accessibility information]]" },
        {
          note: ["This information applies only if you acquired this Microsoft product in the United States. If you obtained this product outside the United States, your package contains a subsidiary information card, Help file, or other documentation listing Microsoft support services, telephone numbers, and addresses. You can contact your subsidiary to find out whether the type of products and services described in these Help topics are available in your area."],
        },
      ],
    },
    "using-accessibility-features-in-internet-explorer": {
      title: "Using accessibility features in Internet Explorer",
      blocks: [
        { p: "In addition to Microsoft Windows accessibility products and services, the following features make Internet Explorer more accessible for people with disabilities." },
        { p: "Click a heading, or press the TAB key to highlight a heading, and then press ENTER." },
        {
          toggles: [
            { title: "Keyboard access" },
            { title: "Highlighting box" },
            { title: "Customize the font size, formatting, colors" },
            { title: "Customize the toolbar" },
            { title: "Use AutoComplete" },
            { title: "Advanced options that make Internet Explorer more accessible" },
          ],
        },
      ],
    },
    "specifying-fonts-and-colors-to-always-use-for-web-pages": {
      blocks: [
        { h: "To specify fonts and colors to always use for Web pages" },
        {
          steps: [
            "On the **Tools** menu in Internet Explorer, click **Internet Options**.",
            "On the **General** tab, click **Accessibility**.",
            "Change the settings as needed.",
          ],
        },
        {
          label: "Note",
          note: ["For Help on an item, click {{question.png}} at the top of the dialog box, and then click the item."],
        },
        { related: "Related Topics" },
      ],
    },
    "using-internet-explorer-keyboard-shortcuts": {
      title: "Internet Explorer keyboard shortcuts",
      blocks: [
        { p: "You can use shortcut keys to view and explore Web pages, preview pages before printing, use the Address bar, work with favorites, and edit." },
        { p: "Click a heading, or press the TAB key to highlight a heading, and then press ENTER." },
        {
          toggles: [
            { title: "Viewing and exploring Web pages" },
            { title: "Using Print Preview" },
            { title: "Using the Address bar" },
            { title: "Working with favorites" },
            { title: "Editing" },
          ],
        },
      ],
    },
    "using-content-advisor-to-control-access": {
      title: "Using Content Advisor to control access",
      blocks: [
        { p: "The Internet provides unprecedented access to a wide variety of information. Some information, however, may not be suitable for every viewer. For example, you might want to prevent your children from seeing Web sites that contain violent or sexual content." },
        { p: "Content Advisor provides a way to help you control the types of content that your computer can gain access to on the Internet. After you turn on Content Advisor, only rated content that meets or exceeds your criteria can be viewed. You can adjust the settings." },
        { p: "With Content Advisor, you can:" },
        {
          bullets: [
            "Control access to Content Advisor settings. You turn Content Advisor on, and view the settings, through the use of a password. You will need this password to change any Content Advisor settings, so you might want to write it down for future reference.",
            "View and adjust the ratings settings to reflect what you think is appropriate content in each of four areas: language, nudity, sex, and violence.",
            "Adjust what types of content other people can view, with or without your permission. You can override content settings on a case-by-case basis.",
            "Set up a list of Web sites that other people can never view, regardless of how the sites' contents are rated.",
            "Set up a list of Web sites that other people can always view, regardless of how the sites' contents are rated.",
            "View and change the ratings systems and bureaus you use.",
          ],
        },
        { p: "Content Advisor is set to the most conservative (least likely to offend) settings when you first turn it on. You can adjust these settings to match your own preferences." },
        { p: "Not all Internet content is rated. If you choose to allow other people to view unrated sites on your computer, some of those sites could contain inappropriate material." },
        { related: "Related Topics" },
      ],
    },
    "turning-on-content-advisor-and-setting-limits": {
      blocks: [
        { h: "To turn on Content Advisor and set limits" },
        {
          steps: [
            "In Control Panel, open {{controlpanel.png}} [[Internet Options]].",
            { text: "On the **Content** tab, Under **Content Advisor**, click **Enable**.", extra: ["If you've already turned on Content Advisor, click **Settings**, and then type the supervisor password."] },
            "Click a category in the list, and then move the slider to set the limits you want to use.",
            "Repeat this process for each category you want to limit, and then click **OK**.",
            "If a supervisor password has not already been set up for your computer, you are prompted to create one.",
          ],
        },
        {
          label: "Notes",
          note: [
            "You can also open Internet Options by clicking the **Tools** menu in Internet Explorer, and then clicking **Internet Options**.",
            "You might want to write down your supervisor password. You will need to type it any time you change the Content Advisor settings.",
            "To prevent others from visiting objectionable Web sites that don't use ratings labels, click the **Approved Sites** tab, and change the settings as appropriate.",
          ],
        },
        { related: "Related Topics" },
      ],
    },
    "allowing-others-to-view-restricted-content": {
      blocks: [
        { h: "To allow others to view restricted or unrated content" },
        {
          steps: [
            "In Control Panel, open {{controlpanel.png}} [[Internet Options]].",
            { text: "On the **Content** tab, under **Content Advisor**, click **Enable**.", extra: ["If you've already enabled Content Advisor, click **Settings**, and then type the supervisor password."] },
            { text: "To allow others to view restricted content, click the **General** tab, and then select the following check box: **Supervisor can type a password to allow users to view restricted content**.", extra: ["To allow others to view unrated content, select the following check box: **Users can see sites that have no rating**."] },
            "Click **OK**.",
            "If a supervisor password has not already been set up for your computer, you are prompted to create one.",
          ],
        },
        {
          label: "Note",
          note: ["You can also open Internet Options by clicking the **Tools** menu in Internet Explorer, and then clicking **Internet Options**."],
        },
        { related: "Related Topics" },
      ],
    },
    "specifying-web-sites-that-others-can-always-see": {
      blocks: [
        { h: "To specify Web sites that others can always or never see" },
        {
          steps: [
            "In Control Panel, open {{controlpanel.png}} [[Internet Options]].",
            { text: "On the **Content** tab, under **Content Advisor**, click **Enable**.", extra: ["If you've already enabled Content Advisor, click **Settings**, and then type the supervisor password."] },
            { text: "Click the **Approved Sites** tab, type the Internet address (URL) of a Web site, and then choose whether you want others to always or never have access to this site.", extra: ["Repeat this process for each Web site that you want to set access for."] },
          ],
        },
        {
          label: "Note",
          note: ["You can also open Internet Options by clicking the **Tools** menu in Internet Explorer, and then clicking **Internet Options**."],
        },
        { related: "Related Topics" },
      ],
    },
    "protecting-your-identity-over-the-internet": {
      title: "Using certificates for privacy and security",
      blocks: [
        { p: "You can use certificates to protect your personally identifiable information on the Internet, and to protect your computer from unsafe software. A certificate is a statement verifying the identity of a person or the security of a Web site." },
        { p: "Internet Explorer uses two different types of certificates:" },
        {
          bullets: [
            "A \"personal certificate\" is a verification that you are who you say you are. This information is used when you send personal information over the Internet to a Web site that requires a certificate verifying your identity. You can control the use of your own identity by having a private key that only you know on your own computer. When used with e-mail programs, security certificates with private keys are also known as \"digital IDs.\"",
            "A \"Web site certificate\" states that a specific Web site is secure and genuine. It ensures that no other Web site can assume the identity of the original secure site. When you are sending personal information over the Internet, it is a good idea to check the certificate of the Web site you are using to ensure that it will protect your personally identifiable information. When you are downloading software from a Web site, you can use certificates to verify that the software is coming from a known, reliable source.",
          ],
        },
        { h: "How do security certificates work?" },
        { p: "A security certificate, whether it is a personal certificate or a Web site certificate, associates an identity with a \"public key.\" Only the owner of the certificate knows the corresponding \"private key.\" The \"private key\" allows the owner to make a \"digital signature\" or decrypt information encrypted with the corresponding \"public key.\" When you send your certificate to other people, you are actually giving them your public key, so they can send you encrypted information that only you can decrypt and read with your private key." },
        { p: "The digital signature component of a security certificate is your electronic identity card. The digital signature tells the recipient that the information actually came from you and has not been forged or tampered with." },
        { p: "Before you can start sending encrypted or digitally signed information, you must obtain a certificate and set up Internet Explorer to use it. When you visit a secure Web site (one whose address starts with \"https\"), the site automatically sends you its certificate." },
        { h: "Where do you get your own security certificates?" },
        { p: "Security certificates are issued by independent certification authorities. There are different classes of security certificates, each one providing a different level of credibility. You can [[obtain your personal security certificate]] from certification authorities." },
        { related: "Related Topics" },
      ],
    },
    "securely-sharing-personal-information": {
      title: "Securely sharing personal information",
      blocks: [
        { p: "Profile Assistant can save you from having to enter the same information, such as your address or e-mail name, every time you visit a new Web site that requests such information. It does this by storing the information on your computer. None of this information can be viewed on your computer, or shared with others, without your permission." },
        { p: "When a Web site requests information from Profile Assistant, the request will tell you:" },
        {
          bullets: [
            "The Internet address of the site requesting the information.",
            "What information the site is requesting from Profile Assistant, so you can choose to exclude information.",
            "How this information will be used.",
            "Whether this site has a secure connection (Secure Sockets Layer or SSL). If it does, you can verify the site's certificate.",
          ],
        },
        { p: "You can encrypt your personal information when it is transmitted and as it is stored on your computer. For more information, click **Related Topics**." },
        { related: "Related Topics" },
      ],
    },
    "what-you-need-to-know-about-cookies": {
      title: "Understanding cookies",
      blocks: [
        { p: "Some Web sites store information in a small text file on your computer. This file is called a cookie." },
        { p: "There are several types of cookies, and you can choose whether to allow some, none, or all of them to be saved on your computer. If you do not allow cookies at all, you may not be able to view some Web sites or take advantage of customization features (such as local news and weather, or stock quotes)." },
        { p: "Click a heading, or press the TAB key to highlight a heading, and then press ENTER." },
        {
          toggles: [
            { title: "How cookies are used" },
            { title: "Persistent cookies" },
            { title: "Temporary cookies" },
            { title: "First-Party vs. Third-Party cookies" },
            { title: "Unsatisfactory cookies" },
            { title: "Your choices in working with cookies" },
          ],
        },
        { related: "Related Topics" },
      ],
    },
    "protecting-your-computer-from-unsafe-software": {
      title: "Protecting your computer from unsafe software",
      blocks: [
        { p: "When you download or run programs from the Internet, you want to know that the program comes from a known, reliable source. That's why, when you choose to download a program from the Internet to your computer, Internet Explorer uses Microsoft Authenticode technology to verify the identity of the program. Authenticode technology verifies that the program has a valid certificate: that the identity of the software publisher matches the certificate, and that the certificate is still valid. Note that this does not prevent a poorly written program from being downloaded or run on your computer, but it does reduce the chance of someone misrepresenting a program that is intended to be malicious or intentionally harmful." },
        { p: "You can specify different settings for the way Internet Explorer handles downloading programs and files, depending on the zone they are coming from." },
        { p: "For example, you might be confident that anything you download within your corporate intranet is safe. So, you might set your security settings for your Local intranet zone to a low level to allow downloading with little or no prompting. If the source is in the Internet zone or the Restricted sites zone, you might want your security levels set to Medium or High. Then, you'd be prompted with information about the program's certificate before it is downloaded, or you might not be able to download it at all." },
        { related: "Related Topics" },
      ],
    },
  };
  const T = {
    START: HOME_ID,
    FIND: "finding-the-information-you-want-on-the-web",
    FAV: "listing-your-favorite-pages-for-quick-viewing",
    HOME: "changing-your-home-page",
    SHARE: "sharing-bookmarks-and-favorites",
    HIST: "finding-pages-you-ve-recently-visited",
    AUTO: "entering-web-information-more-easily",
    OFFLINE: "making-web-pages-available-offline",
    VIEWOFF: "viewing-web-pages-without-being-connected",
    PRINT: "printing-a-web-page",
    SAVE: "saving-a-web-page-on-your-computer",
    SAVEIMG: "saving-a-picture-from-a-web-page",
    PRINTIMG: "printing-a-picture-from-a-web-page",
    SAVETXT: "saving-text-from-a-web-page",
    SEC: "understanding-security-and-privacy-features",
    SECSITES: "using-secure-internet-sites-for-transactions",
    IDENT: "protecting-your-identity-over-the-internet",
    SHAREINFO: "securely-sharing-personal-information",
    COOKIES: "what-you-need-to-know-about-cookies",
    UNSAFE: "protecting-your-computer-from-unsafe-software",
    CADV: "using-content-advisor-to-control-access",
    CADVON: "turning-on-content-advisor-and-setting-limits",
    CADVALLOW: "allowing-others-to-view-restricted-content",
    CADVSITES: "specifying-web-sites-that-others-can-always-see",
    NETSCAPE: "tips-for-netscape-users",
    TOOLBAR: "changing-the-appearance-of-the-windows-toolbar",
    FONTS: "changing-web-page-fonts-and-background-colors",
    ENCODING: "correctly-displaying-web-pages-encoding",
    GRAPHICS: "turning-off-graphics-to-display-all-web-pages-faster",
    TEMPFILES: "creating-more-space-for-temporary-internet-pages",
    ACCDIS: "accessibility-for-people-with-disabilities",
    ACCFEAT: "using-accessibility-features-in-internet-explorer",
    ACCFONTS: "specifying-fonts-and-colors-to-always-use-for-web-pages",
    KEYS: "using-internet-explorer-keyboard-shortcuts",
  };
  const INDEX = [
    {
      term: "accessibility",
      children: [
        { term: "features in Internet Explorer", topics: [T.ACCFEAT] },
        { term: "fonts and colors", topics: [T.ACCFONTS] },
        { term: "for people with disabilities", topics: [T.ACCDIS] },
        { term: "keyboard shortcuts", topics: [T.KEYS] },
      ],
    },
    { term: "finding information on the Web", topics: [T.FIND] },
    { term: "searching the Web", topics: [T.FIND] },
    { term: "digital IDs", topics: [T.IDENT] },
    { term: "identity, protecting", topics: [T.IDENT] },
    { term: "adding Web pages to the Favorites list", topics: [T.FAV] },
    { term: "adding Web pages to the Links bar", topics: [T.FAV] },
    { term: "Address bar", topics: [T.FIND, T.AUTO, T.TOOLBAR, T.KEYS] },
    { term: "Advanced tab, Internet Options", topics: [T.GRAPHICS, T.ENCODING] },
    { term: "animations, turning off", topics: [T.GRAPHICS] },
    { term: "Approved Sites tab", topics: [T.CADVON, T.CADVSITES] },
    { term: "Authenticode", topics: [T.UNSAFE, T.SEC] },
    {
      term: "AutoComplete",
      topics: [T.AUTO],
      children: [
        { term: "deleting entries", topics: [T.AUTO] },
        { term: "forms", topics: [T.AUTO] },
        { term: "passwords", topics: [T.AUTO] },
        { term: "Web addresses", topics: [T.AUTO] },
      ],
    },
    { term: "Back button", topics: [T.HIST] },
    {
      term: "bookmarks",
      children: [
        { term: "exporting", topics: [T.SHARE] },
        { term: "importing", topics: [T.SHARE] },
        { term: "Netscape Navigator", topics: [T.SHARE, T.NETSCAPE] },
      ],
    },
    { term: "certificates", topics: [T.IDENT, T.SECSITES, T.SEC, T.UNSAFE] },
    { term: "Channels folder", topics: [T.OFFLINE] },
    { term: "character sets", topics: [T.ENCODING] },
    {
      term: "colors, Web pages",
      children: [
        { term: "accessibility", topics: [T.ACCFONTS] },
        { term: "changing", topics: [T.FONTS] },
      ],
    },
    {
      term: "Content Advisor",
      topics: [T.CADV],
      children: [
        { term: "Approved Sites", topics: [T.CADVSITES] },
        { term: "enabling", topics: [T.CADVON] },
        { term: "ratings", topics: [T.CADV] },
        { term: "supervisor password", topics: [T.CADVON, T.CADVALLOW] },
        { term: "unrated sites", topics: [T.CADVALLOW] },
        { term: "viewing restricted content", topics: [T.CADVALLOW] },
      ],
    },
    {
      term: "cookies",
      topics: [T.COOKIES, T.SEC],
      children: [
        { term: "first-party and third-party", topics: [T.COOKIES] },
        { term: "persistent", topics: [T.COOKIES] },
        { term: "privacy settings", topics: [T.SEC] },
        { term: "temporary", topics: [T.COOKIES] },
      ],
    },
    { term: "credit card information", topics: [T.SECSITES, T.SEC] },
    { term: "customizing the toolbar", topics: [T.TOOLBAR] },
    { term: "disk space, History list", topics: [T.HIST] },
    { term: "disk space, temporary Internet files", topics: [T.TEMPFILES] },
    { term: "encryption, AutoComplete", topics: [T.AUTO] },
    { term: "encryption, personal information", topics: [T.SHAREINFO] },
    { term: "exporting favorites", topics: [T.SHARE] },
    {
      term: "favorites",
      children: [
        { term: "adding pages", topics: [T.FAV] },
        { term: "exporting", topics: [T.SHARE] },
        { term: "importing", topics: [T.SHARE] },
        { term: "offline viewing", topics: [T.OFFLINE] },
        { term: "sharing", topics: [T.SHARE] },
      ],
    },
    { term: "floppy disks, exporting favorites", topics: [T.SHARE] },
    {
      term: "fonts",
      children: [
        { term: "accessibility", topics: [T.ACCFONTS] },
        { term: "changing", topics: [T.FONTS] },
      ],
    },
    { term: "Forward button", topics: [T.HIST] },
    { term: "graphics, turning off", topics: [T.GRAPHICS] },
    {
      term: "History bar",
      topics: [T.HIST],
      children: [
        { term: "hiding", topics: [T.HIST] },
        { term: "number of days saved", topics: [T.HIST] },
        { term: "searching and sorting", topics: [T.HIST] },
      ],
    },
    {
      term: "home page",
      topics: [T.HOME],
      children: [
        { term: "changing", topics: [T.HOME] },
        { term: "restoring the original", topics: [T.HOME] },
        { term: "using the current page", topics: [T.HOME] },
      ],
    },
    {
      term: "images",
      children: [
        { term: "printing", topics: [T.PRINTIMG] },
        { term: "saving", topics: [T.SAVEIMG] },
        { term: "turning off", topics: [T.GRAPHICS] },
      ],
    },
    { term: "image toolbar", topics: [T.SAVEIMG, T.PRINTIMG] },
    { term: "Imported Bookmarks folder", topics: [T.SHARE] },
    { term: "importing bookmarks", topics: [T.SHARE] },
    { term: "importing favorites", topics: [T.SHARE] },
    {
      term: "Internet Explorer",
      children: [
        { term: "accessibility features", topics: [T.ACCFEAT] },
        { term: "getting started", topics: [T.START] },
        { term: "keyboard shortcuts", topics: [T.KEYS] },
      ],
    },
    { term: "Internet Options", topics: [T.HOME, T.GRAPHICS, T.TEMPFILES, T.ACCFONTS, T.CADVON] },
    { term: "keyboard shortcuts", topics: [T.KEYS, T.NETSCAPE] },
    {
      term: "language encoding",
      topics: [T.ENCODING],
      children: [
        { term: "Auto-Select", topics: [T.ENCODING] },
        { term: "language packs", topics: [T.ENCODING] },
      ],
    },
    { term: "Links bar", topics: [T.FAV, T.TOOLBAR] },
    { term: "lock icon", topics: [T.SECSITES] },
    { term: "Netscape Navigator", topics: [T.SHARE, T.NETSCAPE] },
    {
      term: "offline viewing",
      topics: [T.OFFLINE, T.VIEWOFF],
      children: [
        { term: "making pages available", topics: [T.OFFLINE] },
        { term: "synchronizing", topics: [T.VIEWOFF] },
        { term: "viewing pages", topics: [T.VIEWOFF] },
      ],
    },
    { term: "P3P privacy policy", topics: [T.SEC] },
    {
      term: "passwords",
      children: [
        { term: "AutoComplete", topics: [T.AUTO] },
        { term: "Content Advisor", topics: [T.CADVON, T.CADVALLOW] },
      ],
    },
    { term: "pictures, turning off", topics: [T.GRAPHICS] },
    {
      term: "printing",
      children: [
        { term: "images", topics: [T.PRINTIMG] },
        { term: "previewing", topics: [T.PRINT] },
        { term: "Web pages", topics: [T.PRINT] },
      ],
    },
    { term: "privacy", topics: [T.SEC, T.SHAREINFO] },
    { term: "Profile Assistant", topics: [T.SHAREINFO] },
    { term: "ratings, Content Advisor", topics: [T.CADV] },
    {
      term: "saving",
      children: [
        { term: "images", topics: [T.SAVEIMG] },
        { term: "text", topics: [T.SAVETXT] },
        { term: "Web Archive", topics: [T.SAVE] },
        { term: "Web pages", topics: [T.SAVE] },
        { term: "Web Page, complete", topics: [T.SAVE] },
      ],
    },
    { term: "secure sites", topics: [T.SECSITES] },
    {
      term: "security",
      topics: [T.SEC, T.SECSITES],
      children: [
        { term: "certificates", topics: [T.IDENT, T.SECSITES, T.SEC] },
        { term: "personal information", topics: [T.SHAREINFO] },
        { term: "unsafe software", topics: [T.UNSAFE] },
        { term: "zones", topics: [T.UNSAFE] },
      ],
    },
    { term: "sounds, turning off", topics: [T.GRAPHICS] },
    { term: "SSL (Secure Sockets Layer)", topics: [T.SHAREINFO, T.SECSITES] },
    { term: "style sheets", topics: [T.FONTS] },
    { term: "subscribing", topics: [T.OFFLINE] },
    { term: "supervisor password", topics: [T.CADVON, T.CADVALLOW] },
    { term: "Synchronize command", topics: [T.VIEWOFF] },
    { term: "temporary Internet files", topics: [T.TEMPFILES] },
    {
      term: "toolbar",
      children: [
        { term: "changing appearance", topics: [T.TOOLBAR] },
        { term: "customizing", topics: [T.TOOLBAR] },
        { term: "Links bar", topics: [T.TOOLBAR] },
      ],
    },
    { term: "unrated sites", topics: [T.CADVALLOW] },
    { term: "videos, turning off", topics: [T.GRAPHICS] },
    { term: "Web addresses, AutoComplete", topics: [T.AUTO] },
    { term: "Work Offline command", topics: [T.VIEWOFF] },
    { term: "zones, security", topics: [T.UNSAFE] },
  ];

  const $ = (id) => document.getElementById(id);
  const container = $("hh-catalog-tree");
  const content = $("hh-content");
  const hhBody = $("hh-body");
  const navBox = $("hh-nav-box");
  const tabsBar = $("hh-tabs-bar");
  const mainContainer = $("hh-main-container");
  const searchInput = $("hh-search-input");
  const listBtn = $("hh-search-list");
  const displayBtn = $("hh-search-display");
  const resultsBox = $("hh-search-results");
  const idxInput = $("hh-index-input");
  const idxList = $("hh-index-list");
  const idxDisplay = $("hh-index-display");
  const favList = $("hh-fav-list");
  const favRemove = $("hh-fav-remove");
  const favDisplay = $("hh-fav-display");
  const favCurrent = $("hh-fav-current");
  const favAdd = $("hh-fav-add");
  const modal = $("hh-topics-modal");
  const tList = $("hh-topics-list");
  const tDisplay = $("hh-topics-display");
  const tCancel = $("hh-topics-cancel");

  const homeNodes = Array.from(content.childNodes).map((n) => n.cloneNode(true));

  function slug(text) {
    return text.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  }

  const topicLabels = new Map();
  (function collect(list) {
    list.forEach((n) => {
      if (n.children) collect(n.children);
      else if (!topicLabels.has(slug(n.label))) topicLabels.set(slug(n.label), n.label);
    });
  })(TREE);

  function make(tag, className, text) {
    const e = document.createElementNS(HTML_NS, tag);
    if (className) e.setAttribute("class", className);
    if (text !== undefined) e.textContent = text;
    return e;
  }

  function markSelected(box, item, scroll = true) {
    const prev = box.querySelector(ITEM + ".selected");
    if (prev) prev.classList.remove("selected");
    if (!item) return;
    item.classList.add("selected");
    if (scroll) item.scrollIntoView({ block: "nearest" });
  }

  function arrowTarget(key, items, current) {
    const cur = items.indexOf(current);
    if (key === "ArrowDown") return items[Math.min(cur + 1, items.length - 1)];
    if (key === "ArrowUp") return items[Math.max(cur - 1, 0)];
    return undefined;
  }

  function bindItemClicks(box, pick, activate, accept = () => true) {
    box.addEventListener("click", (e) => {
      const item = e.target.closest(ITEM);
      if (item && accept(item)) pick(item);
    });
    box.addEventListener("dblclick", (e) => {
      const item = e.target.closest(ITEM);
      if (!item || !accept(item)) return;
      pick(item);
      activate();
    });
  }

  function bindHoverIcon(btn, iconFor) {
    const img = btn.querySelector("img");
    let over = false;
    const paint = () => img.setAttribute("src", BASE + iconFor(over));
    btn.addEventListener("mouseenter", () => { over = true; paint(); });
    btn.addEventListener("mouseleave", () => { over = false; paint(); });
    return paint;
  }

  function linkBlock(className, text) {
    const wrap = make("div", className);
    wrap.append(make("a", null, text));
    return wrap;
  }

  function setOpen(node, open) {
    node.classList.toggle("open", open);
    node.querySelector(":scope > .hh-tree-item img").setAttribute("src", open ? ICON.bookOpen : ICON.bookClosed);
  }

  function closeSiblings(node) {
    Array.from(node.parentElement.children).forEach((sib) => {
      if (sib !== node && sib.classList.contains("hh-tree-node") && sib.classList.contains("open")) {
        setOpen(sib, false);
      }
    });
  }

  let rowCounter = 0;

  function buildNode(data) {
    const isBook = Array.isArray(data.children);
    const node = make("div", "hh-tree-node");

    const row = make("div", "hh-tree-item");
    row.setAttribute("data-id", slug(data.label));
    row.setAttribute("data-key", String(++rowCounter));
    row.setAttribute("data-type", isBook ? "book" : "topic");

    const img = make("img");
    img.setAttribute("src", isBook ? ICON.bookClosed : ICON.topic);
    const label = make("span", "hh-tree-label");
    label.append(img, make("span", null, data.label));
    row.append(label);
    node.append(row);

    if (isBook) {
      const kids = make("div", "hh-tree-children");
      data.children.forEach((child) => kids.append(buildNode(child)));
      node.append(kids);
    }
    return node;
  }

  function inline(parent, text) {
    text.split(/(\*\*.+?\*\*|\[\[.+?\]\]|\{\{.+?\}\})/).forEach((part) => {
      if (!part) return;
      if (part.startsWith("**")) {
        parent.append(make("b", null, part.slice(2, -2)));
      } else if (part.startsWith("[[")) {
        parent.append(make("a", "hh-doc-a", part.slice(2, -2)));
      } else if (part.startsWith("{{")) {
        const img = make("img");
        img.setAttribute("src", BASE + part.slice(2, -2));
        img.style.verticalAlign = "middle";
        img.style.margin = "0 2px";
        parent.append(img);
      } else {
        parent.append(document.createTextNode(part));
      }
    });
  }

  function buildList(tag, className, items) {
    const list = make(tag, className);
    items.forEach((item) => {
      const isObj = typeof item === "object";
      const li = make("li");
      const text = make("div");
      inline(text, isObj ? item.text : item);
      li.append(text);
      if (isObj) {
        (item.extra || []).forEach((t) => {
          const extra = make("div", "hh-doc-step-extra");
          inline(extra, t);
          li.append(extra);
        });
        if (item.link) li.append(linkBlock("hh-doc-link", item.link));
      }
      list.append(li);
    });
    return list;
  }

  function toggleList(items) {
    const wrap = make("div", "hh-doc-toggles");
    items.forEach((it) => {
      const box = make("div", "hh-doc-toggle");
      const head = make("div", "hh-doc-toggle-head");
      const icon = make("img");
      icon.setAttribute("src", BASE + "plus.png");
      head.append(icon, make("span", null, it.title));
      const bodyEl = make("div", "hh-doc-toggle-body");
      (it.body || []).forEach((t) => {
        const p = make("div", "hh-doc-p");
        inline(p, t);
        bodyEl.append(p);
      });
      head.addEventListener("click", () => {
        const open = box.classList.toggle("open");
        icon.setAttribute("src", BASE + (open ? "minus.png" : "plus.png"));
      });
      box.append(head, bodyEl);
      wrap.append(box);
    });
    return wrap;
  }

  function renderDoc(doc) {
    const nodes = [];
    if (doc.title) nodes.push(make("div", "hh-doc-title", doc.title));

    doc.blocks.forEach((b) => {
      if (b.sub) {
        nodes.push(make("div", "hh-doc-section", b.sub));
      } else if (b.h) {
        nodes.push(make("div", "hh-doc-heading", b.h));
      } else if (b.p) {
        const p = make("div", "hh-doc-p");
        inline(p, b.p);
        nodes.push(p);
      } else if (b.bullets) {
        nodes.push(buildList("ul", "hh-doc-bullets", b.bullets));
      } else if (b.steps) {
        nodes.push(buildList("ol", "hh-doc-steps", b.steps));
      } else if (b.note) {
        const head = make("div", "hh-doc-note-title");
        const icon = make("img");
        icon.setAttribute("src", BASE + "note.png");
        head.append(icon, make("span", null, b.label || "Note"));
        nodes.push(head, buildList("ul", "hh-doc-bullets", b.note));
      } else if (b.toggles) {
        nodes.push(toggleList(b.toggles));
      } else if (b.related) {
        nodes.push(linkBlock("hh-doc-link hh-doc-related", b.related));
      }
    });
    content.replaceChildren(...nodes);
  }

  function select(row) {
    const prev = container.querySelector(".hh-tree-item.selected");
    if (prev) prev.classList.remove("selected");
    row.classList.add("selected");
  }

  function revealInTree(id, key) {
    let row = key ? container.querySelector('.hh-tree-item[data-key="' + key + '"]') : null;
    if (!row) row = container.querySelector('.hh-tree-item[data-id="' + id + '"]');
    if (!row) return;
    const chain = [];
    let node = row.parentElement.parentElement.closest(".hh-tree-node");
    while (node) {
      chain.unshift(node);
      node = node.parentElement.closest(".hh-tree-node");
    }
    chain.forEach((n) => { closeSiblings(n); setOpen(n, true); });
    select(row);
  }

  let navHistory = [HOME_ID];
  let navKeys = [null];
  let navPos = 0;
  let navigating = false;

  function selectedKey(id) {
    const r = container.querySelector(".hh-tree-item.selected");
    return r && r.getAttribute("data-id") === id ? r.getAttribute("data-key") : null;
  }

  function showTopicContent(id) {
    if (id === HOME_ID) {
      content.replaceChildren(...homeNodes.map((n) => n.cloneNode(true)));
    } else if (DOCS[id]) {
      renderDoc(DOCS[id]);
    } else {
      return false;
    }
    content.scrollTop = 0;
    setCurrentTopic(id);
    return true;
  }

  function onTopicSelected(id) {
    if (!showTopicContent(id)) return;
    if (!navigating && navHistory[navPos] !== id) {
      navHistory = navHistory.slice(0, navPos + 1);
      navKeys = navKeys.slice(0, navPos + 1);
      navHistory.push(id);
      navKeys.push(selectedKey(id));
      navPos = navHistory.length - 1;
    }
    updateNavButtons();
  }

  function showTopic(id) {
    revealInTree(id);
    onTopicSelected(id);
  }

  container.addEventListener("click", (e) => {
    const row = e.target.closest(".hh-tree-item");
    if (!row) return;
    select(row);

    if (row.getAttribute("data-type") !== "book") {
      onTopicSelected(row.getAttribute("data-id"));
      return;
    }

    const node = row.parentElement;
    const willOpen = !node.classList.contains("open");
    if (willOpen) closeSiblings(node);
    setOpen(node, willOpen);
    if (!willOpen) return;

    const first = node.querySelector('.hh-tree-item[data-type="topic"]');
    if (!first) return;
    const id = first.getAttribute("data-id");
    revealInTree(id, first.getAttribute("data-key"));
    onTopicSelected(id);
  });

  TREE.forEach((item) => container.append(buildNode(item)));
  select(container.querySelector(".hh-tree-item"));

  function showPanel(i) {
    const name = PANELS[i];
    if (!name || navBox.getAttribute("data-panel") === name) return;
    navBox.setAttribute("data-panel", name);
    if (name === "search") setTimeout(() => searchInput.focus(), 0);
    if (name === "index") setTimeout(() => idxInput.focus(), 0);
  }

  tabsBar.addEventListener("click", (e) => {
    const tab = e.target.closest("tab");
    if (!tab) return;
    showPanel(Array.from(tabsBar.querySelectorAll("tab")).indexOf(tab));
  });
  tabsBar.addEventListener("select", () => {
    if (typeof tabsBar.selectedIndex === "number") showPanel(tabsBar.selectedIndex);
  });

  function plain(t) {
    return t.replace(/\{\{.+?\}\}/g, " ").replace(/\*\*|\[\[|\]\]/g, "").toLowerCase();
  }

  function docText(doc) {
    const parts = [];
    const add = (t) => { if (typeof t === "string") parts.push(plain(t)); };
    const addItem = (it) => {
      if (typeof it === "string") return add(it);
      add(it.text);
      add(it.link);
      (it.extra || []).forEach(add);
    };
    (doc.blocks || []).forEach((b) => {
      add(b.h); add(b.sub); add(b.p); add(b.related);
      (b.bullets || []).forEach(addItem);
      (b.steps || []).forEach(addItem);
      (b.note || []).forEach(addItem);
      (b.toggles || []).forEach((t) => { add(t.title); (t.body || []).forEach(add); });
    });
    return parts.join(" ");
  }

  let searchIndex = null;
  function getIndex() {
    if (searchIndex) return searchIndex;
    const entries = [];
    const seen = new Set();
    const push = (id, label, title, text) => {
      if (seen.has(id)) return;
      seen.add(id);
      entries.push({ id, label, head: (label + " " + title).toLowerCase(), body: text });
    };
    topicLabels.forEach((label, id) => {
      if (id === HOME_ID) {
        push(id, label, "", plain(homeNodes.map((n) => n.textContent).join(" ")));
      } else if (DOCS[id]) {
        push(id, label, DOCS[id].title || "", docText(DOCS[id]));
      }
    });
    Object.keys(DOCS).forEach((id) => {
      if (!seen.has(id)) push(id, DOCS[id].title || id, DOCS[id].title || "", docText(DOCS[id]));
    });
    searchIndex = entries;
    return entries;
  }

  function runSearch(query) {
    const tokens = query.toLowerCase().split(/\s+/).filter(Boolean);
    if (!tokens.length) return [];
    const inTitle = [];
    const inBody = [];
    getIndex().forEach((e) => {
      const all = e.head + " " + e.body;
      if (!tokens.every((t) => all.includes(t))) return;
      (tokens.every((t) => e.head.includes(t)) ? inTitle : inBody).push(e);
    });
    return inTitle.concat(inBody);
  }

  function selectResult(item) {
    markSelected(resultsBox, item);
    displayBtn.disabled = !item;
  }

  function listTopics() {
    const found = runSearch(searchInput.value);
    resultsBox.replaceChildren();
    if (!found.length) {
      resultsBox.append(make("div", "hh-search-item empty", "No topics found."));
    } else {
      found.forEach((e) => {
        const item = make("div", "hh-search-item", e.label);
        item.setAttribute("data-id", e.id);
        resultsBox.append(item);
      });
    }
    selectResult(null);
    resultsBox.scrollTop = 0;
  }

  function displaySelected() {
    const item = resultsBox.querySelector(ITEM + ".selected");
    if (item) showTopic(item.getAttribute("data-id"));
  }

  searchInput.addEventListener("input", () => { listBtn.disabled = !searchInput.value.trim(); });
  searchInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && searchInput.value.trim()) {
      e.preventDefault();
      listTopics();
    }
  });
  listBtn.addEventListener("click", listTopics);
  displayBtn.addEventListener("click", displaySelected);
  bindItemClicks(resultsBox, selectResult, displaySelected, (item) => !item.classList.contains("empty"));
  resultsBox.addEventListener("keydown", (e) => {
    const items = Array.from(resultsBox.querySelectorAll(ITEM + ":not(.empty)"));
    if (!items.length) return;
    const target = arrowTarget(e.key, items, resultsBox.querySelector(ITEM + ".selected"));
    if (target) {
      e.preventDefault();
      selectResult(target);
    } else if (e.key === "Enter") {
      e.preventDefault();
      displaySelected();
    }
  });

  function loadFavs() {
    try {
      const list = JSON.parse(Services.prefs.getStringPref(FAVORITES_PREF, "[]"));
      return Array.isArray(list)
        ? list.filter((f) => f && typeof f.id === "string" && typeof f.label === "string")
        : [];
    } catch (err) {
      return [];
    }
  }

  let favs = loadFavs();
  let current = { id: HOME_ID, label: topicLabels.get(HOME_ID) };

  function saveFavs() {
    try {
      Services.prefs.setStringPref(FAVORITES_PREF, JSON.stringify(favs));
    } catch (err) {}
  }

  function updateFavButtons() {
    const hasSelection = !!favList.querySelector(ITEM + ".selected");
    favRemove.disabled = !hasSelection;
    favDisplay.disabled = !hasSelection;
    favAdd.disabled = !current || favs.some((f) => f.id === current.id);
  }

  function selectFav(item) {
    markSelected(favList, item);
    updateFavButtons();
  }

  function renderFavs(keepId) {
    favs.sort((a, b) => a.label.localeCompare(b.label));
    favList.replaceChildren();
    favs.forEach((f) => {
      const item = make("div", "hh-search-item", f.label);
      item.setAttribute("data-id", f.id);
      favList.append(item);
      if (f.id === keepId) item.classList.add("selected");
    });
    updateFavButtons();
  }

  function setCurrentTopic(id) {
    const doc = DOCS[id];
    current = { id, label: topicLabels.get(id) || (doc && doc.title) || id };
    favCurrent.value = current.label;
    updateFavButtons();
  }

  function selectedFav() {
    const item = favList.querySelector(ITEM + ".selected");
    return item ? item.getAttribute("data-id") : null;
  }

  function addFavorite() {
    if (!current || favs.some((f) => f.id === current.id)) return;
    favs.push({ id: current.id, label: favCurrent.value.trim() || current.label });
    saveFavs();
    renderFavs(current.id);
  }

  function removeFavorite() {
    const id = selectedFav();
    if (!id) return;
    favs = favs.filter((f) => f.id !== id);
    saveFavs();
    renderFavs(null);
  }

  function displayFavorite() {
    const id = selectedFav();
    if (id) showTopic(id);
  }

  favCurrent.value = current.label;
  renderFavs(null);

  favAdd.addEventListener("click", addFavorite);
  favRemove.addEventListener("click", removeFavorite);
  favDisplay.addEventListener("click", displayFavorite);
  bindItemClicks(favList, selectFav, displayFavorite);
  favList.addEventListener("keydown", (e) => {
    const items = Array.from(favList.querySelectorAll(ITEM));
    if (!items.length) return;
    const target = arrowTarget(e.key, items, favList.querySelector(ITEM + ".selected"));
    if (target) {
      e.preventDefault();
      selectFav(target);
    } else if (e.key === "Enter") {
      e.preventDefault();
      displayFavorite();
    } else if (e.key === "Delete") {
      e.preventDefault();
      removeFavorite();
    }
  });

  const topicExists = (id) => id === HOME_ID || !!DOCS[id];
  const topicName = (id) => topicLabels.get(id) || (DOCS[id] && DOCS[id].title) || id;
  const byTerm = (a, b) => a.term.toLowerCase().localeCompare(b.term.toLowerCase());

  const entries = [];
  INDEX.slice().sort(byTerm).forEach((e) => {
    entries.push({ term: e.term, topics: (e.topics || []).filter(topicExists), sub: false });
    (e.children || []).slice().sort(byTerm).forEach((c) => {
      entries.push({ term: c.term, topics: (c.topics || []).filter(topicExists), sub: true });
    });
  });

  entries.forEach((e, i) => {
    const item = make("div", "hh-search-item" + (e.sub ? " sub" : ""), e.term);
    item.setAttribute("data-i", String(i));
    idxList.append(item);
    e.el = item;
  });

  let sel = -1;

  function selectEntry(i, copyText) {
    if (sel >= 0 && entries[sel]) entries[sel].el.classList.remove("selected");
    sel = i;
    if (i >= 0) {
      entries[i].el.classList.add("selected");
      entries[i].el.scrollIntoView({ block: "nearest" });
      if (copyText) idxInput.value = entries[i].term;
    }
    idxDisplay.disabled = !(i >= 0 && entries[i].topics.length);
  }

  function jumpTo(query) {
    const q = query.trim().toLowerCase();
    if (!q) return selectEntry(-1, false);
    let i = entries.findIndex((e) => e.term.toLowerCase().startsWith(q));
    if (i < 0) i = entries.findIndex((e) => e.term.toLowerCase() > q);
    if (i < 0) i = entries.length - 1;
    selectEntry(i, false);
  }

  function openTopics(ids) {
    tList.replaceChildren();
    ids.forEach((id) => {
      const item = make("div", "hh-search-item", topicName(id));
      item.setAttribute("data-id", id);
      tList.append(item);
    });
    markSelected(tList, tList.firstElementChild, false);
    tDisplay.disabled = false;
    modal.classList.add("open");
    setTimeout(() => tList.focus(), 0);
  }

  function closeTopics() {
    modal.classList.remove("open");
    idxInput.focus();
  }

  function pickTopic(item) {
    markSelected(tList, item, false);
  }

  function displayPicked() {
    const item = tList.querySelector(ITEM + ".selected");
    if (!item) return;
    modal.classList.remove("open");
    showTopic(item.getAttribute("data-id"));
  }

  bindItemClicks(tList, pickTopic, displayPicked);
  tDisplay.addEventListener("click", displayPicked);
  tCancel.addEventListener("click", closeTopics);
  modal.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      closeTopics();
    } else if (e.key === "Enter") {
      e.preventDefault();
      displayPicked();
    } else {
      const items = Array.from(tList.querySelectorAll(ITEM));
      const target = arrowTarget(e.key, items, tList.querySelector(ITEM + ".selected"));
      if (target) {
        e.preventDefault();
        pickTopic(target);
      }
    }
  });

  function displayEntry() {
    if (sel < 0) return;
    const ids = entries[sel].topics;
    if (!ids.length) return;
    if (ids.length === 1) showTopic(ids[0]);
    else openTopics(ids);
  }

  function indexKeydown(e) {
    if (e.key === "Enter") {
      e.preventDefault();
      displayEntry();
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      selectEntry(Math.min(sel + 1, entries.length - 1), true);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      selectEntry(Math.max(sel - 1, 0), true);
    }
  }

  idxInput.addEventListener("input", () => jumpTo(idxInput.value));
  idxInput.addEventListener("keydown", indexKeydown);
  idxList.addEventListener("keydown", indexKeydown);
  idxDisplay.addEventListener("click", displayEntry);
  bindItemClicks(idxList, (item) => selectEntry(Number(item.getAttribute("data-i")), true), displayEntry);

  const hideBtn = $("btn-hide");
  const paintHideIcon = bindHoverIcon(hideBtn, (over) =>
    hhBody.classList.contains("nav-hidden") || over ? "hide-hover.png" : "hide.png"
  );
  hideBtn.addEventListener("click", () => {
    hhBody.classList.toggle("nav-hidden");
    hideBtn.querySelector("span").textContent = hhBody.classList.contains("nav-hidden") ? "Show" : "Hide";
    paintHideIcon();
  });

  const NAV_ICONS = {
    back: { normal: "back.png", hover: "back-hover.png", disabled: "back-disable.png" },
    forward: { normal: "forward.png", hover: "forward-hover.png", disabled: "forward-disable.png" },
  };

  const navButtons = [
    { kind: "back", el: $("btn-back"), delta: -1 },
    { kind: "forward", el: $("btn-forward"), delta: 1 },
  ];

  function isEnabled(b) {
    const target = navPos + b.delta;
    return target >= 0 && target < navHistory.length;
  }

  function updateNavButtons() {
    navButtons.forEach((b) => b.paint());
  }

  function go(delta) {
    const target = navPos + delta;
    if (target < 0 || target >= navHistory.length) return;
    navPos = target;
    const id = navHistory[navPos];
    navigating = true;
    try {
      onTopicSelected(id);
      revealInTree(id, navKeys[navPos]);
    } finally {
      navigating = false;
    }
    updateNavButtons();
  }

  navButtons.forEach((b) => {
    const icons = NAV_ICONS[b.kind];
    const paintIcon = bindHoverIcon(b.el, (over) => (!isEnabled(b) ? icons.disabled : over ? icons.hover : icons.normal));
    b.paint = () => {
      b.el.classList.toggle("disabled", !isEnabled(b));
      paintIcon();
    };
    b.el.addEventListener("click", () => go(b.delta));
  });

  updateNavButtons();

  bindHoverIcon($("btn-webhelp"), (over) => (over ? "webhelp-hover.png" : "webhelp.png"));

  const optionsBtn = $("btn-options");
  const MENU = [
    { label: "Hide Tabs" },
    { label: "Back", disabled: true },
    { label: "Forward", disabled: true },
    { label: "Home" },
    { label: "Stop" },
    { label: "Refresh" },
    { label: "Internet Options..." },
    "-",
    { label: "2 Web Help" },
    "-",
    { label: "Print..." },
    { label: "Search Highlight Off" },
  ];

  const menu = make("div");
  menu.id = "hh-options-menu";
  MENU.forEach((m) => {
    if (m === "-") menu.append(make("div", "hh-menu-sep"));
    else menu.append(make("div", "hh-menu-item" + (m.disabled ? " disabled" : ""), m.label));
  });
  mainContainer.append(menu);

  const paintOptions = bindHoverIcon(optionsBtn, (over) =>
    over || menu.classList.contains("open") ? "options-hover.png" : "options.png"
  );

  function openMenu() {
    const r = optionsBtn.getBoundingClientRect();
    menu.style.left = r.left + "px";
    menu.style.top = r.bottom + "px";
    menu.classList.add("open");
    optionsBtn.classList.add("open");
    optionsBtn.setAttribute("open", "true");
    paintOptions();
  }

  function closeMenu() {
    menu.classList.remove("open");
    optionsBtn.classList.remove("open");
    optionsBtn.removeAttribute("open");
    paintOptions();
  }

  optionsBtn.addEventListener("click", () => {
    if (menu.classList.contains("open")) closeMenu();
    else openMenu();
  });
  menu.addEventListener("click", (e) => {
    if (e.target.closest(".hh-menu-item:not(.disabled)")) closeMenu();
  });
  document.addEventListener("mousedown", (e) => {
    if (!menu.classList.contains("open")) return;
    if (e.target.closest("#hh-options-menu") || e.target.closest("#btn-options")) return;
    closeMenu();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && menu.classList.contains("open")) closeMenu();
  });
  window.addEventListener("blur", closeMenu);

  function showTopicExternal(id) {
    navBox.setAttribute("data-panel", "contents");
    try { tabsBar.selectedIndex = 0; } catch (err) {}
    showTopic(id);
  }

  window.ie6ShowTopic = showTopicExternal;

  const startTopic = window.arguments && window.arguments[0];
  if (typeof startTopic === "string" && startTopic) showTopicExternal(startTopic);
})();