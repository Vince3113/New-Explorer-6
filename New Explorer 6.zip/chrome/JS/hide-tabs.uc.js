(function () {
  "use strict";

  const PREF_FORCE_HIDDEN = "ie6theme.tabs.forcehidden";

  const isForcedHidden = () => Services.prefs.getBoolPref(PREF_FORCE_HIDDEN, false);

  function setForcedHidden(value) {
    try {
      Services.prefs.setBoolPref(PREF_FORCE_HIDDEN, value);
    } catch (e) {}
  }

  function setFlag(el, name, on) {
    if (on) el.setAttribute(name, "true");
    else el.removeAttribute(name);
  }

  function applyVisibility(tabCount) {
    const tabsToolbar = document.getElementById("TabsToolbar");
    if (tabsToolbar) setFlag(tabsToolbar, "ie6-hidden", isForcedHidden() || tabCount <= 1);
  }

  function findToolbarsPopup() {
    const menu = document.getElementById("viewToolbarsMenu");
    if (menu) {
      return menu.localName === "menupopup" ? menu : menu.querySelector("menupopup");
    }
    const viewPopup = document.getElementById("menu_viewPopup");
    for (const m of viewPopup?.querySelectorAll("menu") || []) {
      if (m.getAttribute("label") === "Toolbars") return m.querySelector("menupopup");
    }
    return null;
  }

  function setupViewMenuItem() {
    const popup = findToolbarsPopup();
    if (!popup || document.getElementById("toolbars-tabs-menuitem")) return;

    const item = document.createXULElement("menuitem");
    item.id = "toolbars-tabs-menuitem";
    item.setAttribute("type", "checkbox");
    item.setAttribute("autocheck", "false");
    item.setAttribute("label", "Tabs");
    item.setAttribute("accesskey", "T");

    item.addEventListener("command", () => {
      const tabsToolbar = document.getElementById("TabsToolbar");
      if (!tabsToolbar) return;
      const hide = !tabsToolbar.hasAttribute("ie6-hidden");
      setForcedHidden(hide);
      setFlag(tabsToolbar, "ie6-hidden", hide);
    });

    function place() {
      const menuBarItem = document.getElementById("toggle_toolbar-menubar");
      if (menuBarItem && menuBarItem.parentNode === popup) {
        menuBarItem.after(item);
      } else {
        const separator = popup.querySelector("menuseparator");
        if (separator) popup.insertBefore(item, separator);
        else popup.appendChild(item);
      }
      const tabsToolbar = document.getElementById("TabsToolbar");
      setFlag(item, "checked", !!tabsToolbar && !tabsToolbar.hasAttribute("ie6-hidden"));
    }

    popup.addEventListener("popupshowing", place);
    place();
  }

  function init() {
    const update = () => applyVisibility(gBrowser.tabs.length);
    update();
    setupViewMenuItem();

    gBrowser.tabContainer.addEventListener("TabOpen", update);
    gBrowser.tabContainer.addEventListener("TabClose", () => applyVisibility(gBrowser.tabs.length - 1));
  }

  if (gBrowserInit?.delayedStartupFinished) {
    init();
    return;
  }

  const onStartup = (subject, topic) => {
    if (subject !== window) return;
    Services.obs.removeObserver(onStartup, topic);
    init();
  };
  Services.obs.addObserver(onStartup, "browser-delayed-startup-finished");
})();