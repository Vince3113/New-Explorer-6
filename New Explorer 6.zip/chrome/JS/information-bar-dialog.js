() => {
  "use strict";

  const PREF_HIDE_DIALOG = "extensions.ie6theme.infobar.hideDialog";

  const check = document.getElementById("ibd-check");
  const ok = document.getElementById("ibd-ok");

  window.addEventListener("unload", () => {
    try {
      Services.prefs.setBoolPref(PREF_HIDE_DIALOG, check.checked);
    } catch (e) {}
  });

  ok.addEventListener("command", () => window.close());

  window.addEventListener("keydown", (e) => {
    if (e.key !== "Escape" && e.key !== "Enter") return;
    e.preventDefault();
    window.close();
  });

  window.addEventListener("load", () => ok.focus());
})();