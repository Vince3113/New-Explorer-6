(function () {
  const POPUP_ID = "contentAreaContextMenu";
  const HIDE_CLASS = "ie6-ctxnative-hide";
  const SEP_CLASS = "ie6-ctxnative-sep-hide";
  const IMG_HIDE_CLASSES = ["imgctx-hide", "imgctx-sep-hide"];
  const CLEAN_OBSERVE = { attributes: true, subtree: true, attributeFilter: ["class", "hidden"] };

  let cleaner = null;

  const RENAMES = [
    { sel: "#context-inspect", re: /^Inspect Element/, label: "Inspect", accesskey: "I" },
    { sel: "#context-viewinfo", re: /^View Page Info/, label: "Properties", accesskey: "r" },
    { sel: "#context-viewpartialsource-selection", re: /^View Selection Source/, label: "Source", accesskey: "o" },
    { sel: "#context-searchselect", re: /^Search .+ for /, label: "Search in the Internet", accesskey: "S" },
    { sel: "#context-print-selection", re: /^Print Selection/, label: "Print", accesskey: "P" },
    { sel: null, re: /^Send Page Link/, label: "Send Link by E-Mail", accesskey: "d" },
    { sel: "#context-copylink", re: /^Copy Link Location/, label: "Copy Link", accesskey: "L" },
    { sel: "#context-bookmarklink", re: /^Bookmark This Link/, label: "Add Link to Favorites", accesskey: "F" },
  ];
  const [, , , SEARCH_RULE, PRINT_RULE, SEND_LINK_RULE] = RENAMES;

  const HIDES = [
    { sel: "#context-searchselect-private", re: /^Search in a Private Window/ },
    { sel: '[id*="highlight" i]', re: /Link to Highlight/ },
    { sel: "#context-sendlinktodevice", re: /^Send Link to / },
    { sel: '[id*="copycleanlink" i]', re: /^Copy Clean Link/ },
    { sel: "#context-openlinkprivate", re: /^Open Link in New Private Window/ },
    { sel: "#context-openlinkincontainertab", re: /^Open Link in New Container Tab/ },
    { sel: '[id*="openlinkinsplit" i], [id*="linkinsplit" i]', re: /^Open Link in Split View/ },
  ];

  const isOwnItem = (el) => el.localName === "menuseparator" || el.classList.contains("ie6-ctx");

  function isMatch(el, rule) {
    const label = el.getAttribute("label") || "";
    return (
      (rule.sel && el.matches(rule.sel)) ||
      rule.re.test(label) ||
      (rule.label && label === rule.label)
    );
  }

  function findItem(popup, rule) {
    for (const el of popup.children) {
      if (!isOwnItem(el) && isMatch(el, rule)) return el;
    }
    return null;
  }

  function setAttr(el, name, value) {
    if (el.getAttribute(name) !== value) el.setAttribute(name, value);
  }

  function reorder(popup) {
    const search = findItem(popup, SEARCH_RULE);
    if (!search) return;
    let anchor = search;
    for (const rule of [SEND_LINK_RULE, PRINT_RULE]) {
      const el = findItem(popup, rule);
      if (!el) continue;
      if (anchor.nextElementSibling !== el) anchor.after(el);
      anchor = el;
    }
  }

  function process(el) {
    if (!el || isOwnItem(el)) return;

    const rename = RENAMES.find((rule) => isMatch(el, rule));
    if (rename) {
      setAttr(el, "label", rename.label);
      setAttr(el, "accesskey", rename.accesskey);
    }

    el.classList.toggle(HIDE_CLASS, HIDES.some((rule) => isMatch(el, rule)));
  }

  function isHiddenItem(el) {
    return (
      el.hidden ||
      el.classList.contains(HIDE_CLASS) ||
      IMG_HIDE_CLASSES.some((name) => el.classList.contains(name))
    );
  }

  function cleanSeparators(popup) {
    const kids = [...popup.children];
    for (const k of kids) {
      if (k.localName === "menuseparator") k.classList.remove(SEP_CLASS);
    }
    let prevWasSep = true;
    let lastSep = null;
    for (const k of kids) {
      if (isHiddenItem(k) || k.classList.contains("ie6-ctx")) continue;
      if (k.localName === "menuseparator") {
        if (prevWasSep) {
          k.classList.add(SEP_CLASS);
        } else {
          prevWasSep = true;
          lastSep = k;
        }
      } else {
        prevWasSep = false;
        lastSep = null;
      }
    }
    if (lastSep) lastSep.classList.add(SEP_CLASS);
  }

  function runClean(popup) {
    cleaner?.disconnect();
    cleanSeparators(popup);
    cleaner?.observe(popup, CLEAN_OBSERVE);
  }

  function init() {
    const popup = document.getElementById(POPUP_ID);
    if (!popup || popup.dataset.selectionInit) return;
    popup.dataset.selectionInit = "1";

    new MutationObserver((records) => {
      for (const r of records) {
        if (r.target.parentNode === popup) process(r.target);
      }
    }).observe(popup, {
      attributes: true,
      subtree: true,
      attributeFilter: ["label", "accesskey", "data-l10n-id"],
    });

    cleaner = new MutationObserver((records) => {
      if (popup.hasAttribute("ie6-plain")) return;
      if (records.some((r) => r.target.parentNode === popup)) runClean(popup);
    });
    cleaner.observe(popup, CLEAN_OBSERVE);

    popup.addEventListener("popupshowing", (event) => {
      if (event.target !== popup) return;
      for (const el of popup.children) process(el);
      if (!popup.hasAttribute("ie6-plain")) {
        reorder(popup);
        runClean(popup);
      }
    });
  }

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();