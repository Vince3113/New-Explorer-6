(function () {
  function getActiveTabInfo() {
    const browser = window.gBrowser.selectedBrowser;
    return {
      url: browser.currentURI ? browser.currentURI.spec : "",
      title: window.gBrowser.selectedTab.label || browser.contentTitle || "",
    };
  }

  function openAddFavoriteDialog() {
    window.openDialog(
      "chrome://userscripts/content/add-favorite-dialog.xhtml",
      "ie6-add-favorite-window",
      "chrome,dialog,centerscreen,resizable=no",
      getActiveTabInfo()
    );
  }

  function openOrganizeFavoritesWindow() {
    const existing = Services.wm.getMostRecentWindow("ie6theme:organize-favorites");
    if (existing) {
      existing.focus();
      return;
    }
    window.openDialog(
      "chrome://userscripts/content/organize-favorites-window.xhtml",
      "_blank",
      "chrome,resizable=yes,centerscreen"
    );
  }

  function hijack(id, handler) {
    const el = document.getElementById(id);
    if (!el) return;
    el.removeAttribute("command");
    el.removeAttribute("oncommand");
    el.addEventListener("command", handler);
  }

  function init() {
    hijack("menu_bookmarkThisPage", openAddFavoriteDialog);
    hijack("bookmarksShowAll", openOrganizeFavoritesWindow);
  }

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();