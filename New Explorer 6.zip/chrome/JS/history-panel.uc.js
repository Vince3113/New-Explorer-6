(function () {
  const HTML_NS = "http://www.w3.org/1999/xhtml";

  const { PlacesUtils } = ChromeUtils.importESModule(
    "resource://gre/modules/PlacesUtils.sys.mjs"
  );

  const ICON_DIR = (() => {
    const dir = Services.dirsvc.get("ProfD", Ci.nsIFile);
    dir.append("chrome");
    dir.append("images");
    return Services.io.newFileURI(dir).spec.replace(/\/?$/, "/");
  })();

  const FOLDER_OPEN = "history-folder.png";
  const FOLDER_CLOSED = "history-folder-close.png";
  const FLAT_PAGE = "sb-row hist-page hist-flat-page";

  const VIEW_OPTIONS = [
    { id: "date", label: "By Date" },
    { id: "site", label: "By Site" },
    { id: "mostvisited", label: "By Most Visited" },
    { id: "todayorder", label: "By Order Visited Today" },
  ];

  let sidebar;
  let listWrapperEl;
  let listEl;
  let searchViewEl;
  let searchInputEl;
  let searchResultsEl;
  let viewMenuEl;
  let ctxMenuEl;
  let showingSearch = false;
  let currentView = "date";
  let currentResult = null;
  let lastSearchTerm = "";

  const iconURL = (name) => ICON_DIR + name;

  function h(tag, className, text) {
    const el = document.createElementNS(HTML_NS, tag);
    if (className) el.className = className;
    if (text != null) el.textContent = text;
    return el;
  }

  function icon(name, className = "sb-icon") {
    const img = h("img", className);
    img.src = iconURL(name);
    return img;
  }

  function siteLabel(siteNode) {
    return siteNode.title === "(local files)" ? "My Computer" : siteNode.title;
  }

  function setSelectedRow(rowEl) {
    sidebar?.querySelector(".sb-selected")?.classList.remove("sb-selected");
    rowEl.classList.add("sb-selected");
  }

  function releaseResult() {
    if (!currentResult) return;
    try {
      currentResult.root.containerOpen = false;
    } catch (e) {}
    currentResult = null;
  }

  function openRoot(setup) {
    const query = PlacesUtils.history.getNewQuery();
    const options = PlacesUtils.history.getNewQueryOptions();
    setup(query, options);
    const result = PlacesUtils.history.executeQuery(query, options);
    result.root.containerOpen = true;
    return { result, root: result.root };
  }

  function showCtxMenu(x, y, label, onConfirm) {
    if (!ctxMenuEl) {
      ctxMenuEl = h("div", "sb-menu sb-ctxmenu");
      ctxMenuEl.hidden = true;
      sidebar.appendChild(ctxMenuEl);
    }

    const item = h("div", "sb-menu-item", label);
    item.addEventListener("click", (e) => {
      e.stopPropagation();
      ctxMenuEl.hidden = true;
      onConfirm();
    });

    ctxMenuEl.replaceChildren(item);
    ctxMenuEl.style.left = x + "px";
    ctxMenuEl.style.top = y + "px";
    ctxMenuEl.hidden = false;
  }

  function deleteUrls(urls) {
    if (!urls.length) return;
    PlacesUtils.history
      .remove(urls)
      .catch((e) => {});
  }

  function collectUrls(containerNode) {
    const urls = [];
    (function walk(node) {
      node.QueryInterface(Ci.nsINavHistoryContainerResultNode);
      node.containerOpen = true;
      for (let i = 0; i < node.childCount; i++) {
        const child = node.getChild(i);
        if (child.type === child.RESULT_TYPE_URI) urls.push(child.uri);
        else walk(child);
      }
      node.containerOpen = false;
    })(containerNode);
    return urls;
  }

  function attachDelete(rowEl, label, getUrls, onDeleted) {
    rowEl.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      e.stopPropagation();
      setSelectedRow(rowEl);
      showCtxMenu(e.clientX, e.clientY, label, () => {
        deleteUrls(getUrls());
        onDeleted();
      });
    });
  }

  function createPageRow(pageNode, className, onDeleted) {
    const row = h("div", className);
    const title = pageNode.title || pageNode.uri;
    row.title = `${title}\n${pageNode.uri}`;
    row.append(icon("page.png"), h("span", null, title));
    row.addEventListener("click", () => {
      setSelectedRow(row);
      gBrowser.selectedTab = gBrowser.addTrustedTab(pageNode.uri);
    });
    attachDelete(row, "Delete Page", () => [pageNode.uri], onDeleted);
    return row;
  }

  function appendPages(container, parentNode, className, onDeleted) {
    for (let i = 0; i < parentNode.childCount; i++) {
      container.appendChild(createPageRow(parentNode.getChild(i), className, onDeleted));
    }
  }

  function createSiteRow(siteNode) {
    const row = h("div", "sb-row hist-site");
    const folderIcon = icon(FOLDER_CLOSED);
    row.title = `Pages visited at ${siteLabel(siteNode)}`;
    row.append(folderIcon, h("span", null, siteLabel(siteNode)));
    attachDelete(row, "Delete History", () => collectUrls(siteNode), buildList);
    return { row, folderIcon };
  }

  function fillPages(siteNode, pageBox) {
    siteNode.QueryInterface(Ci.nsINavHistoryContainerResultNode);
    siteNode.containerOpen = true;
    appendPages(pageBox, siteNode, "sb-row hist-page", buildList);
    siteNode.containerOpen = false;
    pageBox.dataset.filled = "1";
  }

  function fillSites(dayNode, siteBox) {
    dayNode.QueryInterface(Ci.nsINavHistoryContainerResultNode);
    dayNode.containerOpen = true;

    for (let i = 0; i < dayNode.childCount; i++) {
      const siteNode = dayNode.getChild(i);
      const { row, folderIcon } = createSiteRow(siteNode);
      const pageBox = h("div", "sb-children hist-pages");
      siteBox.append(row, pageBox);

      row.addEventListener("click", () => {
        setSelectedRow(row);
        const wasOpen = pageBox.classList.contains("sb-open");

        siteBox
          .querySelectorAll(".hist-pages")
          .forEach((box) => box.classList.remove("sb-open"));
        siteBox
          .querySelectorAll(".hist-site .sb-icon")
          .forEach((img) => (img.src = iconURL(FOLDER_CLOSED)));

        if (wasOpen) return;
        pageBox.classList.add("sb-open");
        folderIcon.src = iconURL(FOLDER_OPEN);
        if (!pageBox.dataset.filled) fillPages(siteNode, pageBox);
      });
    }

    dayNode.containerOpen = false;
    siteBox.dataset.filled = "1";
  }

  function buildDateView() {
    const { result, root } = openRoot((query, options) => {
      options.resultType = options.RESULTS_AS_DATE_SITE_QUERY;
      options.sortingMode = options.SORT_BY_DATE_DESCENDING;
    });
    currentResult = result;

    const openDay = (group, dayNode, siteBox) => {
      group.classList.add("sb-group-open");
      siteBox.classList.add("sb-open");
      if (!siteBox.dataset.filled) fillSites(dayNode, siteBox);
    };

    for (let i = 0; i < root.childCount; i++) {
      const dayNode = root.getChild(i);

      const group = h("div", "sb-group");
      const dayRow = h("div", "sb-row hist-day");
      const siteBox = h("div", "sb-children");
      dayRow.title = `Pages visited ${dayNode.title}`;
      dayRow.append(icon("history-calendar.png"), h("span", null, dayNode.title));
      attachDelete(dayRow, "Delete History", () => collectUrls(dayNode), buildList);
      group.append(dayRow, siteBox);
      listEl.appendChild(group);

      dayRow.addEventListener("click", () => {
        setSelectedRow(dayRow);
        const wasOpen = group.classList.contains("sb-group-open");

        listEl.querySelectorAll(".sb-group-open").forEach((grp) => {
          grp.classList.remove("sb-group-open");
          grp.querySelector(".sb-children").classList.remove("sb-open");
        });

        if (!wasOpen) openDay(group, dayNode, siteBox);
      });

      if (i === 0) openDay(group, dayNode, siteBox);
    }
  }

  function buildSiteView() {
    const { result, root } = openRoot((query, options) => {
      options.resultType = options.RESULTS_AS_SITE_QUERY;
      options.sortingMode = options.SORT_BY_TITLE_ASCENDING;
    });
    currentResult = result;

    for (let i = 0; i < root.childCount; i++) {
      const siteNode = root.getChild(i);
      const { row, folderIcon } = createSiteRow(siteNode);
      const pageBox = h("div", "sb-children hist-pages");
      const group = h("div", "sb-group");
      group.append(row, pageBox);
      listEl.appendChild(group);

      row.addEventListener("click", () => {
        setSelectedRow(row);
        const opening = !pageBox.classList.contains("sb-open");
        pageBox.classList.toggle("sb-open", opening);
        folderIcon.src = iconURL(opening ? FOLDER_OPEN : FOLDER_CLOSED);
        if (opening && !pageBox.dataset.filled) fillPages(siteNode, pageBox);
      });
    }
  }

  function buildFlatView(setup) {
    const { root } = openRoot(setup);
    appendPages(listEl, root, FLAT_PAGE, buildList);
    root.containerOpen = false;
  }

  function setupMostVisited(query, options) {
    options.resultType = options.RESULTS_AS_URI;
    options.sortingMode = options.SORT_BY_VISITCOUNT_DESCENDING;
    options.maxResults = 100;
  }

  function setupToday(query, options) {
    const now = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    query.beginTime = PlacesUtils.toPRTime(startOfDay);
    query.endTime = PlacesUtils.toPRTime(now);
    options.resultType = options.RESULTS_AS_VISIT;
    options.sortingMode = options.SORT_BY_DATE_DESCENDING;
    options.maxResults = 200;
  }

  function buildList() {
    if (!listEl) return;
    releaseResult();
    listEl.textContent = "";
    listEl.classList.toggle("hist-site-view", currentView === "site");

    switch (currentView) {
      case "site":
        return buildSiteView();
      case "mostvisited":
        return buildFlatView(setupMostVisited);
      case "todayorder":
        return buildFlatView(setupToday);
      default:
        return buildDateView();
    }
  }

  function runSearch(term) {
    lastSearchTerm = term;
    searchResultsEl.textContent = "";
    if (!term) return;

    const { root } = openRoot((query, options) => {
      query.searchTerms = term;
      options.resultType = options.RESULTS_AS_URI;
      options.sortingMode = options.SORT_BY_DATE_DESCENDING;
      options.maxResults = 100;
    });

    if (!root.childCount) {
      searchResultsEl.appendChild(h("div", "hist-search-empty", "No results found."));
    }
    appendPages(searchResultsEl, root, FLAT_PAGE, () => runSearch(lastSearchTerm));
    root.containerOpen = false;
  }

  function toggleSearchView() {
    showingSearch = !showingSearch;
    listWrapperEl.hidden = showingSearch;
    searchViewEl.hidden = !showingSearch;
    if (showingSearch) {
      searchInputEl.value = "";
      searchResultsEl.textContent = "";
      searchInputEl.focus();
    }
  }

  function buildViewMenu() {
    viewMenuEl.textContent = "";
    for (const opt of VIEW_OPTIONS) {
      const row = h("div", "sb-menu-item hist-viewmenu-item");
      row.append(
        opt.id === currentView ? icon("radio.png", "hist-radio") : h("span", "hist-radio-spacer"),
        h("span", null, opt.label)
      );
      row.addEventListener("click", (e) => {
        e.stopPropagation();
        currentView = opt.id;
        viewMenuEl.hidden = true;
        buildList();
      });
      viewMenuEl.appendChild(row);
    }
  }

  function toggleViewMenu() {
    if (viewMenuEl.hidden) buildViewMenu();
    viewMenuEl.hidden = !viewMenuEl.hidden;
  }

  function hideSidebar() {
    sidebar.hidden = true;
    releaseResult();
  }

  function buildTitlebar() {
    const titlebar = h("div", "sb-titlebar");
    const closeBtn = icon("close.png", "sb-flatbtn sb-close-btn");
    closeBtn.title = "Close";
    closeBtn.addEventListener("click", hideSidebar);
    titlebar.append(h("span", null, "History"), closeBtn);
    return titlebar;
  }

  function buildToolbar() {
    const toolbar = h("div", "sb-toolbar");

    const viewEl = h("span", "sb-flatbtn hist-view", "View ▾");
    viewEl.addEventListener("click", (e) => {
      e.stopPropagation();
      toggleViewMenu();
    });

    viewMenuEl = h("div", "sb-menu hist-viewmenu");
    viewMenuEl.hidden = true;

    const searchEl = h("span", "sb-flatbtn hist-search");
    searchEl.append(icon("history-search.png", "sb-icon hist-search-icon"), h("span", null, "Search"));
    searchEl.addEventListener("click", toggleSearchView);

    toolbar.append(viewEl, viewMenuEl, searchEl);
    return toolbar;
  }

  function buildSearchView() {
    searchViewEl = h("div", "hist-searchview");
    searchViewEl.hidden = true;

    searchInputEl = h("input", "hist-search-input");
    searchInputEl.type = "text";

    const searchNowBtn = h("button", null, "Search Now");
    const stopBtn = h("button", null, "Stop");
    stopBtn.disabled = true;

    const doSearch = () => runSearch(searchInputEl.value.trim());
    searchNowBtn.addEventListener("click", doSearch);
    searchInputEl.addEventListener("keydown", (e) => {
      if (e.key === "Enter") doSearch();
    });

    const btnRow = h("div", "hist-search-btnrow");
    btnRow.append(searchNowBtn, stopBtn);

    const controls = h("div", "hist-search-controls");
    controls.append(h("label", "hist-search-label", "Search for:"), searchInputEl, btnRow);

    searchResultsEl = h("div", "hist-search-results");
    const resultsWrapper = h("div", "hist-search-wrapper");
    resultsWrapper.appendChild(searchResultsEl);

    searchViewEl.append(controls, resultsWrapper);
    return searchViewEl;
  }

  function ensureSidebar() {
    if (sidebar) return sidebar;

    sidebar = document.createXULElement("vbox");
    sidebar.id = "ie6-history-sidebar";
    sidebar.className = "sb-panel";
    sidebar.hidden = true;

    listEl = h("div", "sb-list");
    listWrapperEl = h("div", "sb-list-wrapper");
    listWrapperEl.appendChild(listEl);

    sidebar.append(buildTitlebar(), buildToolbar(), listWrapperEl, buildSearchView());

    const browserBox = document.getElementById("browser");
    browserBox.insertBefore(sidebar, browserBox.firstChild);

    window.__ie6Sidebars ||= {
      panels: {},
      register(id, hideFn) {
        this.panels[id] = hideFn;
      },
      closeOthers(exceptId) {
        for (const [id, hideFn] of Object.entries(this.panels)) {
          if (id !== exceptId) hideFn();
        }
      },
    };
    window.__ie6Sidebars.register("history", hideSidebar);

    return sidebar;
  }

  function toggleSidebar() {
    ensureSidebar();
    if (!sidebar.hidden) return hideSidebar();

    window.__ie6Sidebars?.closeOthers("history");
    sidebar.hidden = false;
    buildList();
  }

  window.ie6ToggleHistorySidebar = toggleSidebar;

  function init() {
    document.addEventListener(
      "ViewShowing",
      (e) => {
        if (e.target.id !== "PanelUI-history") return;
        e.preventDefault();
        e.stopPropagation();

        const panel = document.getElementById("customizationui-widget-panel");
        if (panel && (panel.state === "open" || panel.state === "showing")) {
          panel.hidePopup();
        }

        toggleSidebar();
      },
      true
    );

    document.addEventListener("click", () => {
      if (viewMenuEl) viewMenuEl.hidden = true;
      if (ctxMenuEl) ctxMenuEl.hidden = true;
    });
  }

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();