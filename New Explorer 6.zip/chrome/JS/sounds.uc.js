(function () {
  const CLICK_SOUND = "resource://ie6theme/sounds/navclick.wav";
  const POPUP_SOUND = "resource://ie6theme/sounds/popup-blocked.wav";
  const PREF_POPUP_SOUND = "extensions.ie6theme.popupblocker.playSound";

  function play(url) {
    new Audio(url).play().catch((e) => {});
  }

  function playClick() {
    play(CLICK_SOUND);
  }
  window.ie6PlayClickSound = playClick;

  document.addEventListener(
    "click",
    (e) => {
      const btn = e.target.closest("#back-button, #forward-button, #home-button");
      if (btn && !btn.disabled && !btn.hasAttribute("disabled")) playClick();
    },
    true
  );

  document.addEventListener(
    "keypress",
    (e) => {
      if (e.key === "Enter" && e.target.id === "urlbar-input") playClick();
    },
    true
  );

  document.getElementById("urlbar-go-button")?.addEventListener("click", playClick, true);

  const lastBlockedCount = new WeakMap();

  window.addEventListener(
    "DOMUpdateBlockedPopups",
    (e) => {
      try {
        const browser = e.target;
        let count;
        try {
          count = browser.popupBlocker.getBlockedPopupCount();
        } catch (err) {}

        const prev = lastBlockedCount.get(browser) || 0;
        if (count !== undefined) {
          lastBlockedCount.set(browser, count);
          if (count <= prev) return;
        }

        if (window.ie6PopupFilter?.willAutoAllow(browser)) return;
        if (!Services.prefs.getBoolPref(PREF_POPUP_SOUND, true)) return;
        play(POPUP_SOUND);
      } catch (err) {}
    },
    true
  );
})();