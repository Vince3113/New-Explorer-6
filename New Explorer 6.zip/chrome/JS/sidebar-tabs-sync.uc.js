(function () {
  const SIDEBAR_IDS = [
    "ie6-search-sidebar",
    "ie6-bookmarks-sidebar",
    "ie6-history-sidebar",
    "ie6-downloads-sidebar",
    "ie6-folders-sidebar",
    "ie6-media-sidebar",
    "ie6-research-sidebar",
    "ie6-logins-sidebar",
    "ie6-account-sidebar",
  ];

  const isVisible = (el) => !el.hidden && getComputedStyle(el).display !== "none";

  function anySidebarVisible() {
    return SIDEBAR_IDS.some((id) => {
      const el = document.getElementById(id);
      return !!el && isVisible(el);
    });
  }

  const tabsToolbarVisible = () => !document.getElementById("TabsToolbar")?.hasAttribute("ie6-hidden");

  function setFlag(root, name, on) {
    if (on) root.setAttribute(name, "true");
    else root.removeAttribute(name);
  }

  function sync() {
    const root = document.getElementById("main-window");
    if (!root) return;

    const sidebarVisible = anySidebarVisible();
    setFlag(root, "sidebar-visible", sidebarVisible);
    setFlag(root, "ie6-sidebar-open", sidebarVisible && tabsToolbarVisible());
  }

  let scheduled = false;
  function scheduleSync() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      sync();
    });
  }

  function init() {
    const root = document.documentElement;
    if (!root) return;

    new MutationObserver(scheduleSync).observe(root, {
      attributes: true,
      attributeFilter: ["hidden", "style", "class", "ie6-hidden"],
      subtree: true,
      childList: true,
    });
    sync();
  }

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();