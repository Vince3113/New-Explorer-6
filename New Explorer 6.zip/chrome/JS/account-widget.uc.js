(function () {
  const { CustomizableUI } = ChromeUtils.importESModule(
    "moz-src:///browser/components/customizableui/CustomizableUI.sys.mjs"
  );

  CustomizableUI.createWidget({
    id: "ie6-account-button",
    type: "button",
    label: "Account",
    tooltiptext: "Account",
    onCommand() {
      window.ie6ToggleAccountSidebar?.();
    },
  });

  if (CustomizableUI.getPlacementOfWidget("fxa-toolbar-menu-button")) {
    CustomizableUI.removeWidgetFromArea("fxa-toolbar-menu-button");
  }
})();