(function () {
  function openFindWindow() {
    const existing = Services.wm.getMostRecentWindow("ie6-find-window");
    if (existing) {
      existing.focus();
      return;
    }
    window.openDialog(
      "chrome://userscripts/content/find-window.xhtml",
      "_blank",
      "chrome,dialog,centerscreen,resizable=no"
    );
  }

  document.addEventListener(
    "keydown",
    (e) => {
      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && e.key.toLowerCase() === "f") {
        e.preventDefault();
        e.stopPropagation();
        openFindWindow();
      }
    },
    true
  );

  function hijackFindMenuItem() {
    const item =
      document.getElementById("menu_find") ||
      document.querySelector('menuitem[command="cmd_find"]');
    if (!item) return;
    item.removeAttribute("command");
    item.removeAttribute("oncommand");
    item.addEventListener("command", openFindWindow);
  }

  if (document.readyState === "complete") hijackFindMenuItem();
  else window.addEventListener("load", hijackFindMenuItem, { once: true });
})();