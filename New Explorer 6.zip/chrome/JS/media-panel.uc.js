(function () {
  const HTML_NS = "http://www.w3.org/1999/xhtml";

  const ICON_DIR = (() => {
    const dir = Services.dirsvc.get("ProfD", Ci.nsIFile);
    dir.append("chrome");
    dir.append("images");
    return Services.io.newFileURI(dir).spec.replace(/\/?$/, "/");
  })();

  const CACHE_TTL = 60 * 60 * 1000;
  const TODAY_TTL = 30 * 60 * 1000;
  const FETCH_TIMEOUT_MS = 8000;

  const DEEZER = "https://api.deezer.com";
  const APPLE_RSS = "https://rss.marketingtools.apple.com/api/v2/us/music";
  const ARTIST_SEARCH_URL = "https://www.deezer.com/search/";

  const RADIO_SERVERS = [
    "https://de1.api.radio-browser.info",
    "https://at1.api.radio-browser.info",
    "https://nl1.api.radio-browser.info",
  ];
  const RADIO_CODECS = ["MP3", "AAC", "AAC+", "OGG"];
  const STATION_COUNT = 5;
  const RADIO_COUNTRY_OVERRIDE = "AR";
  const COUNTRY_ALIASES = { usa: "US", eeuu: "US", uk: "GB" };
  const SHOUTCAST_URL = "https://directory.shoutcast.com/";

  const RADIO_GENRES = [
    { label: "Pop / Top 40", tags: ["pop", "top 40", "top40"] },
    { label: "Rock / Alternative", tags: ["rock", "alternative"] },
    { label: "Country", tags: ["country"] },
    { label: "Jazz / Blues", tags: ["jazz", "blues"] },
    { label: "R&B / Hip-Hop", tags: ["r&b", "hip hop", "hiphop"] },
  ];

  const MUSIC_GENRES = [
    { label: "Pop", id: 132 },
    { label: "Rock", id: 152 },
    { label: "Rap / Hip-Hop", id: 116 },
    { label: "R&B", id: 165 },
    { label: "Latin", id: 197 },
    { label: "Electro", id: 106 },
    { label: "Jazz", id: 129 },
    { label: "Country", id: 84 },
  ];

  const MUSIC_STORES = [
    { text: "Amazon Music", url: "https://www.amazon.com/music" },
    { text: "iTunes Store", url: "https://music.apple.com/" },
    { text: "Bandcamp", url: "https://bandcamp.com/" },
    { text: "Discogs", url: "https://www.discogs.com/" },
  ];

  const MOVIE_SEARCH_URL = "https://www.imdb.com/find/?s=tt&q=";
  const MORE_MOVIES_URL = "https://trailers.apple.com/";
  const TRAILER_SEARCH_URL = "https://www.youtube.com/results?search_query=";
  const MOVIES_TOP_COUNT = 5;
  const TMDB_API_KEY = "";

  const MOVIE_GENRES = [
    { label: "Action & Adventure", tmdb: "28|12", itunes: 4401 },
    { label: "Comedy", tmdb: "35", itunes: 4404 },
    { label: "Sci-Fi & Fantasy", tmdb: "878|14", itunes: 4413 },
    { label: "Drama", tmdb: "18", itunes: 4406 },
  ];

  const TODAY_FEEDS = [
    { name: "Variety", url: "https://variety.com/feed/" },
    { name: "Rolling Stone", url: "https://www.rollingstone.com/feed/" },
    { name: "Billboard", url: "https://www.billboard.com/feed/" },
  ];
  const TODAY_NEWS_URL =
    "https://news.google.com/rss/headlines/section/topic/ENTERTAINMENT?hl=en-US&gl=US&ceid=US:en";
  const MEDIA_SEARCH_URL = "https://www.youtube.com/results?search_query=";
  const MORE_MEDIA_URL = "https://archive.org/";

  const audio = new Audio();
  let video = null;
  let activeMedia = audio;
  let currentObjectUrl = null;
  let setPlayingState = () => {};
  let setVideoScreenVisible = () => {};

  let sidebar;
  let radioBase = RADIO_SERVERS[0];
  let radioAttemptCleanup = null;

  const iconURL = (name) => ICON_DIR + name;
  const mediaURL = (name) => ICON_DIR + "media/" + name;
  const playClick = () => window.ie6PlayClickSound?.();
  const openTab = (url) => openWebLinkIn(url, "tab");

  function h(tag, className, text) {
    const el = document.createElementNS(HTML_NS, tag);
    if (className) el.className = className;
    if (text != null) el.textContent = text;
    return el;
  }

  function icon(src, className) {
    const img = h("img", className);
    img.src = src;
    img.draggable = false;
    return img;
  }

  function createButton(className, text) {
    const btn = h("button", className, text);
    btn.type = "button";
    return btn;
  }

  function createTextInput(placeholder) {
    const input = h("input", "md-find-input");
    input.type = "text";
    if (placeholder) input.placeholder = placeholder;
    input.setAttribute("spellcheck", "false");
    input.setAttribute("autocomplete", "off");
    return input;
  }

  function createLink(text, onClick, className = "md-link") {
    const link = h("a", className, text);
    if (onClick) link.addEventListener("click", onClick);
    return link;
  }

  function createGoButton() {
    const btn = createButton("md-search-go");
    btn.title = "Go";
    const img = icon(iconURL("go.png"), "md-search-go-img");
    btn.appendChild(img);
    btn.addEventListener("mouseenter", () => (img.src = iconURL("go-hover.png")));
    btn.addEventListener("mouseleave", () => (img.src = iconURL("go.png")));
    return btn;
  }

  function createSearchRow(onSubmit, { placeholder, compact = true } = {}) {
    const row = h("div", "md-find" + (compact ? " md-search-row" : ""));
    const input = createTextInput(placeholder);
    const goBtn = createGoButton();
    row.append(input, goBtn);

    const submit = () => {
      const value = input.value.trim();
      if (!value) return;
      playClick();
      onSubmit(value);
    };
    goBtn.addEventListener("click", submit);
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        submit();
      }
    });
    return { row, input };
  }

  function createGoLink(text, url) {
    const row = h("div", "md-places-item md-today-more");
    const img = icon(iconURL("go.png"), "md-more-media-icon");
    row.append(img, h("span", "md-places-label", text));
    row.addEventListener("mouseenter", () => (img.src = iconURL("go-hover.png")));
    row.addEventListener("mouseleave", () => (img.src = iconURL("go.png")));
    row.addEventListener("click", () => {
      playClick();
      openTab(url);
    });
    return row;
  }

  function createSlotSection(title) {
    const wrap = h("div", "md-section");
    if (title) wrap.appendChild(h("p", "md-list-title", title));
    const slot = h("div");
    wrap.appendChild(slot);
    return { wrap, slot };
  }

  function infoItem(content) {
    const row = h("div", "md-info-item");
    const text = h("span", "md-info-text");
    text.appendChild(content);
    row.append(h("span", "md-bullet", "\u2022"), text);
    return row;
  }

  function renderNumberedList(slot, items) {
    const list = h("div", "md-tracks");
    items.forEach((item, i) => {
      const info = h("span", "md-track-info");
      const link = createLink(item.title, item.onClick);
      if (item.tooltip) link.title = item.tooltip;
      info.appendChild(link);
      if (item.note) info.appendChild(h("span", "md-track-note", item.note));

      const row = h("div", "md-track");
      row.append(h("span", "md-track-num", `${i + 1}.`), info);
      list.appendChild(row);
    });
    slot.appendChild(list);
  }

  const renderTracks = (slot, tracks) =>
    renderNumberedList(
      slot,
      tracks.map((t) => ({
        title: t.title,
        note: t.artist ? " - " + t.artist : "",
        tooltip: t.artist ? `${t.title} - ${t.artist}` : t.title,
      }))
    );

  async function timedFetch(url, kind) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS);
    try {
      const res = await fetch(url, { signal: ctrl.signal, cache: "no-store" });
      if (!res.ok) throw new Error("HTTP " + res.status);
      return kind === "text" ? await res.text() : await res.json();
    } finally {
      clearTimeout(timer);
    }
  }

  const cacheEntries = new Map();
  const pendingLoads = new Map();

  function cached(key, ttl, produce) {
    const hit = cacheEntries.get(key);
    if (hit && Date.now() - hit.time < ttl) return Promise.resolve(hit.value);
    if (pendingLoads.has(key)) return pendingLoads.get(key);

    const promise = produce()
      .then((value) => {
        cacheEntries.set(key, { value, time: Date.now() });
        return value;
      })
      .finally(() => pendingLoads.delete(key));
    pendingLoads.set(key, promise);
    return promise;
  }

  function showMessage(slot, text, onRetry) {
    slot.textContent = "";
    slot.appendChild(h("p", "md-status", text));
    if (onRetry) slot.appendChild(createLink("Try again", onRetry));
  }

  function loadInto(slot, { fetch: fetchData, render, error, loading = "Loading...", isCurrent = () => true }) {
    const options = { fetch: fetchData, render, error, loading, isCurrent };
    showMessage(slot, loading);
    fetchData().then(
      (data) => {
        if (!isCurrent()) return;
        slot.textContent = "";
        render(slot, data);
      },
      () => {
        if (isCurrent()) showMessage(slot, error, () => loadInto(slot, options));
      }
    );
  }

  const normName = (str) => String(str || "").toLowerCase().replace(/[^a-z0-9]/g, "");

  function shortenBio(text, max) {
    text = String(text || "").replace(/\s+/g, " ").trim();
    if (text.length <= max) return text;
    const cut = text.slice(0, max);
    const lastStop = Math.max(cut.lastIndexOf(". "), cut.lastIndexOf("! "), cut.lastIndexOf("? "));
    if (lastStop > max * 0.5) return cut.slice(0, lastStop + 1);
    return cut.slice(0, cut.lastIndexOf(" ")) + "...";
  }

  const mapTracks = (data, count) =>
    (data || [])
      .filter((t) => t && t.title)
      .slice(0, count)
      .map((t) => ({ title: t.title_short || t.title, artist: t.artist?.name || "" }));

  function buildGenreList(title, genres, loadGenre) {
    const wrap = h("div", "md-section");
    wrap.appendChild(h("p", "md-list-title", title));

    for (const genre of genres) {
      const item = h("div", "md-genre");
      const head = h("div", "md-genre-head");
      head.append(h("span", "md-genre-arrow"), h("span", "md-genre-label", genre.label));
      const slot = h("div", "md-genre-slot");
      item.append(head, slot);

      let loaded = false;
      head.addEventListener("click", () => {
        playClick();
        const opening = !item.classList.contains("md-genre-open");
        item.classList.toggle("md-genre-open", opening);
        if (opening && !loaded) {
          loaded = true;
          loadGenre(genre, slot);
        }
      });
      wrap.appendChild(item);
    }
    return wrap;
  }

  function stopAllMedia() {
    audio.pause();
    audio.currentTime = 0;

    if (video) {
      video.pause();
      video.currentTime = 0;
      video.src = "";
    }

    setVideoScreenVisible(false);
    setPlayingState(false);
  }

  function pickAndPlay(accept, getMedia, showVideo) {
    const input = h("input");
    input.type = "file";
    input.accept = accept;

    input.addEventListener("change", () => {
      const file = input.files[0];
      const media = getMedia();
      if (!file || !media) return;

      stopAllMedia();
      if (currentObjectUrl) URL.revokeObjectURL(currentObjectUrl);
      currentObjectUrl = URL.createObjectURL(file);

      activeMedia = media;
      media.src = currentObjectUrl;
      media.play()?.catch(() => {});

      setVideoScreenVisible(showVideo);
      setPlayingState(true);
    });

    input.click();
  }

  const selectAndPlayAudio = () => pickAndPlay("audio/*", () => audio, false);
  const selectAndPlayVideo = () => pickAndPlay("video/*", () => video, true);

  const getFeaturedAlbum = () =>
    cached("featured-album", CACHE_TTL, async () => {
      const json = await timedFetch(`${DEEZER}/chart/0/albums?limit=10`, "json");
      const list = (json.data || []).filter((a) => a && a.title && a.cover_small);
      if (!list.length) throw new Error("Empty chart");

      const pick = list[Math.floor(Math.random() * list.length)];
      return {
        title: pick.title,
        artist: pick.artist?.name || "",
        artistId: pick.artist?.id || null,
        cover: pick.cover_small,
      };
    });

  function renderFeatured(slot, album) {
    const cover = icon(album.cover, "md-promo-img");
    cover.title = album.title;
    cover.addEventListener("error", () => (cover.style.visibility = "hidden"));

    const text = h("div", "md-promo-text");
    text.appendChild(h("p", "md-promo-headline md-featured-album", album.title));
    if (album.artist) {
      text.appendChild(h("p", "md-promo-headline md-featured-artist", album.artist));
    }

    const links = h("div", "md-links");
    links.append(createLink("Play Clip"), createLink("Watch Video"));
    text.appendChild(links);

    const promo = h("div", "md-promo");
    promo.append(cover, text);
    slot.appendChild(promo);
  }

  const getTopTracks = () =>
    cached("top-tracks", CACHE_TTL, async () => {
      const json = await timedFetch(`${DEEZER}/chart/0/tracks?limit=5`, "json");
      const tracks = mapTracks(json.data, 5);
      if (!tracks.length) throw new Error("Empty chart");
      return tracks;
    });

  const loadFeatured = (slot) =>
    loadInto(slot, { fetch: getFeaturedAlbum, render: renderFeatured, error: "Featured content is unavailable." });

  const loadTopMusic = (slot) =>
    loadInto(slot, { fetch: getTopTracks, render: renderTracks, error: "Top Music is unavailable." });

  async function fetchArtistBio(name) {
    const url =
      "https://en.wikipedia.org/w/api.php?action=query&format=json&formatversion=2" +
      "&generator=search&gsrlimit=1&gsrsearch=" + encodeURIComponent(name + " musician") +
      "&prop=extracts&exintro=1&explaintext=1&exsentences=3&exlimit=1&redirects=1";
    const json = await timedFetch(url, "json");
    const page = json?.query?.pages?.[0];
    if (!page?.extract) return null;
    if (!normName(page.title).includes(normName(name))) return null;
    return {
      text: shortenBio(page.extract, 280),
      url: "https://en.wikipedia.org/?curid=" + page.pageid,
    };
  }

  async function fetchArtistReleases(artistId) {
    if (!artistId) return null;
    const json = await timedFetch(`${DEEZER}/artist/${artistId}/albums?limit=50`, "json");
    const seen = new Set();
    return (json.data || [])
      .filter((a) => a && a.title && a.release_date)
      .sort((a, b) => (a.release_date < b.release_date ? 1 : -1))
      .filter((a) => {
        const key = a.title.toLowerCase().replace(/\s*[\(\[].*?[\)\]]/g, "").trim();
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .slice(0, 3)
      .map((a) => ({ title: a.title, year: a.release_date.slice(0, 4) }));
  }

  async function fetchArtistNews(name) {
    const url =
      "https://news.google.com/rss/search?q=" + encodeURIComponent('"' + name + '"') +
      "&hl=en-US&gl=US&ceid=US:en";
    const doc = new DOMParser().parseFromString(await timedFetch(url, "text"), "text/xml");
    if (doc.querySelector("parsererror")) throw new Error("Bad RSS");

    const news = [];
    for (const item of doc.querySelectorAll("item")) {
      const rawTitle = item.querySelector("title")?.textContent || "";
      const link = item.querySelector("link")?.textContent || "";
      const source = item.querySelector("source")?.textContent || "";
      if (!rawTitle || !link) continue;

      const title = source && rawTitle.endsWith(" - " + source) ? rawTitle.slice(0, -(source.length + 3)) : rawTitle;
      news.push({ title, link, source });
      if (news.length >= 3) break;
    }
    return news;
  }

  const getArtistInfo = (album) =>
    cached("artist:" + (album.artistId || album.artist), CACHE_TTL, async () => {
      const [bio, releases, news] = await Promise.allSettled([
        fetchArtistBio(album.artist),
        fetchArtistReleases(album.artistId),
        fetchArtistNews(album.artist),
      ]);

      const info = {
        name: album.artist,
        bio: bio.status === "fulfilled" ? bio.value : null,
        releases: releases.status === "fulfilled" ? releases.value : null,
        news: news.status === "fulfilled" ? news.value : null,
      };

      if (!info.bio && !info.releases?.length && !info.news?.length) throw new Error("No artist data");
      return info;
    });

  function renderArtistInfo(slot, info) {
    slot.appendChild(h("p", "md-list-title", info.name));

    if (info.bio) {
      slot.appendChild(h("p", "md-info-bio", info.bio.text));
      slot.appendChild(createLink("More on Wikipedia", () => openTab(info.bio.url)));
    }

    if (info.releases?.length) {
      slot.appendChild(h("p", "md-list-title md-subtitle", "Recent Releases"));
      info.releases.forEach((r) => {
        slot.appendChild(infoItem(document.createTextNode(`${r.title} (${r.year})`)));
      });
    }

    if (info.news?.length) {
      slot.appendChild(h("p", "md-list-title md-subtitle", "News"));
      info.news.forEach((n) => {
        const content = document.createDocumentFragment();
        content.appendChild(createLink(n.title, () => openTab(n.link)));
        if (n.source) content.appendChild(h("span", "md-info-src", " - " + n.source));
        slot.appendChild(infoItem(content));
      });
    }
  }

  const loadArtistInfo = (slot) =>
    loadInto(slot, {
      fetch: () => getFeaturedAlbum().then(getArtistInfo),
      render: renderArtistInfo,
      error: "Artist Info is unavailable.",
    });

  function buildSearchMusic() {
    const { wrap, slot } = createSlotSection("Search Music");
    let requestId = 0;

    const runSearch = (query) => {
      const id = ++requestId;
      loadInto(slot, {
        fetch: async () => {
          const json = await timedFetch(`${DEEZER}/search?limit=5&q=${encodeURIComponent(query)}`, "json");
          return mapTracks(json.data, 5);
        },
        render: (target, tracks) => {
          if (tracks.length) renderTracks(target, tracks);
          else showMessage(target, "No songs found.");
        },
        loading: "Searching...",
        error: "Search is unavailable.",
        isCurrent: () => id === requestId,
      });
    };

    wrap.insertBefore(createSearchRow(runSearch).row, slot);
    return wrap;
  }

  function buildBuyMusic() {
    const wrap = h("div", "md-section");
    wrap.appendChild(h("p", "md-list-title", "Buy Music"));

    for (const store of MUSIC_STORES) {
      const row = h("div", "md-places-item md-buy-item");
      row.append(h("span", "md-bullet", "\u2022"), h("span", "md-places-label", store.text));
      row.addEventListener("click", () => {
        playClick();
        openTab(store.url);
      });
      wrap.appendChild(row);
    }
    return wrap;
  }

  function fillMsnMusic(body) {
    const featured = createSlotSection("Featured");
    const top = createSlotSection("Top Music");
    const info = createSlotSection("Artist Info");

    body.append(featured.wrap, top.wrap, info.wrap, buildSearchMusic(), buildBuyMusic());

    loadFeatured(featured.slot);
    loadTopMusic(top.slot);
    loadArtistInfo(info.slot);
  }

  function detectRadioCountry() {
    const clean = (c) => (/^[A-Za-z]{2}$/.test(c || "") ? c.toUpperCase() : "");

    let cc = clean(RADIO_COUNTRY_OVERRIDE);
    if (cc) return cc;

    try {
      cc = clean(((Services.locale.regionalPrefsLocales || [])[0] || "").split("-")[1]);
      if (cc) return cc;
    } catch (e) {}

    try {
      cc = clean(Services.prefs.getCharPref("browser.search.region", ""));
    } catch (e) {}
    return cc;
  }

  async function radioFetch(path) {
    let lastErr = new Error("No radio servers");
    for (const base of RADIO_SERVERS) {
      try {
        const json = await timedFetch(base + path, "json");
        radioBase = base;
        return json;
      } catch (e) {
        lastErr = e;
      }
    }
    throw lastErr;
  }

  async function fetchRadioList({ country = "", tag = "", state = "", order = "clicktrend", name = "" } = {}) {
    const query = new URLSearchParams({
      order,
      reverse: "true",
      hidebroken: "true",
      is_https: "true",
      limit: "40",
    });
    if (country) query.set("countrycode", country);
    if (tag) query.set("tag", tag);
    if (state) query.set("state", state);
    if (name) query.set("name", name);

    const json = await radioFetch("/json/stations/search?" + query);
    return (Array.isArray(json) ? json : [])
      .filter(
        (st) =>
          st &&
          st.name &&
          st.url_resolved &&
          st.lastcheckok === 1 &&
          !st.hls &&
          st.url_resolved.startsWith("https://") &&
          RADIO_CODECS.includes(String(st.codec || "").toUpperCase())
      )
      .map((st) => ({
        uuid: st.stationuuid,
        name: st.name.trim(),
        url: st.url_resolved,
        codec: st.codec,
        bitrate: st.bitrate,
        country: st.country || "",
      }));
  }

  function dedupeStations(list) {
    const seen = new Set();
    const out = [];
    for (const st of list) {
      const key = normName(st.name);
      if (!key || seen.has(key)) continue;
      seen.add(key);
      out.push(st);
      if (out.length >= STATION_COUNT) break;
    }
    return out;
  }

  async function collectStations(fetchLists, { globalOnlyIfEmpty = false } = {}) {
    const country = detectRadioCountry();
    const out = [];
    const seen = new Set();
    let lastErr = null;

    for (const cc of country ? [country, ""] : [""]) {
      if (out.length >= STATION_COUNT) break;
      if (globalOnlyIfEmpty && cc === "" && out.length) break;

      let lists;
      try {
        lists = await fetchLists(cc);
      } catch (e) {
        lastErr = e;
        continue;
      }

      const longest = Math.max(0, ...lists.map((l) => l.length));
      for (let i = 0; i < longest && out.length < STATION_COUNT; i++) {
        for (const list of lists) {
          const st = list[i];
          const key = st && normName(st.name);
          if (!key || seen.has(key)) continue;
          seen.add(key);
          out.push(st);
          if (out.length >= STATION_COUNT) break;
        }
      }
    }

    if (!out.length) throw lastErr || new Error("No playable stations");
    return out;
  }

  const getFeaturedStations = () =>
    cached("radio-featured", CACHE_TTL, () =>
      collectStations(async (cc) => [await fetchRadioList({ country: cc })], { globalOnlyIfEmpty: true })
    );

  const getGenreStations = (genre) =>
    cached("radio-genre:" + genre.label, CACHE_TTL, () =>
      collectStations(async (cc) => {
        const results = await Promise.allSettled(genre.tags.map((tag) => fetchRadioList({ country: cc, tag })));
        const lists = results.filter((r) => r.status === "fulfilled").map((r) => r.value);
        if (!lists.length) throw results[0].reason;
        return lists;
      })
    );

  function playStation(station, statusEl) {
    radioAttemptCleanup?.();
    statusEl.textContent = "";

    stopAllMedia();
    activeMedia = audio;

    const cleanup = () => {
      audio.removeEventListener("error", onError);
      audio.removeEventListener("playing", cleanup);
      if (radioAttemptCleanup === cleanup) radioAttemptCleanup = null;
    };
    const onError = () => {
      cleanup();
      setPlayingState(false);
      statusEl.textContent = "Couldn't play this station.";
    };
    audio.addEventListener("error", onError);
    audio.addEventListener("playing", cleanup);
    radioAttemptCleanup = cleanup;

    audio.src = station.url;
    audio.play().catch((err) => {
      if (err?.name === "AbortError") return;
      onError();
    });
    setPlayingState(true);

    if (station.uuid) fetch(radioBase + "/json/url/" + station.uuid, { cache: "no-store" }).catch(() => {});
  }

  function renderStations(slot, stations, statusEl) {
    for (const st of stations) {
      const link = createLink(st.name, () => playStation(st, statusEl));
      const details = [st.country, st.bitrate ? `${st.bitrate}k ${st.codec}` : st.codec].filter(Boolean).join(" - ");
      link.title = details ? `${st.name} (${details})` : st.name;
      slot.appendChild(infoItem(link));
    }
  }

  function buildBrowseRadios() {
    const statusEl = h("p", "md-status");
    const wrap = buildGenreList("Browse Radios", RADIO_GENRES, (genre, slot) =>
      loadInto(slot, {
        fetch: () => getGenreStations(genre),
        render: (target, stations) => renderStations(target, stations, statusEl),
        error: "Stations are unavailable.",
      })
    );
    wrap.appendChild(statusEl);
    return wrap;
  }

  const getPickCountries = () =>
    cached("pick-countries", Infinity, async () =>
      ((await radioFetch("/json/countries?hidebroken=true")) || []).filter(
        (c) => c && /^[A-Za-z]{2}$/.test(c.iso_3166_1 || "")
      )
    );

  const normLoc = (str) =>
    String(str || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]/g, "");

  function regionName(code) {
    try {
      return new Intl.DisplayNames(["en"], { type: "region" }).of(code) || code;
    } catch (e) {
      return code;
    }
  }

  function resolveCountry(text, countries) {
    const q = normLoc(text);
    if (!q) return null;

    const codes = new Set(countries.map((c) => c.iso_3166_1.toUpperCase()));
    if (COUNTRY_ALIASES[q] && codes.has(COUNTRY_ALIASES[q])) return COUNTRY_ALIASES[q];

    const namers = ["en", "es"]
      .map((lang) => {
        try {
          return new Intl.DisplayNames([lang], { type: "region" });
        } catch (e) {
          return null;
        }
      })
      .filter(Boolean);

    for (const c of countries) {
      const code = c.iso_3166_1.toUpperCase();
      if (normLoc(code) === q) return code;
      const names = [c.name];
      namers.forEach((n) => {
        try {
          names.push(n.of(code));
        } catch (e) {}
      });
      if (names.some((n) => normLoc(n) === q)) return code;
    }
    return null;
  }

  async function findPickStations(spec) {
    let code = spec.code || null;
    let candidates = [];

    if (!code) {
      const parts = String(spec.text || "").split(",").map((x) => x.trim()).filter(Boolean);
      if (!parts.length) return null;

      let countries = [];
      try {
        countries = await getPickCountries();
      } catch (e) {}

      if (parts.length >= 2) {
        code = resolveCountry(parts[parts.length - 1], countries);
        candidates = (code ? parts.slice(0, -1) : parts).slice().reverse().slice(0, 2);
      } else {
        code = resolveCountry(parts[0], countries);
        candidates = code ? [] : [parts[0]];
      }
    }

    const countryName = code ? regionName(code) : "";

    for (const cand of candidates) {
      const list = await fetchRadioList({ country: code || "", state: cand, order: "votes" });
      if (list.length) {
        return {
          stations: dedupeStations(list),
          label: countryName ? `${cand}, ${countryName}` : cand,
          note: "",
        };
      }
    }

    if (code) {
      const list = await fetchRadioList({ country: code, order: "votes" });
      if (list.length) {
        return {
          stations: dedupeStations(list),
          label: countryName,
          note: candidates.length ? `No stations found for ${candidates[0]}. Showing ${countryName}.` : "",
        };
      }
    }

    return { stations: [], label: spec.text || countryName, note: "" };
  }

  function buildPickRadio() {
    const wrap = h("div", "md-section md-pickradio");
    wrap.appendChild(h("p", "md-list-title", "Pick Radio"));

    const locName = h("span", "md-pick-loc-name");
    const locLine = h("p", "md-pick-loc");
    locLine.append("Radios in ", locName);
    wrap.appendChild(locLine);

    const changeBtn = createButton("md-btn", "Change Location");
    wrap.appendChild(changeBtn);

    const closeEdit = () => wrap.classList.remove("md-pick-editing");
    const search = createSearchRow((text) => {
      closeEdit();
      applyLocation({ text });
    });
    const edit = h("div", "md-pick-edit");
    edit.append(search.row, h("p", "md-status", "Type a city and country, e.g. Buenos Aires, Argentina"));
    wrap.appendChild(edit);

    const slot = h("div");
    const statusEl = h("p", "md-status");
    wrap.append(slot, statusEl);

    let requestId = 0;
    function applyLocation(spec) {
      const id = ++requestId;
      statusEl.textContent = "";
      loadInto(slot, {
        fetch: () => findPickStations(spec),
        render: (target, res) => {
          if (!res) return;
          locName.textContent = res.label;
          if (!res.stations.length) {
            showMessage(target, "No stations found for that location.");
            return;
          }
          renderStations(target, res.stations, statusEl);
          if (res.note) statusEl.textContent = res.note;
        },
        error: "Stations are unavailable.",
        isCurrent: () => id === requestId,
      });
    }

    changeBtn.addEventListener("click", () => {
      playClick();
      if (wrap.classList.toggle("md-pick-editing")) {
        search.input.focus();
        search.input.select();
      }
    });
    search.input.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closeEdit();
    });

    const cc = detectRadioCountry();
    if (cc) {
      locName.textContent = regionName(cc);
      applyLocation({ code: cc });
    } else {
      locName.textContent = "...";
      wrap.classList.add("md-pick-editing");
    }

    return wrap;
  }

  function buildSearchRadio() {
    const wrap = h("div", "md-section");
    wrap.appendChild(h("p", "md-list-title", "Search Radio"));

    const slot = h("div");
    const statusEl = h("p", "md-status");
    let requestId = 0;

    const runSearch = (keyword) => {
      const id = ++requestId;
      statusEl.textContent = "";
      loadInto(slot, {
        fetch: async () => {
          let list = await fetchRadioList({ name: keyword, order: "votes" });
          if (!list.length) list = await fetchRadioList({ tag: keyword, order: "votes" });
          return dedupeStations(list);
        },
        render: (target, stations) => {
          if (stations.length) renderStations(target, stations, statusEl);
          else showMessage(target, "No stations found.");
        },
        loading: "Searching...",
        error: "Search is unavailable.",
        isCurrent: () => id === requestId,
      });
    };

    const row = h("div", "md-find md-search-row");
    const input = createTextInput();
    const findBtn = createButton("md-btn md-find-btn");
    const lens = icon(iconURL("search14.png"), "md-find-btn-icon");
    lens.addEventListener("error", () => {
      if (!lens.dataset.fallback) {
        lens.dataset.fallback = "1";
        lens.src = mediaURL("search14.png");
      }
    });
    findBtn.append(lens, h("span", null, "Find"));
    row.append(input, findBtn);

    const doFind = () => {
      const keyword = input.value.trim();
      if (!keyword) return;
      playClick();
      runSearch(keyword);
    };
    findBtn.addEventListener("click", doFind);
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        doFind();
      }
    });

    const moreBtn = createButton("md-btn md-more-btn", "More Stations");
    moreBtn.addEventListener("click", () => {
      playClick();
      openTab(SHOUTCAST_URL);
    });

    wrap.append(row, slot, statusEl, moreBtn);
    return wrap;
  }

  function fillRadio(body) {
    const featured = createSlotSection("Featured Stations");
    const statusEl = h("p", "md-status");
    featured.wrap.appendChild(statusEl);

    body.append(featured.wrap, buildBrowseRadios(), buildPickRadio(), buildSearchRadio());

    loadInto(featured.slot, {
      fetch: getFeaturedStations,
      render: (slot, stations) => renderStations(slot, stations, statusEl),
      error: "Stations are unavailable.",
    });
  }

  const getNewReleases = () =>
    cached("new-releases", CACHE_TTL, async () => {
      const json = await timedFetch(`${APPLE_RSS}/most-played/100/albums.json`, "json");
      const today = new Date().toISOString().slice(0, 10);
      const releases = (json?.feed?.results || [])
        .filter((a) => a && a.name && a.url && a.artworkUrl100 && a.releaseDate && a.releaseDate <= today)
        .sort((a, b) => (a.releaseDate < b.releaseDate ? 1 : -1))
        .slice(0, 5)
        .map((a) => ({
          title: a.name,
          artist: a.artistName || "",
          url: a.url,
          artistUrl: a.artistUrl || a.url,
          cover: a.artworkUrl100,
        }));
      if (!releases.length) throw new Error("No releases");
      return releases;
    });

  function renderNewReleases(slot, releases) {
    for (const rel of releases) {
      const albumUrl = rel.url;

      const cover = icon(rel.cover, "md-release-img");
      cover.title = rel.title;
      cover.addEventListener("error", () => (cover.style.visibility = "hidden"));
      cover.addEventListener("click", () => {
        playClick();
        openTab(albumUrl);
      });

      const text = h("div", "md-release-text");
      text.appendChild(createLink(rel.title, () => openTab(albumUrl), "md-link md-release-link"));
      if (rel.artist) {
        text.appendChild(createLink(rel.artist, () => openTab(rel.artistUrl), "md-link md-release-link"));
      }

      const item = h("div", "md-release");
      item.append(cover, text);
      slot.appendChild(item);
    }
  }

  const getGenreTracks = (genre) =>
    cached("genre-tracks:" + genre.id, CACHE_TTL, async () => {
      const json = await timedFetch(`${DEEZER}/chart/${genre.id}/tracks?limit=5`, "json");
      const tracks = mapTracks(json.data, 5);
      if (!tracks.length) throw new Error("Empty genre chart");
      return tracks;
    });

  function buildSearchArtist() {
    const wrap = h("div", "md-section");
    wrap.append(
      h("p", "md-list-title", "Search Music"),
      h("p", "md-search-label", "Search Artist:"),
      createSearchRow((query) => openTab(ARTIST_SEARCH_URL + encodeURIComponent(query) + "/artist")).row
    );
    return wrap;
  }

  function fillMusic(body) {
    const top = createSlotSection("Top Music");
    const releases = createSlotSection("New Releases");

    body.append(
      top.wrap,
      releases.wrap,
      buildGenreList("Browse Music", MUSIC_GENRES, (genre, slot) =>
        loadInto(slot, {
          fetch: () => getGenreTracks(genre),
          render: renderTracks,
          error: "Songs are unavailable.",
        })
      ),
      buildSearchArtist()
    );

    loadTopMusic(top.slot);
    loadInto(releases.slot, {
      fetch: getNewReleases,
      render: renderNewReleases,
      error: "New releases are unavailable.",
    });
  }

  const movieTrailerUrl = (title) => TRAILER_SEARCH_URL + encodeURIComponent(title + " official trailer");
  const movieClipUrl = (title) => TRAILER_SEARCH_URL + encodeURIComponent(title + " movie clip");

  async function fetchMovieList(genre, limit) {
    if (TMDB_API_KEY) {
      try {
        let url = "https://api.themoviedb.org/3/";
        if (genre) {
          const from = new Date(Date.now() - 365 * 24 * 3600 * 1000).toISOString().slice(0, 10);
          const to = new Date().toISOString().slice(0, 10);
          url +=
            "discover/movie?language=en-US&include_adult=false&sort_by=popularity.desc" +
            "&with_genres=" + encodeURIComponent(genre.tmdb) +
            "&primary_release_date.gte=" + from +
            "&primary_release_date.lte=" + to + "&";
        } else {
          url += "movie/now_playing?language=en-US&page=1&";
        }
        const json = await timedFetch(url + "api_key=" + encodeURIComponent(TMDB_API_KEY), "json");
        const list = (json.results || [])
          .filter((m) => m && m.title)
          .map((m) => ({
            title: m.title,
            year: (m.release_date || "").slice(0, 4),
            released: m.release_date || "",
            poster: m.poster_path ? "https://image.tmdb.org/t/p/w154" + m.poster_path : "",
          }));
        if (list.length) return list.slice(0, limit);
      } catch (e) {}
    }

    const suffix = (genre ? "genre=" + genre.itunes + "/" : "") + "json";
    const urls = [
      `https://itunes.apple.com/us/rss/topmovies/limit=${limit}/${suffix}`,
      `https://ax.itunes.apple.com/WebObjects/MZStoreServices.woa/ws/RSS/topMovies/limit=${limit}/${suffix}`,
    ];
    let lastErr = null;
    for (const url of urls) {
      try {
        const json = await timedFetch(url, "json");
        const entries = json?.feed?.entry;
        const list = (Array.isArray(entries) ? entries : entries ? [entries] : [])
          .filter((e) => e?.["im:name"]?.label)
          .map((e) => {
            const imgs = e["im:image"];
            const released = (e["im:releaseDate"]?.label || "").slice(0, 10);
            return {
              title: e["im:name"].label,
              year: released.slice(0, 4),
              released,
              poster: Array.isArray(imgs) && imgs.length ? imgs[imgs.length - 1].label || "" : "",
            };
          });
        if (list.length) return list.slice(0, limit);
      } catch (e) {
        lastErr = e;
      }
    }
    throw lastErr || new Error("No movies");
  }

  const getMovies = (key, genre, limit) =>
    cached("movies:" + key, CACHE_TTL, () => fetchMovieList(genre, limit));

  function pickNewRelease(list) {
    const today = new Date().toISOString().slice(0, 10);
    const dated = list
      .filter((m) => m.released && m.released <= today)
      .sort((a, b) => (a.released < b.released ? 1 : -1));
    return dated[0] || list[0];
  }

  function renderNewRelease(slot, list) {
    const movie = pickNewRelease(list);
    const promo = h("div", "md-promo");

    if (movie.poster) {
      const poster = icon(movie.poster, "md-movie-poster");
      poster.title = movie.title;
      poster.addEventListener("error", () => (poster.style.visibility = "hidden"));
      poster.addEventListener("click", () => {
        playClick();
        openTab(movieTrailerUrl(movie.title));
      });
      promo.appendChild(poster);
    }

    const headline = h("p", "md-promo-headline");
    headline.append(h("span", "md-movie-label", "New Release: "), movie.title);

    const links = h("div", "md-links");
    links.append(
      createLink("Watch Trailer", () => openTab(movieTrailerUrl(movie.title))),
      createLink("View Clip", () => openTab(movieClipUrl(movie.title)))
    );

    const text = h("div", "md-promo-text");
    text.append(headline, links);
    promo.appendChild(text);
    slot.appendChild(promo);
  }

  function renderMovieList(slot, movies) {
    renderNumberedList(
      slot,
      movies.slice(0, MOVIES_TOP_COUNT).map((m) => ({
        title: m.title,
        note: m.year ? ` (${m.year})` : "",
        tooltip: "Watch trailer: " + m.title,
        onClick: () => openTab(movieTrailerUrl(m.title)),
      }))
    );
  }

  const loadMovieList = (slot, key, genre, limit, error) =>
    loadInto(slot, { fetch: () => getMovies(key, genre, limit), render: renderMovieList, error });

  function buildSearchMovies() {
    const wrap = h("div", "md-section");
    wrap.append(
      h("p", "md-list-title", "Search Movies"),
      createSearchRow((query) => openTab(MOVIE_SEARCH_URL + encodeURIComponent(query)), {
        placeholder: "Enter Title...",
      }).row
    );
    return wrap;
  }

  function fillMovies(body) {
    const newRelease = createSlotSection();
    const top = createSlotSection("Top Movie Trailers");

    body.append(
      newRelease.wrap,
      top.wrap,
      buildGenreList("Browse Trailers by Genre", MOVIE_GENRES, (genre, slot) =>
        loadMovieList(slot, "genre-" + genre.itunes, genre, MOVIES_TOP_COUNT, "Trailers are unavailable.")
      ),
      buildSearchMovies(),
      createGoLink("More Movies and Trailers...", MORE_MOVIES_URL)
    );

    loadInto(newRelease.slot, {
      fetch: () => getMovies("top", null, 10),
      render: renderNewRelease,
      error: "New release is unavailable.",
    });
    loadMovieList(top.slot, "top", null, 10, "Trailers are unavailable.");
  }

  const xmlText = (node, tagName) => (node.getElementsByTagName(tagName)[0]?.textContent || "").trim();

  function extractItemImage(node) {
    const fromAttr = (tag, test) => {
      for (const el of node.getElementsByTagName(tag)) {
        const url = el.getAttribute("url");
        if (url && (!test || test(el))) return url;
      }
      return "";
    };

    let url =
      fromAttr(
        "media:content",
        (el) => (el.getAttribute("medium") || "image") === "image" && !/video/.test(el.getAttribute("type") || "")
      ) ||
      fromAttr("media:thumbnail") ||
      fromAttr("enclosure", (el) => /^image\//.test(el.getAttribute("type") || ""));

    if (!url) {
      const markup = xmlText(node, "content:encoded") || xmlText(node, "description");
      const img = markup && new DOMParser().parseFromString(markup, "text/html").querySelector("img[src]");
      if (img) url = img.getAttribute("src");
    }

    url = url.replace(/^http:\/\//, "https://");
    return url.startsWith("https://") ? url : "";
  }

  function parseFeedItems(xml, sourceName) {
    const doc = new DOMParser().parseFromString(xml, "text/xml");
    if (doc.querySelector("parsererror")) throw new Error("Bad RSS");

    const items = [];
    for (const node of doc.querySelectorAll("item")) {
      let title = xmlText(node, "title");
      const link = xmlText(node, "link");
      if (!title || !link) continue;

      const source = xmlText(node, "source") || sourceName;
      if (source && title.endsWith(" - " + source)) title = title.slice(0, -(source.length + 3));

      items.push({ title, link, source, image: extractItemImage(node) });
    }
    return items;
  }

  const getTodayStory = () =>
    cached("today-story", TODAY_TTL, async () => {
      const results = await Promise.allSettled(
        TODAY_FEEDS.map(async (feed) => parseFeedItems(await timedFetch(feed.url, "text"), feed.name))
      );
      const lists = results.filter((r) => r.status === "fulfilled").map((r) => r.value);

      let item = null;
      for (const list of lists) {
        item = list.find((it) => it.image);
        if (item) break;
      }
      if (!item) item = lists.find((l) => l.length)?.[0] || null;
      if (!item) item = parseFeedItems(await timedFetch(TODAY_NEWS_URL, "text"), "")[0] || null;
      if (!item) throw new Error("No headlines");
      return item;
    });

  function renderTodayStory(slot, item) {
    if (item.image) {
      const img = icon(item.image, "md-today-img");
      img.title = item.title;
      img.addEventListener("error", () => (img.style.display = "none"));
      img.addEventListener("click", () => openTab(item.link));
      slot.appendChild(img);
    }

    const headline = createLink(item.title, () => openTab(item.link), "md-today-headline");
    if (item.source) headline.title = item.source;
    slot.appendChild(headline);

    const quality = h("p", "md-today-quality");
    ["56k", "100k", "300k"].forEach((label, i) => {
      if (i) quality.append(" | ");
      quality.appendChild(createLink(label));
    });
    slot.appendChild(quality);
  }

  const getTodayLists = async () => {
    const [music, movies] = await Promise.allSettled([
      getTopTracks().then((tracks) =>
        tracks.slice(0, 5).map((t) => ({ label: t.title, query: t.artist ? `${t.artist} ${t.title}` : t.title }))
      ),
      getMovies("top", null, 10).then((list) => list.slice(0, 5).map((m) => ({ label: m.title, query: m.title }))),
    ]);
    const data = {
      music: music.status === "fulfilled" && music.value.length ? music.value : null,
      movies: movies.status === "fulfilled" ? movies.value : null,
    };
    if (!data.music && !data.movies) throw new Error("No featured links");
    return data;
  };

  function renderTodayLists(slot, data) {
    const addGroup = (heading, entries, suffix) => {
      if (!entries?.length) return;
      slot.appendChild(h("p", "md-list-title", heading));

      const list = h("div", "md-today-list");
      for (const entry of entries) {
        list.appendChild(
          createLink(
            entry.label,
            () => {
              playClick();
              openTab(TRAILER_SEARCH_URL + encodeURIComponent(entry.query + " " + suffix));
            },
            "md-today-list-link"
          )
        );
      }
      slot.appendChild(list);
    };

    addGroup("Music Videos:", data.music, "official music video");
    addGroup("Movie Previews:", data.movies, "official trailer");
  }

  function fillToday(body) {
    const story = h("div", "md-today-story");
    const lists = h("div", "md-today-lists");

    const findMedia = createSearchRow(
      (query) => openWebLinkIn(MEDIA_SEARCH_URL + encodeURIComponent(query), "window"),
      { placeholder: "Find Media", compact: false }
    );

    body.append(story, findMedia.row, lists, createGoLink("More Audio and Video...", MORE_MEDIA_URL));

    loadInto(story, {
      fetch: getTodayStory,
      render: renderTodayStory,
      error: "Headlines are unavailable.",
    });
    loadInto(lists, {
      fetch: getTodayLists,
      render: renderTodayLists,
      error: "Featured links are unavailable.",
    });
  }

  function fillMediaPlaces(body) {
    const places = [
      { text: "My Music", icon: "mymusic.png", action: selectAndPlayAudio },
      { text: "My Videos", icon: "myvideos.png", action: selectAndPlayVideo },
      { text: "More Media", icon: "moremedia.png", action: () => openTab("https://wmpskinsarchive.neocities.org/") },
      { text: "Radio Guide", icon: "radioguide.png", action: () => openTab(SHOUTCAST_URL) },
    ];

    const container = h("div", "md-places-container");
    for (const place of places) {
      const row = h("div", "md-places-item");
      row.append(icon(mediaURL(place.icon), "md-places-icon"), h("span", "md-places-label", place.text));
      row.addEventListener("click", () => {
        playClick();
        place.action();
      });
      container.appendChild(row);
    }
    body.appendChild(container);
  }

  const clamp01 = (n) => Math.max(0, Math.min(1, n));

  function createHit(className, title, disabled = false) {
    const btn = createButton("md-hit " + className);
    if (title) btn.title = title;
    btn.disabled = disabled;
    return btn;
  }

  function buildPlayer(container) {
    const videoContainer = h("div", "md-video-container");
    video = h("video", "md-video-element");
    videoContainer.appendChild(video);
    container.appendChild(videoContainer);
    setVideoScreenVisible = (visible) => videoContainer.classList.toggle("active", visible);

    const player = h("div", "md-player");
    player.appendChild(icon(mediaURL("Layout.png"), "md-player-img"));

    const mediaOptions = h("div", "md-media-options");
    mediaOptions.append(
      h("span", "md-media-options-text", "Media Options"),
      icon(mediaURL("alltabs.png"), "md-media-options-arrow")
    );
    player.append(mediaOptions, icon(mediaURL("redirect.png"), "md-redirect-btn"));

    const playBtn = createHit("md-hit-play", "Play");
    const stopBtn = createHit("md-hit-stop", "Stop", true);
    const prevBtn = createHit("md-hit-prev", null, true);
    const nextBtn = createHit("md-hit-next", null, true);

    setPlayingState = (isPlaying) => {
      playBtn.classList.toggle("playing", isPlaying);
      playBtn.title = isPlaying ? "Pause" : "Play";
      stopBtn.classList.toggle("active", isPlaying);
      stopBtn.disabled = !isPlaying;
    };

    playBtn.addEventListener("click", () => {
      playClick();
      if (!activeMedia.src) {
        selectAndPlayAudio();
      } else if (activeMedia.paused) {
        activeMedia.play();
        setPlayingState(true);
      } else {
        activeMedia.pause();
        setPlayingState(false);
      }
    });

    stopBtn.addEventListener("click", () => {
      if (stopBtn.disabled) return;
      playClick();
      stopAllMedia();
    });

    player.append(playBtn, stopBtn, prevBtn, nextBtn);

    const durationBar = h("div", "md-duration-bar");
    durationBar.appendChild(icon(mediaURL("durationbar.png"), "md-duration-img"));
    player.appendChild(durationBar);

    const seekSlider = h("div", "md-seek-slider");
    const seekFill = icon(mediaURL("seekbar.png"), "md-seek-fill");
    const seekThumb = h("div", "md-seek-thumb");
    seekSlider.append(seekFill, seekThumb);
    player.appendChild(seekSlider);

    let isSeeking = false;

    const updateSeekVisual = (percent) => {
      seekFill.style.clipPath = `inset(0 ${100 - percent * 100}% 0 0)`;
      seekThumb.style.left = `${percent * 100}%`;
    };

    function seekFromEvent(e) {
      const rect = seekSlider.getBoundingClientRect();
      const percent = clamp01((e.clientX - rect.left) / rect.width);
      updateSeekVisual(percent);
      if (Number.isFinite(activeMedia.duration) && activeMedia.duration > 0) {
        activeMedia.currentTime = percent * activeMedia.duration;
      }
    }

    seekSlider.addEventListener("mousedown", (e) => {
      isSeeking = true;
      if (e.target === seekThumb) seekThumb.classList.add("active");
      seekFromEvent(e);
    });

    for (const media of [audio, video]) {
      media.addEventListener("timeupdate", () => {
        if (media === activeMedia && !isSeeking && Number.isFinite(media.duration) && media.duration > 0) {
          updateSeekVisual(media.currentTime / media.duration);
        }
      });
      media.addEventListener("ended", () => {
        if (media === activeMedia) {
          setPlayingState(false);
          updateSeekVisual(0);
        }
      });
    }

    const volumeBar = h("div", "md-volume-bar");
    volumeBar.appendChild(icon(mediaURL("volumebar.png"), "md-volume-img"));
    player.appendChild(volumeBar);

    const volumeSlider = h("div", "md-volume-slider");
    const volumeFill = icon(mediaURL("volume.png"), "md-volume-fill");
    const volumeThumb = icon(mediaURL("volume-changer.png"), "md-volume-thumb");
    volumeSlider.append(volumeFill, volumeThumb);

    const volBtn = createHit("md-hit-volume", "Mute");
    let isDraggingVol = false;
    let lastVolumePercent = 1;

    function updateVolumeVisual(percent) {
      volumeFill.style.clipPath = `inset(0 ${100 - percent * 100}% 0 0)`;
      volumeThumb.style.left = `${percent * 100}%`;
      audio.volume = percent;
      video.volume = percent;
    }

    function volumeFromEvent(e) {
      const rect = volumeSlider.getBoundingClientRect();
      lastVolumePercent = clamp01((e.clientX - rect.left) / rect.width);
      updateVolumeVisual(lastVolumePercent);
    }

    volBtn.addEventListener("click", () => {
      playClick();
      const isMuted = volBtn.classList.toggle("muted");
      audio.muted = isMuted;
      video.muted = isMuted;
      updateVolumeVisual(isMuted ? 0 : lastVolumePercent);
    });

    volumeSlider.addEventListener("mousedown", (e) => {
      if (volBtn.classList.contains("muted")) return;
      isDraggingVol = true;
      volumeFromEvent(e);
    });

    player.append(volBtn, volumeSlider);

    window.addEventListener("mousemove", (e) => {
      if (isSeeking) seekFromEvent(e);
      if (isDraggingVol && !volBtn.classList.contains("muted")) volumeFromEvent(e);
    });
    window.addEventListener("mouseup", () => {
      isSeeking = false;
      isDraggingVol = false;
      seekThumb.classList.remove("active");
    });

    container.appendChild(player);
  }

  function makeAccordion(title, startOpen, fill) {
    const section = h("div", "md-accordion" + (startOpen ? " md-open" : ""));

    const header = h("div", "md-accordion-header");
    header.appendChild(h("span", "md-accordion-title", title));

    const content = h("div", "md-accordion-content");
    const body = h("div", "md-accordion-body");
    body.appendChild(content);
    section.append(header, body);

    const ensureFilled = () => {
      if (body.dataset.filled) return;
      body.dataset.filled = "1";
      fill(content);
    };
    if (startOpen) ensureFilled();

    header.addEventListener("click", () => {
      const opening = !section.classList.contains("md-open");
      section.classList.toggle("md-open", opening);
      if (opening) ensureFilled();
      playClick();
    });

    return section;
  }

  function setMediaButtonOpen(isOpen) {
    const btn = document.getElementById("ie6-media-button");
    if (!btn) return;
    if (isOpen) btn.setAttribute("open", "true");
    else btn.removeAttribute("open");
  }

  function hideSidebar() {
    stopAllMedia();
    sidebar.hidden = true;
    setMediaButtonOpen(false);
  }

  function ensureSidebar() {
    if (sidebar) return sidebar;

    sidebar = document.createXULElement("vbox");
    sidebar.id = "ie6-media-sidebar";
    sidebar.className = "sb-panel";
    sidebar.hidden = true;

    const closeBtn = icon(iconURL("close.png"), "sb-flatbtn sb-close-btn");
    closeBtn.title = "Close";
    closeBtn.addEventListener("click", hideSidebar);
    const titlebar = h("div", "sb-titlebar");
    titlebar.append(h("span", null, "Media"), closeBtn);

    const banner = h("div", "md-banner");
    banner.appendChild(icon(iconURL("wmc.png"), "md-banner-img"));

    const footer = h("div", "md-footer");
    footer.append(
      createLink("Privacy Statement"),
      h("p", "md-copyright", "\u00A9 2001 Microsoft Corporation."),
      h("p", "md-copyright", "All rights reserved.")
    );

    const bodyWrap = h("div", "md-list");
    bodyWrap.append(
      banner,
      makeAccordion("Today", true, fillToday),
      makeAccordion("Music", false, fillMusic),
      makeAccordion("Movies", false, fillMovies),
      makeAccordion("Radio", false, fillRadio),
      makeAccordion("MSN Music", false, fillMsnMusic),
      makeAccordion("Media Places", false, fillMediaPlaces),
      footer
    );
    bodyWrap.addEventListener(
      "click",
      (e) => {
        if (e.target.closest(".md-link")) playClick();
      },
      true
    );

    const listWrap = h("div", "md-list-wrap");
    listWrap.appendChild(bodyWrap);
    sidebar.append(titlebar, listWrap);
    buildPlayer(sidebar);

    const browserBox = document.getElementById("browser");
    browserBox.insertBefore(sidebar, browserBox.firstChild);

    window.__ie6Sidebars ||= {
      panels: {},
      register(id, hideFn) {
        this.panels[id] = hideFn;
      },
      closeOthers(exceptId) {
        for (const [id, hideFn] of Object.entries(this.panels)) {
          if (id !== exceptId) hideFn();
        }
      },
    };
    window.__ie6Sidebars.register("media", hideSidebar);

    return sidebar;
  }

  function toggleMediaSidebar() {
    ensureSidebar();
    if (!sidebar.hidden) return hideSidebar();

    window.__ie6Sidebars?.closeOthers("media");
    sidebar.hidden = false;
    setMediaButtonOpen(true);
  }

  window.ie6ToggleMediaSidebar = toggleMediaSidebar;
})();