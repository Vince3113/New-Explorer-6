(() => {
  "use strict";

  if (location.href !== "chrome://browser/content/browser.xhtml") return;
  if (window.IE6InfoBar) return;

  const XHTML = "http://www.w3.org/1999/xhtml";
  const OPTIONS_SUFFIX = " Click here for options...";
  const STATUSBAR_HEIGHT = 23;
  const CLOSE_ICON = "resource://ie6theme/images/close.png";
  const SOUND_URL = "resource://ie6theme/sounds/information.wav";
  const PLAY_SOUND = true;
  const NO_SOUND_TYPES = ["popup-blocked"];
  const DIALOG_URL = "chrome://userscripts/content/information-bar-dialog.xhtml";
  const DIALOG_WINDOWTYPE = "ie6theme:information-bar-dialog";
  const PREF_HIDE_DIALOG = "extensions.ie6theme.infobar.hideDialog";
  const root = document.documentElement;

  function create(tag, className, text) {
    const el = document.createElementNS(XHTML, tag);
    if (className) el.className = className;
    if (text != null) el.textContent = text;
    return el;
  }

  const bar = create("div");
  bar.id = "info-bar";
  bar.hidden = true;

  const closeBarBtn = create("img", "info-closebar");
  closeBarBtn.src = CLOSE_ICON;
  closeBarBtn.draggable = false;
  const closeCol = create("div", "info-close-col");
  closeCol.append(closeBarBtn);

  const list = create("div", "info-list");
  bar.append(closeCol, list);

  const entries = new Map();
  let menu = null;
  let collapsed = false;

  function getText(n) {
    const text = n.messageText?.textContent || n.getAttribute("label") || n.label || "";
    return String(text).replace(/\s+/g, " ").trim();
  }

  function getButtons(n) {
    const buttons = n.buttonContainer
      ? n.buttonContainer.querySelectorAll("button")
      : n.querySelectorAll("button.notification-button");
    return [...buttons].filter((b) => !b.classList.contains("close-icon"));
  }

  function isShown(n) {
    if (typeof n.checkVisibility === "function") return n.checkVisibility({ checkVisibilityCSS: true });
    return n.getClientRects().length > 0;
  }

  const notifType = (n) => n.getAttribute("value") || n.value || "";

  function dismiss(n) {
    try {
      if (typeof n.dismiss === "function") n.dismiss();
      else if (typeof n.close === "function") n.close();
    } catch {}

    setTimeout(() => {
      if (!n.isConnected) return;
      try {
        const box = n.control || n.closest("notificationbox");
        if (box?.removeNotification) box.removeNotification(n, true);
        else n.remove();
      } catch {
        n.remove();
      }
    }, 250);
  }

  function hideMenu() {
    menu?.remove();
    menu = null;
  }

  function showMenu(n, row) {
    hideMenu();
    const buttons = getButtons(n);
    if (!buttons.length) return;

    menu = create("div", "info-menu");
    for (const button of buttons) {
      const label = String(button.label || button.textContent || "").trim();
      const item = create("div", "info-menu-item", label);
      item.addEventListener("click", (e) => {
        e.stopPropagation();
        hideMenu();
        button.click();
      });
      menu.append(item);
    }
    root.append(menu);

    const rect = row.getBoundingClientRect();
    menu.style.setProperty("left", Math.max(0, Math.round(rect.left + 22)) + "px", "important");
    menu.style.setProperty("bottom", Math.round(window.innerHeight - rect.top) + "px", "important");
  }

  async function playSound() {
    if (!PLAY_SOUND) return;
    try {
      await new Audio(SOUND_URL).play();
    } catch (e) {}
  }

  function maybeShowDialog() {
    try {
      if (Services.prefs.getBoolPref(PREF_HIDE_DIALOG, false)) return;
      if (Services.wm.getMostRecentWindow(DIALOG_WINDOWTYPE)) return;
      window.openDialog(DIALOG_URL, "", "chrome,dialog=yes,centerscreen,dependent,resizable=no");
    } catch (e) {}
  }

  function sync(n) {
    const entry = entries.get(n);
    if (!entry) return;

    const hasButtons = getButtons(n).length > 0;
    entry.textEl.textContent = getText(n) + (hasButtons ? OPTIONS_SUFFIX : "");
    entry.closeEl.style.visibility = n.querySelector(".close-icon")?.hidden ? "hidden" : "";
  }

  function add(n, silent = false) {
    if (entries.has(n) || n.localName !== "notification-message") return;
    n.setAttribute("info-mirrored", "");

    const row = create("div", "info-item");
    const textEl = create("div", "info-text");
    const closeEl = create("div", "info-close");
    closeEl.title = "Close";
    row.append(create("div", "info-icon"), textEl, closeEl);

    textEl.addEventListener("click", (e) => {
      if (!getButtons(n).length) return;
      e.stopPropagation();
      showMenu(n, row);
    });

    closeEl.addEventListener("click", (e) => {
      e.stopPropagation();
      hideMenu();
      dismiss(n);
    });

    const mo = new MutationObserver(() => sync(n));
    mo.observe(n, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: ["label", "message", "hidden"],
    });

    entries.set(n, { row, textEl, closeEl, mo });
    list.append(row);
    sync(n);
    collapsed = false;

    if (silent) return;
    setTimeout(() => {
      if (!n.isConnected || !isShown(n)) return;
      if (!NO_SOUND_TYPES.includes(notifType(n))) playSound();
      maybeShowDialog();
    }, 100);
  }

  function remove(n) {
    const entry = entries.get(n);
    if (!entry) return;
    entry.mo.disconnect();
    entry.row.remove();
    entries.delete(n);
  }

  const watched = new Map();

  function watch(el) {
    if (!el || watched.has(el)) return;
    const observer = new MutationObserver(reposition);
    observer.observe(el, { attributes: true, attributeFilter: ["style", "hidden", "class"] });
    watched.set(el, observer);
  }

  function reposition() {
    const dev = document.getElementById("dev-bar");
    const tip = document.getElementById("tip-bar");
    watch(dev);
    watch(tip);

    let bottom = STATUSBAR_HEIGHT;
    if (dev && !dev.hidden && dev.getBoundingClientRect().height > 0) {
      bottom = Math.max(bottom, Math.round(window.innerHeight - dev.getBoundingClientRect().top));
    } else if (tip && !tip.hidden) {
      bottom += tip.offsetHeight;
    }
    bar.style.setProperty("bottom", bottom + "px", "important");
  }

  function refresh() {
    for (const n of [...entries.keys()]) {
      if (!n.isConnected) remove(n);
    }

    let anyShown = false;
    for (const [n, entry] of entries) {
      const shown = isShown(n);
      entry.row.hidden = !shown;
      if (shown) anyShown = true;
    }

    bar.hidden = collapsed || !anyShown || window.fullScreen;
    if (bar.hidden) hideMenu();
    reposition();
  }

  let refreshScheduled = false;
  function scheduleRefresh() {
    if (refreshScheduled) return;
    refreshScheduled = true;
    requestAnimationFrame(() => {
      refreshScheduled = false;
      refresh();
    });
  }

  function scan(node) {
    if (node.nodeType !== 1) return;
    if (node.localName === "notification-message") add(node);
    else node.querySelectorAll?.("notification-message").forEach((n) => add(n));
  }

  function init() {
    root.append(bar);

    closeBarBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      collapsed = true;
      refresh();
    });

    document.querySelectorAll("notification-message").forEach((n) => add(n, true));

    new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) scan(node);
      }
      scheduleRefresh();
    }).observe(root, { childList: true, subtree: true });

    window.gBrowser?.tabContainer?.addEventListener("TabSelect", () => {
      hideMenu();
      setTimeout(refresh, 50);
    });

    window.addEventListener("resize", refresh);
    window.addEventListener("fullscreen", refresh);
    window.addEventListener("blur", hideMenu);
    window.addEventListener(
      "mousedown",
      (e) => {
        if (menu && !menu.contains(e.target)) hideMenu();
      },
      true
    );
    window.addEventListener(
      "keydown",
      (e) => {
        if (e.key === "Escape") hideMenu();
      },
      true
    );

    setInterval(() => {
      if (!bar.hidden) reposition();
    }, 1000);
    refresh();
  }

  window.IE6InfoBar = { refresh, reposition };

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();