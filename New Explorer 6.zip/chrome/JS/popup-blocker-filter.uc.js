(function () {
  const PREF_LEVEL = "extensions.ie6theme.popupblocker.filterLevel";
  const PREF_BLOCK = "dom.disable_open_during_load";
  const busy = new WeakSet();

  function willAutoAllow(browser) {
    try {
      return (
        Services.prefs.getBoolPref(PREF_BLOCK, true) &&
        Services.prefs.getCharPref(PREF_LEVEL, "medium") === "low" &&
        !!browser.currentURI &&
        browser.currentURI.schemeIs("https")
      );
    } catch (e) {
      return false;
    }
  }

  window.ie6PopupFilter = { willAutoAllow };

  window.addEventListener(
    "DOMUpdateBlockedPopups",
    (e) => {
      const browser = e.target;
      if (!willAutoAllow(browser) || busy.has(browser)) return;
      busy.add(browser);
      try {
        const blocker = browser.popupBlocker;
        for (let i = blocker.getBlockedPopupCount() - 1; i >= 0; i--) blocker.unblockPopup(i);
      } catch (err) {
      } finally {
        busy.delete(browser);
      }
    },
    true
  );
})();