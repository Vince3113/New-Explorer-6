(function () {
  const PREF_BLOCKER = "dom.disable_open_during_load";
  const WINDOWS_UPDATE_PATH = "C:\\WINDOWS\\Modding\\Update\\wumgr.exe";

  function newFile(path) {
    const file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
    file.initWithPath(path);
    return file;
  }

  function runProcess(exe, args = []) {
    const process = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
    process.init(exe);
    process.run(false, args, args.length);
  }

  function makeSubmenu(id, label, accesskey, itemDefs) {
    const menu = document.createXULElement("menu");
    menu.id = id;
    menu.setAttribute("label", label);
    menu.setAttribute("accesskey", accesskey);
    const popup = document.createXULElement("menupopup");
    popup.id = id + "-popup";
    for (const { label: itemLabel, accesskey: itemKey, command } of itemDefs) {
      const item = document.createXULElement("menuitem");
      item.setAttribute("label", itemLabel);
      item.setAttribute("accesskey", itemKey);
      item.addEventListener("command", command);
      popup.appendChild(item);
    }
    menu.appendChild(popup);
    return menu;
  }

  function makeItem(id, label, accesskey, command) {
    const item = document.createXULElement("menuitem");
    item.id = id;
    item.setAttribute("label", label);
    item.setAttribute("accesskey", accesskey);
    item.addEventListener("command", command);
    return item;
  }

  function getActiveTabInfo() {
    const browser = window.gBrowser.selectedBrowser;
    return {
      url: browser.currentURI ? browser.currentURI.spec : "",
      title: window.gBrowser.selectedTab.label || browser.contentTitle || "",
    };
  }

  function openMailto({ subject = "", body = "" } = {}) {
    try {
      const params = [];
      if (subject) params.push("subject=" + encodeURIComponent(subject));
      if (body) params.push("body=" + encodeURIComponent(body));
      const uri = Services.io.newURI("mailto:" + (params.length ? "?" + params.join("&") : ""));
      Cc["@mozilla.org/uriloader/external-protocol-service;1"]
        .getService(Ci.nsIExternalProtocolService)
        .loadURI(uri);
    } catch (e) {}
  }

  function openMailApp() {
    if (Services.appinfo.OS === "WINNT") {
      try {
        const regKey = Cc["@mozilla.org/windows-registry-key;1"].createInstance(Ci.nsIWindowsRegKey);
        regKey.open(
          Ci.nsIWindowsRegKey.ROOT_KEY_CLASSES_ROOT,
          "mailto\\shell\\open\\command",
          Ci.nsIWindowsRegKey.ACCESS_READ
        );
        const command = regKey.readStringValue("");
        regKey.close();

        const match = command.match(/^"([^"]+)"/) || command.match(/^(\S+)/);
        if (match) {
          const exe = newFile(match[1]);
          if (exe.exists()) {
            runProcess(exe);
            return;
          }
        }
      } catch (e) {}
    }
    openMailto();
  }

  function openSendLink() {
    const { url, title } = getActiveTabInfo();
    openMailto({ subject: title, body: url });
  }

  function openSendPage() {
    const { url, title } = getActiveTabInfo();
    openMailto({ subject: title, body: `${title}\n${url}` });
  }

  function openWindowsUpdate() {
    try {
      const exe = newFile(WINDOWS_UPDATE_PATH);
      if (!exe.exists()) return;
      runProcess(exe);
    } catch (e) {}
  }

  function openInternetOptions() {
    if (Services.appinfo.OS !== "WINNT") return;
    try {
      const rundll32 = Services.dirsvc.get("SysD", Ci.nsIFile).clone();
      rundll32.append("rundll32.exe");
      runProcess(rundll32, ["shell32.dll,Control_RunDLL", "inetcpl.cpl"]);
    } catch (e) {}
  }

  const isBlockerOn = () => Services.prefs.getBoolPref(PREF_BLOCKER, true);

  function togglePopupBlocker() {
    Services.prefs.setBoolPref(PREF_BLOCKER, !isBlockerOn());
  }

  function openPopupBlockerSettings() {
    const existing = Services.wm.getMostRecentWindow("ie6-popupblocker-settings");
    if (existing) {
      existing.focus();
      return;
    }
    window.openDialog(
      "chrome://userscripts/content/popup-blocker-settings.xhtml",
      "_blank",
      "chrome,dialog,centerscreen,resizable=no"
    );
  }

  function init() {
    const popup = document.getElementById("menu_ToolsPopup");
    if (!popup || document.getElementById("ie6-tools-mailnews")) return;

    const mailNews = makeSubmenu("ie6-tools-mailnews", "Mail and News", "M", [
      { label: "Read Mail", accesskey: "R", command: openMailApp },
      { label: "New Message...", accesskey: "N", command: () => openMailto() },
      { label: "Send a Link...", accesskey: "L", command: openSendLink },
      { label: "Send Page...", accesskey: "P", command: openSendPage },
    ]);
    const popupBlocker = makeSubmenu("ie6-tools-popupblocker", "Pop-up Blocker", "P", [
      { label: "Turn Off Pop-up Blocker", accesskey: "T", command: togglePopupBlocker },
      { label: "Pop-up Blocker Settings...", accesskey: "S", command: openPopupBlockerSettings },
    ]);
    popup.insertBefore(popupBlocker, popup.firstChild);
    popup.insertBefore(mailNews, popup.firstChild);

    const [toggleItem, settingsItem] = popupBlocker.querySelectorAll("menupopup > menuitem");
    popupBlocker.querySelector("menupopup").addEventListener("popupshowing", () => {
      const on = isBlockerOn();
      toggleItem.setAttribute("label", on ? "Turn Off Pop-up Blocker" : "Turn On Pop-up Blocker");
      if (on) settingsItem.removeAttribute("disabled");
      else settingsItem.setAttribute("disabled", "true");
    });

    const manageExtensions = document.querySelector('#menu_ToolsPopup menuitem[label="Manage Extensions"]');
    const downloads = document.getElementById("menu_openDownloads");
    if (manageExtensions && downloads && downloads.nextSibling) {
      popup.insertBefore(manageExtensions, downloads.nextSibling);
    }

    const winUpdate = makeItem("ie6-tools-windowsupdate", "Windows Update", "U", openWindowsUpdate);
    const syncAnchor =
      document.getElementById("sync-reauthitem") ||
      document.getElementById("sync-syncnowitem") ||
      document.getElementById("sync-syncnow") ||
      document.getElementById("sync-enable");
    if (syncAnchor && syncAnchor.nextSibling) popup.insertBefore(winUpdate, syncAnchor.nextSibling);
    else popup.appendChild(winUpdate);

    popup.appendChild(makeItem("ie6-tools-internetoptions", "Internet Options...", "O", openInternetOptions));
  }

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();