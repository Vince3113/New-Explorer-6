(function () {
  if (location.href !== "chrome://browser/content/browser.xhtml") return;

  const { CustomizableUI } = ChromeUtils.importESModule(
    "moz-src:///browser/components/customizableui/CustomizableUI.sys.mjs"
  );

  const BUTTON_ID = "ie6-add-separator-button";

  function init() {
    if (!CustomizableUI.__separatorSwapListenerAdded) {
      CustomizableUI.addListener({
        onWidgetAdded(widgetId, area, position) {
          if (widgetId !== BUTTON_ID) return;
          try {
            CustomizableUI.removeWidgetFromArea(BUTTON_ID);
            CustomizableUI.addWidgetToArea("separator", area, position);
          } catch (e) {}
        },
      });
      CustomizableUI.__separatorSwapListenerAdded = true;
    }

    try {
      CustomizableUI.createWidget({
        id: BUTTON_ID,
        type: "button",
        label: "Separador",
        tooltiptext: "Arrastrá esto a una barra para agregar un separador estilo IE6",
        onCreated(node) {
          node.classList.add("ie6-add-separator-btn");
        },
        onCommand() {
          try {
            const placement = CustomizableUI.getPlacementOfWidget(BUTTON_ID);
            CustomizableUI.addWidgetToArea("separator", placement ? placement.area : "nav-bar");
          } catch (e) {}
        },
      });
    } catch (e) {}
  }

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();