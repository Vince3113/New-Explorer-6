(function () {
  try {
    if (document.getElementById("ie6-tabscroll-left")) return;

    const XHTML = "http://www.w3.org/1999/xhtml";
    const CLICK_STEP_PX = 160;
    const HOLD_DELAY_MS = 160;
    const SPEED_MIN_PX_S = 700;
    const SPEED_MAX_PX_S = 2400;
    const SPEED_RAMP_MS = 900;
    const PLUS_WIDTH_PX = 20;
    const FOLLOW_MS = 350;

    const tabs = gBrowser.tabContainer;
    const asb = document.getElementById("tabbrowser-arrowscrollbox") || tabs.arrowScrollbox;
    const toolbar = document.getElementById("TabsToolbar");

    if (!tabs || !asb || !toolbar) return;

    function makeButton(id, label) {
      const btn = document.createXULElement("hbox");
      btn.id = id;
      btn.setAttribute("align", "center");
      btn.setAttribute("pack", "center");
      btn.setAttribute("aria-label", label);
      btn.hidden = true;
      return btn;
    }

    function addGlyph(btn) {
      const glyph = document.createXULElement("hbox");
      glyph.className = "ie6-tabbtn-glyph";
      btn.appendChild(glyph);
    }

    function openNewTab() {
      if (window.BrowserCommands?.openTab) BrowserCommands.openTab();
      else BrowserOpenTab();
    }

    const left = makeButton("ie6-tabscroll-left", "Scroll tabs left");
    const right = makeButton("ie6-tabscroll-right", "Scroll tabs right");
    const plusEnd = makeButton("ie6-newtab-end", "New Tab");
    const plusInline = makeButton("ie6-newtab-inline", "New Tab");
    addGlyph(left);
    addGlyph(right);

    tabs.parentNode.insertBefore(left, tabs);
    tabs.after(right, plusEnd);
    tabs.parentNode.appendChild(plusInline);

    for (const plus of [plusEnd, plusInline]) {
      plus.addEventListener("mousedown", (e) => {
        if (e.button !== 0) return;
        e.preventDefault();
        openNewTab();
      });
    }

    function lastRealTab() {
      const list = gBrowser.tabs;
      for (let i = list.length - 1; i >= 0; i--) {
        if (!list[i].closing && !list[i].hidden) return list[i];
      }
      return null;
    }

    let lastX = null;
    let lastY = null;

    function positionInline() {
      if (plusInline.hidden) return;
      const last = lastRealTab();
      if (!last) return;
      const r = last.getBoundingClientRect();
      if (r.width <= 0) return;
      const t = tabs.getBoundingClientRect();
      const x = Math.round(Math.min(r.right, t.right - PLUS_WIDTH_PX));
      const y = Math.round(t.top);
      if (x !== lastX) {
        plusInline.style.left = x + "px";
        lastX = x;
      }
      if (y !== lastY) {
        plusInline.style.top = y + "px";
        lastY = y;
      }
    }

    let rafId = 0;
    let until = 0;

    function frame() {
      rafId = 0;
      positionInline();
      if (performance.now() < until) rafId = requestAnimationFrame(frame);
    }

    function schedulePosition(ms = FOLLOW_MS) {
      until = Math.max(until, performance.now() + ms);
      if (!rafId) rafId = requestAnimationFrame(frame);
    }

    function scrollTabs(px) {
      try {
        asb.scrollByPixels(px, true);
      } catch (e) {
        asb.scrollbox?.scrollBy({ left: px, behavior: "instant" });
      }
    }

    function bindScrollButton(btn, dir) {
      let delayTimer = null;
      let holdRaf = 0;
      let holdStart = 0;
      let lastTs = 0;

      const stop = () => {
        clearTimeout(delayTimer);
        delayTimer = null;
        if (holdRaf) cancelAnimationFrame(holdRaf);
        holdRaf = 0;
      };

      const hold = (ts) => {
        if (btn.hasAttribute("ie6-disabled")) {
          stop();
          return;
        }
        const dt = Math.min(ts - lastTs, 50);
        lastTs = ts;
        const k = Math.min((ts - holdStart) / SPEED_RAMP_MS, 1);
        const speed = SPEED_MIN_PX_S + (SPEED_MAX_PX_S - SPEED_MIN_PX_S) * k;
        scrollTabs(dir * speed * (dt / 1000));
        holdRaf = requestAnimationFrame(hold);
      };

      btn.addEventListener("mousedown", (e) => {
        if (e.button !== 0 || btn.hasAttribute("ie6-disabled")) return;
        e.preventDefault();
        scrollTabs(dir * CLICK_STEP_PX);
        delayTimer = setTimeout(() => {
          delayTimer = null;
          holdStart = lastTs = performance.now();
          holdRaf = requestAnimationFrame(hold);
        }, HOLD_DELAY_MS);
      });

      for (const ev of ["mouseleave", "dragstart"]) btn.addEventListener(ev, stop);
      window.addEventListener("mouseup", stop, true);
      window.addEventListener("blur", stop);
    }

    bindScrollButton(left, -1);
    bindScrollButton(right, 1);

    function bindWheel(btn) {
      btn.addEventListener(
        "wheel",
        (e) => {
          if (!isOverflowing()) return;
          const d = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
          if (!d) return;
          scrollTabs(e.deltaMode === 1 ? d * 40 : d);
          e.preventDefault();
        },
        { passive: false }
      );
    }
    for (const b of [left, right, plusEnd]) bindWheel(b);

    function bindPressed(btn) {
      const release = () => btn.removeAttribute("ie6-pressed");
      btn.addEventListener("mousedown", (e) => {
        if (e.button !== 0 || btn.hasAttribute("ie6-disabled")) return;
        btn.setAttribute("ie6-pressed", "true");
      });
      btn.addEventListener("mouseleave", release);
      window.addEventListener("mouseup", release, true);
      window.addEventListener("blur", release);
    }
    for (const b of [left, right, plusEnd, plusInline]) bindPressed(b);

    function isOverflowing() {
      return asb.hasAttribute("overflowing") || tabs.getAttribute("overflow") === "true";
    }

    function sync() {
      const overflowing = isOverflowing();

      left.hidden = right.hidden = plusEnd.hidden = !overflowing;
      plusInline.hidden = overflowing;
      plusInline.style.visibility = tabs.hasAttribute("movingtab") ? "hidden" : "";

      left.toggleAttribute("ie6-disabled", asb.hasAttribute("scrolledtostart"));
      right.toggleAttribute("ie6-disabled", asb.hasAttribute("scrolledtoend"));

      schedulePosition();
    }

    const stateObserver = new MutationObserver(sync);
    const stateFilter = {
      attributes: true,
      attributeFilter: ["overflowing", "overflow", "scrolledtostart", "scrolledtoend", "movingtab"],
    };
    stateObserver.observe(asb, stateFilter);
    stateObserver.observe(tabs, stateFilter);

    for (const ev of ["TabOpen", "TabClose", "TabMove", "TabPinned", "TabUnpinned"]) {
      tabs.addEventListener(ev, sync);
    }
    window.addEventListener("resize", sync);

    tabs.addEventListener("mouseleave", () => schedulePosition());
    asb.addEventListener("transitionend", () => schedulePosition(100), true);
    new ResizeObserver(() => schedulePosition()).observe(tabs);
    new ResizeObserver(() => schedulePosition()).observe(toolbar);
    new MutationObserver(() => schedulePosition()).observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["ie6-sidebar-open", "ie6-colorscheme", "sizemode"],
    });

    function hideNatives() {
      for (const id of ["tabs-newtab-button", "new-tab-button"]) {
        const el = document.getElementById(id);
        if (el && el.style.display !== "none") {
          el.style.setProperty("display", "none", "important");
        }
      }

      const root = asb.shadowRoot;
      if (root && !root.getElementById("ie6-hide-native-scrollbuttons")) {
        const style = document.createElementNS(XHTML, "style");
        style.id = "ie6-hide-native-scrollbuttons";
        style.textContent =
          '[part="scrollbutton-up"], [part="scrollbutton-down"] { display: none !important; }';
        root.appendChild(style);
      }
    }

    hideNatives();
    let hideQueued = false;
    new MutationObserver(() => {
      if (hideQueued) return;
      hideQueued = true;
      requestAnimationFrame(() => {
        hideQueued = false;
        hideNatives();
      });
    }).observe(toolbar, { childList: true, subtree: true });

    function stripCloseTooltip(tab) {
      const btn = tab.querySelector(".tab-close-button");
      if (!btn) return;
      for (const attr of ["data-l10n-id", "data-l10n-args", "tooltiptext", "title"]) {
        btn.removeAttribute(attr);
      }
    }

    for (const tab of gBrowser.tabs) stripCloseTooltip(tab);
    tabs.addEventListener("TabOpen", (e) => stripCloseTooltip(e.target));

    window.addEventListener(
      "popupshowing",
      (e) => {
        if (e.target.id !== "tabbrowser-tab-tooltip") return;
        if (!e.target.triggerNode?.closest?.(".tab-close-button")) return;
        e.preventDefault();
        e.stopPropagation();
      },
      true
    );

    sync();
  } catch (ex) {}
})();