(function () {
  const { CustomizableUI } = ChromeUtils.importESModule(
    "moz-src:///browser/components/customizableui/CustomizableUI.sys.mjs"
  );

  CustomizableUI.createWidget({
    id: "ie6-research-button",
    type: "button",
    label: "Research",
    tooltiptext: "Research",
    onCommand() {
      window.ie6ToggleResearchSidebar?.();
    },
  });
})();