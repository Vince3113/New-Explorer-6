(function () {
  let extensionsWindow = null;

  function openWindow() {
    if (extensionsWindow && !extensionsWindow.closed) {
      extensionsWindow.focus();
      return;
    }
    extensionsWindow = window.openDialog(
      "chrome://userchrome/content/extensions-window.xhtml",
      "_blank",
      "chrome,dialog,centerscreen,resizable=no,width=561,height=527"
    );
  }

  function addMenuItem() {
    if (document.getElementById("extensions-menuitem")) return;
    const item = document.createXULElement("menuitem");
    item.id = "extensions-menuitem";
    item.setAttribute("label", "Manage Extensions");
    item.addEventListener("command", openWindow);
    document.getElementById("menu_ToolsPopup").appendChild(item);
  }

  function onPopupShowing(event) {
    if (event.target.id !== "unified-extensions-panel") return;
    event.preventDefault();
    event.stopPropagation();
    openWindow();
  }

  function init() {
    const toolsPopup = document.getElementById("menu_ToolsPopup");
    if (toolsPopup) toolsPopup.addEventListener("popupshowing", addMenuItem);
    else {}

    document.addEventListener("popupshowing", onPopupShowing, true);
    window.addEventListener("unload", () => {
      if (extensionsWindow && !extensionsWindow.closed) extensionsWindow.close();
    }, { once: true });
  }

  if (document.readyState === "complete") init();
  else window.addEventListener("load", init, { once: true });
})();