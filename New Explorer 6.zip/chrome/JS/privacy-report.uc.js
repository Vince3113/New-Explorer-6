(function () {
  "use strict";

  if (window.location.href !== "chrome://browser/content/browser.xhtml") return;
  if (window.IE6PrivacyReport) return;

  const Ci = Components.interfaces;
  const TYPE_DOCUMENT = Ci.nsIContentPolicy.TYPE_DOCUMENT;

  const MSG_COLLECT = "privacy-report:collect";
  const MSG_RESOURCES = "privacy-report:resources";
  const COLLECT_TIMEOUT = 600;

  const WP = Ci.nsIWebProgressListener;
  const flagsOf = (names) => names.map((name) => WP[name]).filter((flag) => typeof flag === "number");
  const hasAny = (state, flags) => flags.some((flag) => (state & flag) !== 0);

  const BLOCKED_COOKIES = flagsOf([
    "STATE_COOKIES_BLOCKED_BY_PERMISSION",
    "STATE_COOKIES_BLOCKED_TRACKER",
    "STATE_COOKIES_BLOCKED_SOCIALTRACKER",
    "STATE_COOKIES_BLOCKED_ALL",
    "STATE_COOKIES_BLOCKED_FOREIGN",
  ]);
  const BLOCKED_CONTENT = flagsOf([
    "STATE_BLOCKED_TRACKING_CONTENT",
    "STATE_BLOCKED_FINGERPRINTING_CONTENT",
    "STATE_BLOCKED_CRYPTOMINING_CONTENT",
    "STATE_BLOCKED_SOCIALTRACKING_CONTENT",
  ]);
  const RESTRICTED = flagsOf(["STATE_COOKIES_PARTITIONED_FOREIGN"]);
  const LOADED_COOKIES = flagsOf([
    "STATE_COOKIES_LOADED",
    "STATE_COOKIES_LOADED_TRACKER",
    "STATE_COOKIES_LOADED_SOCIALTRACKER",
  ]);

  const isWebURI = (uri) => !!uri && (uri.schemeIs("http") || uri.schemeIs("https"));

  const byWindow = new Map();
  const pending = new WeakMap();

  const newSite = (key, host) => ({ key, host, sent: false, set: false });

  function resolveBrowser(channel) {
    const loadInfo = channel.loadInfo;
    const top = loadInfo?.browsingContext?.top;
    const browser = top?.embedderElement;
    if (!browser || !window.gBrowser?.getTabForBrowser(browser)) return null;
    return { loadInfo, top, browser };
  }

  function pageSites(browser, top) {
    const wgp = top.currentWindowGlobal;
    if (!wgp) return null;

    const id = wgp.innerWindowId;
    let record = byWindow.get(id);
    if (record) return record.sites;

    record = { sites: new Map() };
    byWindow.set(id, record);

    let docURI = null;
    try {
      docURI = wgp.documentURI;
    } catch {}

    const loading = pending.get(browser);
    if (loading && docURI && loading.mainKey === docURI.prePath) {
      for (const [key, site] of loading.sites) record.sites.set(key, site);
      pending.delete(browser);
    }
    if (isWebURI(docURI) && !record.sites.has(docURI.prePath)) {
      record.sites.set(docURI.prePath, newSite(docURI.prePath, docURI.host));
    }
    return record.sites;
  }

  function mark(channel, sites, isRequest) {
    const uri = channel.URI;
    let site = sites.get(uri.prePath);
    if (!site) {
      site = newSite(uri.prePath, uri.host);
      sites.set(uri.prePath, site);
    }

    try {
      if (isRequest) {
        channel.getRequestHeader("Cookie");
        site.sent = true;
      } else {
        channel.getResponseHeader("Set-Cookie");
        site.set = true;
      }
    } catch {}
  }

  function onRequest(channel) {
    const ctx = resolveBrowser(channel);
    if (!ctx) return;

    if (ctx.loadInfo.externalContentPolicyType === TYPE_DOCUMENT) {
      const loading = { sites: new Map(), mainKey: channel.URI.prePath };
      pending.set(ctx.browser, loading);
      mark(channel, loading.sites, true);
      return;
    }

    const sites = pageSites(ctx.browser, ctx.top);
    if (sites) mark(channel, sites, true);
  }

  function onResponse(channel) {
    const ctx = resolveBrowser(channel);
    if (!ctx) return;

    const sites =
      ctx.loadInfo.externalContentPolicyType === TYPE_DOCUMENT
        ? pending.get(ctx.browser)?.sites
        : pageSites(ctx.browser, ctx.top);
    if (sites) mark(channel, sites, false);
  }

  const OBSERVED_TOPICS = [
    "http-on-modify-request",
    "http-on-examine-response",
    "http-on-examine-cached-response",
    "http-on-examine-merged-response",
    "inner-window-destroyed",
  ];

  const observer = {
    observe(subject, topic) {
      if (topic === "inner-window-destroyed") {
        try {
          byWindow.delete(subject.QueryInterface(Ci.nsISupportsPRUint64).data);
        } catch {}
        return;
      }

      try {
        const channel = subject.QueryInterface(Ci.nsIHttpChannel);
        if (topic === "http-on-modify-request") onRequest(channel);
        else onResponse(channel);
      } catch {}
    },
  };

  for (const topic of OBSERVED_TOPICS) Services.obs.addObserver(observer, topic);
  window.addEventListener(
    "unload",
    () => {
      for (const topic of OBSERVED_TOPICS) {
        try {
          Services.obs.removeObserver(observer, topic);
        } catch {}
      }
    },
    { once: true }
  );

  const FRAME_SCRIPT =
    "data:application/javascript;charset=utf-8," +
    encodeURIComponent(`
      addMessageListener("${MSG_COLLECT}", () => {
        const urls = [];
        const walk = (win, depth) => {
          try {
            for (const entry of win.performance.getEntriesByType("resource")) urls.push(entry.name);
          } catch {}
          if (depth > 4) return;
          try {
            for (let i = 0; i < win.frames.length; i++) {
              try {
                walk(win.frames[i], depth + 1);
              } catch {}
            }
          } catch {}
        };
        try {
          walk(content, 0);
        } catch {}
        sendAsyncMessage("${MSG_RESOURCES}", { urls });
      });
    `);
  const frameScriptLoaded = new WeakSet();

  function collectPerfUrls(browser) {
    return new Promise((resolve) => {
      const mm = browser.messageManager;
      if (!mm) return resolve([]);

      let finished = false;
      const finish = (urls) => {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        try {
          mm.removeMessageListener(MSG_RESOURCES, listener);
        } catch {}
        resolve(urls);
      };
      const listener = { receiveMessage: (msg) => finish(msg.data?.urls || []) };
      const timer = setTimeout(() => finish([]), COLLECT_TIMEOUT);

      try {
        mm.addMessageListener(MSG_RESOURCES, listener);
        if (!frameScriptLoaded.has(browser)) {
          mm.loadFrameScript(FRAME_SCRIPT, true);
          frameScriptLoaded.add(browser);
        }
        mm.sendAsyncMessage(MSG_COLLECT);
      } catch {
        finish([]);
      }
    });
  }

  async function readBlockingLog(browser) {
    let raw = null;
    try {
      if (typeof browser.getContentBlockingLog === "function") raw = await browser.getContentBlockingLog();
    } catch {}
    if (!raw) {
      try {
        raw = browser.browsingContext.currentWindowGlobal.contentBlockingLog;
      } catch {}
    }
    if (!raw) return {};

    try {
      return typeof raw === "string" ? JSON.parse(raw) : raw;
    } catch {
      return {};
    }
  }

  function collectNetworkSites(browser, uri, getEntry) {
    try {
      const wgp = browser.browsingContext.currentWindowGlobal;
      let sites = wgp ? byWindow.get(wgp.innerWindowId)?.sites : null;
      if (!sites) {
        const loading = pending.get(browser);
        if (loading?.mainKey === uri.prePath) sites = loading.sites;
      }

      for (const site of sites?.values() || []) {
        const entry = getEntry(site.key, site.host);
        entry.sent ||= site.sent;
        entry.set ||= site.set;
      }
    } catch {}
  }

  async function collectPerformanceSites(browser, getEntry) {
    for (const raw of await collectPerfUrls(browser)) {
      try {
        const url = new URL(raw);
        if (url.protocol === "http:" || url.protocol === "https:") getEntry(url.origin, url.hostname);
      } catch {}
    }
  }

  async function collectBlockingSites(browser, getEntry) {
    try {
      const log = await readBlockingLog(browser);
      for (const [origin, events] of Object.entries(log || {})) {
        let originURI;
        try {
          originURI = Services.io.newURI(origin);
        } catch {
          continue;
        }
        if (!isWebURI(originURI) || !Array.isArray(events)) continue;

        const entry = getEntry(originURI.prePath, originURI.host);
        for (const [state] of events) {
          if (hasAny(state, BLOCKED_COOKIES) || hasAny(state, BLOCKED_CONTENT)) entry.blocked = true;
          else if (hasAny(state, RESTRICTED)) entry.restricted = true;
          if (hasAny(state, LOADED_COOKIES)) entry.loaded = true;
        }
      }
    } catch {}
  }

  function statusOf(entry) {
    if (entry.blocked) return "Blocked";
    if (entry.restricted) return "Restricted";
    if (entry.sent || entry.set || entry.loaded) return "Accepted";
    return "";
  }

  function toSite(entry, label) {
    const status = statusOf(entry);
    return {
      key: entry.key,
      host: entry.host,
      label,
      status,
      restricted: status === "Blocked" || status === "Restricted",
    };
  }

  function isSupported(browser) {
    try {
      return isWebURI(browser.currentURI);
    } catch {
      return false;
    }
  }

  async function getReport(browser) {
    const uri = browser.currentURI;
    const report = { supported: isWebURI(uri), pageUrl: "", sites: [], anyRestricted: false, originAttributes: {} };
    if (!report.supported) return report;

    report.pageUrl = uri.specIgnoringRef;
    try {
      report.originAttributes = JSON.parse(JSON.stringify(browser.contentPrincipal.originAttributes));
    } catch {}

    const entries = new Map();
    const getEntry = (key, host) => {
      let entry = entries.get(key);
      if (!entry) {
        entry = { key, host, sent: false, set: false, loaded: false, blocked: false, restricted: false };
        entries.set(key, entry);
      }
      return entry;
    };

    getEntry(uri.prePath, uri.host);
    collectNetworkSites(browser, uri, getEntry);
    await collectPerformanceSites(browser, getEntry);
    await collectBlockingSites(browser, getEntry);

    const first = toSite(entries.get(uri.prePath), report.pageUrl);
    const others = [...entries.values()]
      .filter((entry) => entry.key !== uri.prePath)
      .sort((a, b) => a.key.localeCompare(b.key))
      .map((entry) => toSite(entry, entry.key + "/"));

    report.sites = [first, ...others];
    report.anyRestricted = report.sites.some((site) => site.restricted);
    return report;
  }

  window.IE6PrivacyReport = { isSupported, getReport };
})();