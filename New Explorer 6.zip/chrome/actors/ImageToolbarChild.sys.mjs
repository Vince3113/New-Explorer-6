const IMG = "resource://ie6theme/images/";
const ZOOM_ENLARGE = `${IMG}imgtoolbar-enlarge.png`;
const ZOOM_SHRINK = `${IMG}imgtoolbar-shrink.png`;

const TOOLBAR_HTML = `
  <style>
    html, body, :root { background-color: #FFFFFF !important; }
    #image-toolbar {
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      z-index: 2147483647 !important;
      width: 112px !important;
      height: 24px !important;
      box-sizing: border-box !important;
      background: linear-gradient(to bottom, #ECE9D8, #D4D0C8);
      border: 1px solid #716F64;
      border-top: none;
      transition: width 0.15s ease-out;
    }
    #image-toolbar.collapsed { width: 16px !important; }
    #image-toolbar button {
      position: absolute !important;
      top: 0 !important;
      width: 24px !important;
      height: 24px !important;
      box-sizing: border-box !important;
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      padding: 0 !important;
      margin: 0 !important;
      border: 1px solid transparent;
      background: transparent;
      cursor: default;
    }
    #it-save { left: 0 !important; }
    #it-print { left: 24px !important; }
    #it-mail { left: 48px !important; }
    #it-folder { left: 72px !important; }
    #image-toolbar button#it-toggle { left: 96px !important; width: 16px !important; }
    #image-toolbar.collapsed button:not(#it-toggle) { display: none !important; }
    #image-toolbar.collapsed #it-toggle { left: 0 !important; }
    #image-toolbar button:hover {
      border: 1px solid rgba(113, 111, 100, 0.6);
      background: rgba(236, 233, 216, 0.6);
    }
    #image-toolbar img {
      width: 16px !important;
      height: 16px !important;
      flex: 0 0 16px !important;
    }
    #it-toggle img { transform: scaleX(-1); }
    #image-toolbar.collapsed #it-toggle img { transform: none; }
  </style>
  <button id="it-save" data-tip="Save Picture"><img src="${IMG}imgtoolbar-save.png"></button>
  <button id="it-print" data-tip="Print Picture"><img src="${IMG}imgtoolbar-print.png"></button>
  <button id="it-mail" data-tip="E-mail Picture"><img src="${IMG}imgtoolbar-mail.png"></button>
  <button id="it-folder" data-tip="Open My Pictures Folder"><img src="${IMG}imgtoolbar-folder.png"></button>
  <button id="it-toggle" data-tip="Hide/Show Toolbar"><img src="${IMG}imgtoolbar-toggle.png"></button>
`;

const ZOOM_HTML = `
  <style>
    #image-zoomicon {
      position: fixed !important;
      bottom: 8px !important;
      right: 8px !important;
      z-index: 2147483647 !important;
      width: 45px !important;
      height: 44px !important;
      box-sizing: border-box !important;
      display: none;
      align-items: center;
      justify-content: center;
      background: linear-gradient(to bottom, #ECE9D8, #D4D0C8);
      border: 1px solid #716F64;
    }
    #image-zoomicon .zoomicon-inner {
      width: 41px;
      height: 40px;
      box-sizing: border-box;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 1px solid transparent;
    }
    #image-zoomicon:hover .zoomicon-inner {
      border: 1px solid #716F64;
      background: #FFFFFF;
    }
    #image-zoomicon img {
      width: 39px !important;
      height: 38px !important;
    }
  </style>
  <div class="zoomicon-inner"><img src="${ZOOM_ENLARGE}"></div>
`;

const TIP_DELAY = 500;
const TIP_STYLE = [
  "position:fixed",
  "z-index:2147483647",
  "display:none",
  "padding:2px 4px",
  "border:1px solid #000",
  "background:#FFFFE1",
  "color:#000",
  "font:11px Tahoma,'MS Sans Serif',sans-serif",
  "white-space:nowrap",
  "pointer-events:none",
  "box-shadow:2px 2px 3px rgba(0,0,0,0.45)",
].join(";");

export class ImageToolbarChild extends JSWindowActorChild {
  handleEvent(event) {
    if (event.type !== "DOMWindowCreated") return;

    const win = this.contentWindow;
    const doc = this.document;
    if (!win || !doc || !(doc instanceof win.ImageDocument)) return;
    if (doc.getElementById("image-toolbar")) return;

    this.injectToolbar(doc);
    this.injectZoomIndicator(doc);
    this.injectTooltips(doc);
  }

  injectTooltips(doc) {
    const win = doc.defaultView;
    const tip = doc.createElement("div");
    tip.style.cssText = TIP_STYLE;
    doc.documentElement.appendChild(tip);

    let timer = null;
    let current = null;

    const hide = () => {
      win.clearTimeout(timer);
      tip.style.display = "none";
      current = null;
    };

    const show = (text, x, y) => {
      tip.textContent = text;
      tip.style.left = "0px";
      tip.style.top = "0px";
      tip.style.display = "block";
      const width = tip.offsetWidth;
      const height = tip.offsetHeight;
      let left = x + 12;
      let top = y + 20;
      if (left + width > win.innerWidth - 4) left = Math.max(4, x - width - 5);
      if (top + height > win.innerHeight - 4) top = Math.max(4, y - height - 8);
      tip.style.left = left + "px";
      tip.style.top = top + "px";
    };

    doc.addEventListener("mouseover", (e) => {
      const el = e.target.closest?.("[data-tip]");
      if (!el) {
        if (current) hide();
        return;
      }
      if (el === current) return;
      hide();
      current = el;
      const { clientX, clientY } = e;
      timer = win.setTimeout(() => {
        const text = el.getAttribute("data-tip");
        if (text) show(text, clientX, clientY);
      }, TIP_DELAY);
    });

    doc.addEventListener("mouseout", (e) => {
      if (current && !current.contains(e.relatedTarget)) hide();
    });

    doc.addEventListener("mousedown", hide, true);
  }

  injectToolbar(doc) {
    const bar = doc.createElement("div");
    bar.id = "image-toolbar";
    bar.innerHTML = TOOLBAR_HTML;
    doc.documentElement.appendChild(bar);

    bar.addEventListener("click", (e) => {
      const button = e.target.closest("button");
      if (!button) return;
      switch (button.id) {
        case "it-save":
          this.sendAsyncMessage("ImageToolbar:Save", { url: doc.URL });
          break;
        case "it-print":
          this.contentWindow.print();
          break;
        case "it-mail":
          this.sendAsyncMessage("ImageToolbar:Mail", { url: doc.URL });
          break;
        case "it-folder":
          this.sendAsyncMessage("ImageToolbar:OpenPicturesFolder", {});
          break;
        case "it-toggle":
          bar.classList.toggle("collapsed");
          break;
      }
    });
  }

  injectZoomIndicator(doc) {
    const win = doc.defaultView;
    const img = doc.querySelector("body > img");
    if (!img) return;

    const wrap = doc.createElement("div");
    wrap.id = "image-zoomicon";
    wrap.innerHTML = ZOOM_HTML;
    doc.documentElement.appendChild(wrap);

    const icon = wrap.querySelector("img");
    const update = () => {
      const shrunk = img.classList.contains("shrinkToFit");
      const canToggle =
        shrunk ||
        img.classList.contains("overflowingHorizontal") ||
        img.classList.contains("overflowingVertical");
      wrap.style.display = canToggle ? "flex" : "none";
      icon.src = shrunk ? ZOOM_SHRINK : ZOOM_ENLARGE;
      wrap.setAttribute("data-tip", shrunk ? "View image at actual size" : "Stretch to fit page");
    };

    new win.MutationObserver(update).observe(img, { attributes: true, attributeFilter: ["class"] });
    update();
    win.setTimeout(update, 300);
    win.setTimeout(update, 1000);

    wrap.addEventListener("click", () =>
      img.dispatchEvent(new win.MouseEvent("click", { bubbles: true, cancelable: true }))
    );
  }
}