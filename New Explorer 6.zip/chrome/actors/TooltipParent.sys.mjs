export class IE6TooltipParent extends JSWindowActorParent {
  receiveMessage(msg) {
    const win = this.browsingContext.topChromeWindow;
    if (!win) return;

    switch (msg.name) {
      case "IE6Tooltip:Show": {
        const browser = this.browsingContext.top.embedderElement;
        if (!browser || typeof win.__tooltipShowFromContent !== "function") return;
        const rect = browser.getBoundingClientRect();
        const { text, x, y } = msg.data;
        win.__tooltipShowFromContent(text, rect.left + x, rect.top + y);
        break;
      }
      case "IE6Tooltip:Hide":
        if (typeof win.__tooltipHideFromContent === "function") {
          win.__tooltipHideFromContent();
        }
        break;
    }
  }
}