const SHELL_FOLDERS_KEY = "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders";
const MAIL_KEY = "Software\\Clients\\Mail";

const KNOWN_MAIL_CLIENTS = {
  Thunderbird: (file) => [
    "-compose",
    `attachment='file://${file.path.replace(/\\/g, "/")}'`,
  ],
  Outlook: (file) => ["/a", file.path],
};

function readRegistryString(root, path, name = "") {
  try {
    const key = Cc["@mozilla.org/windows-registry-key;1"].createInstance(Ci.nsIWindowsRegKey);
    key.open(root, path, Ci.nsIWindowsRegKey.ACCESS_READ);
    try {
      return key.readStringValue(name);
    } finally {
      key.close();
    }
  } catch (e) {
    return null;
  }
}

function leafNameOf(uri, fallback) {
  try {
    return uri.QueryInterface(Ci.nsIURL).fileName || fallback;
  } catch (e) {
    return fallback;
  }
}

export class ImageToolbarParent extends JSWindowActorParent {
  get browser() {
    return this.browsingContext.top.embedderElement;
  }

  async receiveMessage(msg) {
    try {
      switch (msg.name) {
        case "ImageToolbar:Save":
          return await this.saveImage(msg.data.url);
        case "ImageToolbar:Mail":
          return await this.mailImage(msg.data.url);
        case "ImageToolbar:OpenPicturesFolder":
          return this.openPicturesFolder();
      }
    } catch (e) {}
    return undefined;
  }

  getPicturesFolder() {
    const path = readRegistryString(
      Ci.nsIWindowsRegKey.ROOT_KEY_CURRENT_USER,
      SHELL_FOLDERS_KEY,
      "My Pictures"
    );
    if (path) {
      try {
        const file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
        file.initWithPath(path);
        if (file.exists()) return file;
      } catch (e) {}
    }
    const pics = Services.dirsvc.get("Home", Ci.nsIFile).clone();
    pics.append("Pictures");
    return pics;
  }

  async saveImage(url) {
    if (!this.browser) return;

    const uri = Services.io.newURI(url);
    const fp = Cc["@mozilla.org/filepicker;1"].createInstance(Ci.nsIFilePicker);
    fp.init(this.browser.browsingContext, "Guardar imagen como", Ci.nsIFilePicker.modeSave);
    fp.defaultString = leafNameOf(uri, "imagen");
    fp.appendFilters(Ci.nsIFilePicker.filterAll);
    try {
      const pics = this.getPicturesFolder();
      if (pics.exists()) fp.displayDirectory = pics;
    } catch (e) {}

    const rv = await new Promise((resolve) => fp.open(resolve));
    if (rv !== Ci.nsIFilePicker.returnOK && rv !== Ci.nsIFilePicker.returnReplace) return;

    await this.writeUriToFile(uri, fp.file.path);
  }

  async writeUriToFile(uri, destPath) {
    if (uri.schemeIs("file")) {
      await IOUtils.copy(uri.QueryInterface(Ci.nsIFileURL).file.path, destPath);
      return;
    }
    const response = await fetch(uri.spec);
    if (!response.ok) throw new Error(`HTTP ${response.status} for ${uri.spec}`);
    await IOUtils.write(destPath, new Uint8Array(await response.arrayBuffer()));
  }

  openPicturesFolder() {
    const dir = this.getPicturesFolder();
    try {
      dir.reveal();
    } catch (e) {
      dir.launch();
    }
  }

  async mailImage(url) {
    let file;
    try {
      const uri = Services.io.newURI(url);
      file = uri.schemeIs("file")
        ? uri.QueryInterface(Ci.nsIFileURL).file
        : await this.downloadToTemp(uri);
    } catch (e) {
      return;
    }
    this.launchMailClient(file);
  }

  async downloadToTemp(uri) {
    const dest = Services.dirsvc.get("TmpD", Ci.nsIFile).clone();
    dest.append(leafNameOf(uri, "image.jpg"));
    dest.createUnique(Ci.nsIFile.NORMAL_FILE_TYPE, 0o600);
    await this.writeUriToFile(uri, dest.path);
    return dest;
  }

  getMailClientName() {
    return readRegistryString(Ci.nsIWindowsRegKey.ROOT_KEY_CURRENT_USER, MAIL_KEY);
  }

  getMailClientExe(clientName) {
    const cmd = readRegistryString(
      Ci.nsIWindowsRegKey.ROOT_KEY_LOCAL_MACHINE,
      `${MAIL_KEY}\\${clientName}\\shell\\open\\command`
    );
    if (!cmd) return null;
    const match = cmd.match(/^"([^"]+)"/) || cmd.match(/^(\S+)/);
    return match ? match[1] : null;
  }

  fallbackToMailto(file, clientName) {
    const win = this.browser?.ownerGlobal;
    win?.openTrustedLinkIn(`mailto:?subject=${encodeURIComponent(file.leafName)}`, "current");
    const msg = clientName
      ? `Se detectó "${clientName}" pero todavía no conozco su sintaxis para adjuntar. Adjuntá el archivo manualmente.`
      : "No se pudo detectar el cliente de correo para adjuntar el archivo automáticamente. Adjuntala manualmente.";
    Services.prompt.alert(win, "Enviar imagen", msg);
  }

  launchMailClient(file) {
    const clientName = this.getMailClientName();
    const exePath = clientName && this.getMailClientExe(clientName);
    const knownClient = clientName && Object.keys(KNOWN_MAIL_CLIENTS).find((k) => clientName.includes(k));

    if (!exePath || !knownClient) {
      this.fallbackToMailto(file, clientName);
      return;
    }

    const exe = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
    exe.initWithPath(exePath);
    const process = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
    process.init(exe);

    const args = KNOWN_MAIL_CLIENTS[knownClient](file);
    process.run(false, args, args.length);
  }
}