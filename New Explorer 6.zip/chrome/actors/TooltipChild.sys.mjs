export class IE6TooltipChild extends JSWindowActorChild {
  constructor() {
    super();
    this._currentTarget = null;
  }

  handleEvent(event) {
    if (event.type === "mouseover") this._onMouseOver(event);
    else if (event.type === "mouseout") this._onMouseOut(event);
  }

  _findTitle(node) {
    for (let el = node; el && el.nodeType === 1; el = el.parentElement) {
      const text = el.getAttribute("title");
      if (text) return { el, text };
    }
    return null;
  }

  _onMouseOver(event) {
    const found = this._findTitle(event.target);

    if (!found) {
      if (this._currentTarget) {
        this._currentTarget = null;
        this.sendAsyncMessage("IE6Tooltip:Hide", {});
      }
      return;
    }

    if (found.el === this._currentTarget) return;
    this._currentTarget = found.el;

    this.sendAsyncMessage("IE6Tooltip:Show", {
      text: found.text,
      x: event.clientX,
      y: event.clientY,
    });
  }

  _onMouseOut(event) {
    if (
      this._currentTarget &&
      (!event.relatedTarget || !this._currentTarget.contains(event.relatedTarget))
    ) {
      this._currentTarget = null;
      this.sendAsyncMessage("IE6Tooltip:Hide", {});
    }
  }
}