Welcome to New Explorer 6, a IE6 theme for Nocturne version 1.4.0

This theme was designed for Projek01 Users, you will find issues if you use it outside it.

Enable Themes ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Open about:config and activate "toolkit.legacyUserProfileCustomizations.stylesheets"

*Warning* Nocturne can reactiave cleartype, disable it by typing in Run "cttune" and following the steps

Installation ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Put the Chrome Folder inside the current profile file (You can find it by clicking "Profile Folder" in about:support)

Put the defaults folder and config.cfg inside Nocturne main file (replace all)

Configuration ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

In about:config make the following changes:

-print.prefer_system_dialog = TRUE
-browser.chrome.toolbar_tips = FALSE
-browser.urlbar.formatting.enabled = FALSE
-browser.urlbar.showSearchTerms.enabled = FALSE
-browser.urlbar.showSearchTerms.featureGate = FALSE
-browser.tabs.groups.enabled = FALSE
-full-screen-api.transition = enter: 0 0 / leave: 0 0
-browser.download.alwaysOpenPanel = FALSE
-full-screen-api.warning.timeout = 0

Enable Win URL always

In Settings disable the following: *First two are related to issues with Nocturne customization*

-Show search suggestions
-Recent searches
-Suggest search engines to use

Extra Steps ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

- Title Replacement -

Open Windhawk and follow the steps

-Go to Search for mods...
-Search for "Text Replace" by m417z (Details>Install)
-Once install, Go to Settings, Visual Mode, Scroll down, and click Add new item

Fill the next requierments:

Program name = nocturne.exe
The text to be replaced = Mozilla Firefox
The replacement text = Microsoft Internet Explorer

- Icon Replacement -

Open Resource Hacker

- File, Open and search for "nocturne.exe" in the Nocturne main file
- Once open, go to the Icon Group folder and replace "1" and "32512" with IconGroup1.ico in the Theme folder

Sadly at the moment the 16x16 ico will not be displayed due to Firefox based issues.

Enjoy and thanks for downloading!